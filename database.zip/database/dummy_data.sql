-- ========================================================
-- Seed/Dummy Data Insert Queries for Inventory Management System
-- Use this file to populate inventory tables for testing
-- ========================================================

-- 1. Populate custom Units of Measurement (Left empty by default)
-- INSERT INTO public.inventory_units (unit) VALUES ...

-- 2. Populate custom Storage Locations (Left empty by default)
-- INSERT INTO public.inventory_locations (location) VALUES ...

-- 3. Populate Materials Master Data (Left empty by default)
-- INSERT INTO public.inventory_materials ...

-- 4. Populate Sample Transaction Records
INSERT INTO public.inventory_transactions (id, date, sku, name, qty, type, ref, remarks, user_name) VALUES
('TXN-00001', CURRENT_DATE - INTERVAL '15 days', 'SKU-1001', 'Steel Rod 12mm', 150, 'OUT', 'WO-4560', 'Production consumption', 'Priya Sharma'),
('TXN-00002', CURRENT_DATE - INTERVAL '12 days', 'SKU-1001', 'Steel Rod 12mm', 250, 'IN', 'GRN-8901', 'Goods received from supplier', 'Arjun Mehta'),
('TXN-00003', CURRENT_DATE - INTERVAL '10 days', 'SKU-1002', 'Copper Wire 2.5mm', 400, 'OUT', 'WO-4562', 'Production consumption', 'Priya Sharma'),
('TXN-00004', CURRENT_DATE - INTERVAL '8 days', 'SKU-1002', 'Copper Wire 2.5mm', 500, 'IN', 'GRN-8902', 'Goods received from supplier', 'Arjun Mehta'),
('TXN-00005', CURRENT_DATE - INTERVAL '5 days', 'SKU-1005', 'Industrial Bearings 6204', 30, 'OUT', 'WO-4568', 'Maintenance replacement', 'Priya Sharma'),
('TXN-00006', CURRENT_DATE - INTERVAL '2 days', 'SKU-1006', 'Lubricant Oil 20L', 20, 'OUT', 'WO-4570', 'Routine servicing consumption', 'Priya Sharma')
ON CONFLICT (id) DO NOTHING;

-- 5. Populate Default Settings
INSERT INTO public.inventory_settings (id, page_size_master, page_size_txn, page_size_stock)
VALUES (1, 6, 6, 6)
ON CONFLICT (id) DO UPDATE SET
    page_size_master = EXCLUDED.page_size_master,
    page_size_txn = EXCLUDED.page_size_txn,
    page_size_stock = EXCLUDED.page_size_stock;

-- 6. Insert Initial Audit Log
INSERT INTO public.inventory_audit (action, user_name, detail)
VALUES ('Database Initialized', 'System', 'Seed/Dummy data loaded successfully into all tables.');
