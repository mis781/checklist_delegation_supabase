-- ---------------------------------------------------------------------------
-- whatsapp_broadcast_schedules
-- One row per broadcast created from the Broadcast Scheduler form.
-- Links to whatsapp_templates (template used) and whatsapp_bulk_contacts
-- (recipient). Run this in your Supabase SQL Editor.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.whatsapp_broadcast_schedules (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  schedule_name    TEXT NOT NULL,                 -- Section 1: Schedule Name

  schedule_status  TEXT NOT NULL DEFAULT 'onetime' -- Section 1: Schedule Status
                   CHECK (schedule_status IN ('onetime', 'recurring')),

  send_type        TEXT NOT NULL DEFAULT 'send'    -- Section 1: Send vs Schedule
                   CHECK (send_type IN ('send', 'schedule')),

  send_date        TIMESTAMPTZ,                    -- combined date+time, only used when send_type = 'schedule'

  template_id      UUID REFERENCES public.whatsapp_templates(id)
                   ON DELETE SET NULL,              -- Section 2: selected template

  mime_type        TEXT,                            -- Section 2: attachment mime type (application/pdf, image/png, etc.)
  media_url        TEXT,                            -- Section 2: uploaded attachment URL

  contact_id       UUID REFERENCES public.whatsapp_bulk_contacts(id)
                   ON DELETE CASCADE,                -- Section 3: recipient

  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Keep updated_at fresh on every row change
CREATE OR REPLACE FUNCTION public.fn_touch_broadcast_schedule()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_broadcast_schedule ON public.whatsapp_broadcast_schedules;
CREATE TRIGGER trg_touch_broadcast_schedule
  BEFORE UPDATE ON public.whatsapp_broadcast_schedules
  FOR EACH ROW EXECUTE FUNCTION public.fn_touch_broadcast_schedule();

CREATE INDEX IF NOT EXISTS idx_whatsapp_broadcast_schedules_template_id
  ON public.whatsapp_broadcast_schedules (template_id);

CREATE INDEX IF NOT EXISTS idx_whatsapp_broadcast_schedules_contact_id
  ON public.whatsapp_broadcast_schedules (contact_id);

CREATE INDEX IF NOT EXISTS idx_whatsapp_broadcast_schedules_send_date
  ON public.whatsapp_broadcast_schedules (send_date);
