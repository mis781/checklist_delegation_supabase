-- ---------------------------------------------------------------------------
-- whatsapp_bulk_contacts
-- Persisted list of contacts imported via CSV for bulk template messaging
-- from the "Bulk Import" tab of NewChatModal. Independent of
-- whatsapp_contacts_metadata (which tracks actual conversation threads) —
-- this is just a reusable address-book the user builds up over time.
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.whatsapp_bulk_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  raw_phone_number TEXT NOT NULL,
  phone_number TEXT,              -- normalized by trigger below (last 10 digits)
  display_name TEXT,
  batch_label TEXT,               -- e.g. source filename, for grouping/filtering
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

-- Reuses public.whatsapp_normalize_phone() from whatsapp_schema.sql so
-- re-importing the same numbers in a different format upserts cleanly.
CREATE OR REPLACE FUNCTION public.fn_normalize_bulk_contact_phone()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.phone_number := public.whatsapp_normalize_phone(NEW.raw_phone_number);
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_normalize_bulk_contact_phone ON public.whatsapp_bulk_contacts;
CREATE TRIGGER trg_normalize_bulk_contact_phone
  BEFORE INSERT OR UPDATE ON public.whatsapp_bulk_contacts
  FOR EACH ROW EXECUTE FUNCTION public.fn_normalize_bulk_contact_phone();

-- Drop the earlier partial unique index if this migration ran before —
-- PostgREST's upsert(onConflict:) issues a plain `ON CONFLICT (phone_number)`,
-- which Postgres can only resolve against a full (non-partial) constraint.
DROP INDEX IF EXISTS public.uq_whatsapp_bulk_contacts_phone_active;

ALTER TABLE public.whatsapp_bulk_contacts
  DROP CONSTRAINT IF EXISTS uq_whatsapp_bulk_contacts_phone;
ALTER TABLE public.whatsapp_bulk_contacts
  ADD CONSTRAINT uq_whatsapp_bulk_contacts_phone UNIQUE (phone_number);

CREATE INDEX IF NOT EXISTS idx_whatsapp_bulk_contacts_created_at
  ON public.whatsapp_bulk_contacts (created_at DESC);
