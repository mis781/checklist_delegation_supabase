-- ==========================================================================
-- WhatsApp CRM — Database Schema (Supabase / PostgreSQL)
-- Enterprise-grade, 3NF-safe, high-throughput WhatsApp Business API layer.
--
-- IMPORTANT — external_contact_id assumption:
-- This project's existing `public.users` table (see checklist_schema.sql) is
-- the INTERNAL STAFF/LOGIN table (admins, HODs, agents) — its `id` is a
-- BIGINT identity column, not a UUID. It is almost certainly NOT the same
-- table as your external "Contacts" (WhatsApp end-customers) table referenced
-- in the brief, which lives in another schema/table not visible here.
--
-- whatsapp_contacts_metadata.external_contact_id is therefore declared as a
-- plain BIGINT with NO hard FK by default. Uncomment/adjust the commented
-- FK constraint once you confirm the real Contacts table name + PK type
-- (swap to UUID there if that table uses gen_random_uuid()).
-- ==========================================================================

-- --------------------------------------------------------------------------
-- 0. Extensions
-- --------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- gen_random_uuid()

-- --------------------------------------------------------------------------
-- 1. Enum Types
-- (CREATE TYPE has no IF NOT EXISTS in Postgres — guard with DO blocks so
-- this script is safely re-runnable, matching the IF NOT EXISTS style used
-- everywhere else in this schema.)
-- --------------------------------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.whatsapp_message_direction AS ENUM ('INBOUND', 'OUTBOUND');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.whatsapp_message_type AS ENUM (
    'text', 'text_reply', 'button_reply', 'template', 'media', 'audio', 'location', 'contacts', 'reaction', 'sticker', 'unsupported'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Ensure the new enum values exist if type was already created
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'audio';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'location';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'contacts';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'reaction';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'sticker';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'unsupported';

DO $$ BEGIN
  CREATE TYPE public.whatsapp_message_status AS ENUM (
    'sent', 'delivered', 'read', 'failed'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.whatsapp_error_source AS ENUM (
    'META_WEBHOOK', 'EDGE_FUNCTION', 'PORTAL_CORE'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- --------------------------------------------------------------------------
-- 2. Table: whatsapp_templates
-- Meta-approved template library, synced periodically from the Business API.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_templates (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    element_name  TEXT NOT NULL,
    category      TEXT NOT NULL CHECK (category IN ('MARKETING', 'UTILITY', 'AUTHENTICATION')),
    language      TEXT NOT NULL DEFAULT 'en_US',
    body_text     TEXT NOT NULL, -- contains {{1}}, {{2}}... placeholders
    status        TEXT NOT NULL DEFAULT 'PENDING'
                    CHECK (status IN ('APPROVED', 'PENDING', 'REJECTED', 'PAUSED', 'DISABLED')),
    -- Meta template HEADER block. TEXT headers can carry their own {{1}}
    -- placeholder (rendered client-side only — the send edge function does
    -- not yet fill dynamic header text params); IMAGE/VIDEO/DOCUMENT headers
    -- require the *sender* to supply a concrete media link at send time
    -- (Meta's approval-time sample is preview-only and cannot be replayed).
    header_type        TEXT NOT NULL DEFAULT 'NONE', -- checked below (re-run-safe DO block)
    header_text         TEXT NULL,
    -- Opaque Meta media handle/id returned in components[].example.header_handle
    -- at template-approval time. Preview-only (cannot be sent as-is) — stored
    -- so the template picker can at least label what kind of sample exists.
    header_sample_url   TEXT NULL,
    footer_text         TEXT NULL,
    -- Array of { type: 'URL'|'PHONE_NUMBER'|'QUICK_REPLY'|'COPY_CODE', text, url?, phone_number? }
    -- mirroring Meta's BUTTONS component, so the chat UI can render the same
    -- buttons Meta shows on the approved template.
    buttons             JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at    TIMESTAMPTZ NULL,
    CONSTRAINT whatsapp_templates_element_name_key UNIQUE (element_name)
);

-- Additive columns for the HEADER/FOOTER/BUTTONS support above — safe to
-- re-run against an already-deployed table that predates these columns.
ALTER TABLE public.whatsapp_templates
    ADD COLUMN IF NOT EXISTS header_type TEXT NOT NULL DEFAULT 'NONE',
    ADD COLUMN IF NOT EXISTS header_text TEXT NULL,
    ADD COLUMN IF NOT EXISTS header_sample_url TEXT NULL,
    ADD COLUMN IF NOT EXISTS footer_text TEXT NULL,
    ADD COLUMN IF NOT EXISTS buttons JSONB NOT NULL DEFAULT '[]'::jsonb;

DO $$ BEGIN
  ALTER TABLE public.whatsapp_templates
    ADD CONSTRAINT whatsapp_templates_header_type_check
    CHECK (header_type IN ('NONE', 'TEXT', 'IMAGE', 'VIDEO', 'DOCUMENT'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- --------------------------------------------------------------------------
-- 3. Table: whatsapp_contacts_metadata
-- WhatsApp-specific configuration layered on top of an external contact.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_contacts_metadata (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_contact_id     BIGINT NULL, -- see header note; point at real Contacts PK
    -- CONSTRAINT whatsapp_contacts_metadata_external_fk
    --   FOREIGN KEY (external_contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL,
    phone_number            TEXT NOT NULL, -- normalized (last-10-digit) join key
    raw_phone_number        TEXT NOT NULL, -- untouched string as received from Meta
    display_name            TEXT NULL,
    meta_session_expires_at TIMESTAMPTZ NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at              TIMESTAMPTZ NULL,
    CONSTRAINT whatsapp_contacts_metadata_phone_number_key UNIQUE (phone_number)
);

-- --------------------------------------------------------------------------
-- 4. Table: whatsapp_conversations (selectively denormalized for inbox reads)
-- One conversation per contact — inbound webhooks always resolve to this row
-- via the normalized phone number, never creating a duplicate thread.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_conversations (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    whatsapp_contact_id UUID NOT NULL REFERENCES public.whatsapp_contacts_metadata(id) ON DELETE CASCADE,
    unread_count        INTEGER NOT NULL DEFAULT 0 CHECK (unread_count >= 0),
    last_message_text   TEXT NULL,
    last_message_at     TIMESTAMPTZ NULL,
    latest_status       TEXT NULL CHECK (latest_status IN ('sent', 'delivered', 'read', 'failed')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ NULL,
    CONSTRAINT whatsapp_conversations_contact_unique UNIQUE (whatsapp_contact_id)
);

-- --------------------------------------------------------------------------
-- 5. Table: whatsapp_messages
-- Every message instance. PK is Meta's wamid (TEXT) so delivery/read
-- webhooks can be matched directly without a lookup table.
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_messages (
    id                 TEXT PRIMARY KEY, -- Meta wamid, or 'local_<uuid>' for optimistic pre-send rows
    conversation_id    UUID NULL REFERENCES public.whatsapp_conversations(id) ON DELETE CASCADE,
    direction          public.whatsapp_message_direction NOT NULL,
    message_type       public.whatsapp_message_type NOT NULL,
    body               TEXT NULL,
    mime_type          TEXT NULL,
    media_url          TEXT NULL,
    template_id        UUID NULL REFERENCES public.whatsapp_templates(id) ON DELETE SET NULL,
    parent_message_id  TEXT NULL REFERENCES public.whatsapp_messages(id) ON DELETE SET NULL,
    is_forwarded       BOOLEAN NOT NULL DEFAULT false,
    -- Raw webhook remnants / dynamic params. For OUTBOUND 'template' messages,
    -- whatsapp-send also snapshots { header: {type, text, mediaUrl, fileName},
    -- footer, buttons } here at send time, so the chat bubble can render the
    -- header media/buttons the message was actually sent with even if the
    -- source template row is later edited or deleted.
    metadata           JSONB NOT NULL DEFAULT '{}'::jsonb,
    latest_status      public.whatsapp_message_status NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at         TIMESTAMPTZ NULL
);
-- conversation_id is nullable: inbound webhook inserts may arrive with only a
-- raw phone number in metadata->>'from_phone'; fn_resolve_message_conversation()
-- (below) resolves/creates the conversation BEFORE INSERT and fills this in.

-- --------------------------------------------------------------------------
-- 6. Table: whatsapp_message_status_history (append-only audit/event log)
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_message_status_history (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id  TEXT NOT NULL REFERENCES public.whatsapp_messages(id) ON DELETE CASCADE,
    status      public.whatsapp_message_status NOT NULL,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    raw_payload JSONB NULL -- full webhook status event, for forensic replay
);

-- --------------------------------------------------------------------------
-- 7. Table: whatsapp_error_logs
-- --------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.whatsapp_error_logs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    error_source  public.whatsapp_error_source NOT NULL,
    error_code    TEXT NULL,
    error_message TEXT NOT NULL,
    payload_dump  JSONB NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ==========================================================================
-- TRIGGERS & FUNCTIONS
-- ==========================================================================

-- --------------------------------------------------------------------------
-- A. Generic updated_at toucher
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_touch_updated_at ON public.whatsapp_templates;
CREATE TRIGGER trg_touch_updated_at
  BEFORE UPDATE ON public.whatsapp_templates
  FOR EACH ROW EXECUTE FUNCTION public.fn_touch_updated_at();

DROP TRIGGER IF EXISTS trg_touch_updated_at ON public.whatsapp_contacts_metadata;
CREATE TRIGGER trg_touch_updated_at
  BEFORE UPDATE ON public.whatsapp_contacts_metadata
  FOR EACH ROW EXECUTE FUNCTION public.fn_touch_updated_at();

DROP TRIGGER IF EXISTS trg_touch_updated_at ON public.whatsapp_conversations;
CREATE TRIGGER trg_touch_updated_at
  BEFORE UPDATE ON public.whatsapp_conversations
  FOR EACH ROW EXECUTE FUNCTION public.fn_touch_updated_at();

DROP TRIGGER IF EXISTS trg_touch_updated_at ON public.whatsapp_messages;
CREATE TRIGGER trg_touch_updated_at
  BEFORE UPDATE ON public.whatsapp_messages
  FOR EACH ROW EXECUTE FUNCTION public.fn_touch_updated_at();

-- --------------------------------------------------------------------------
-- B. Phone normalization
-- Strips every non-digit character then keeps the rightmost 10 digits, so
-- "+91 98765-43210", "919876543210" and "9876543210" all collapse to the
-- same "9876543210" join key regardless of how Meta/webhook/agent formatted
-- the number. Declared IMMUTABLE so it is usable inside an index expression.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.whatsapp_normalize_phone(p_raw TEXT)
RETURNS TEXT AS $$
DECLARE
    v_cleaned TEXT;
BEGIN
    IF p_raw IS NULL THEN
        RETURN NULL;
    END IF;

    -- Step 1: Strip all non-digit characters (+, spaces, hyphens, brackets)
    v_cleaned := regexp_replace(p_raw, '\D', '', 'g');

    -- Step 2: Extract right-most 10 digits
    IF length(v_cleaned) >= 10 THEN
        RETURN substring(v_cleaned from length(v_cleaned) - 9);
    ELSE
        RETURN v_cleaned; -- Fallback for short internal extensions/test numbers
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- --------------------------------------------------------------------------
-- C. Keep whatsapp_contacts_metadata.phone_number normalized on write
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_normalize_contact_phone()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.raw_phone_number := COALESCE(NEW.raw_phone_number, NEW.phone_number);
  NEW.phone_number := public.whatsapp_normalize_phone(NEW.raw_phone_number);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_normalize_contact_phone ON public.whatsapp_contacts_metadata;
CREATE TRIGGER trg_normalize_contact_phone
  BEFORE INSERT OR UPDATE OF raw_phone_number, phone_number ON public.whatsapp_contacts_metadata
  FOR EACH ROW EXECUTE FUNCTION public.fn_normalize_contact_phone();

-- --------------------------------------------------------------------------
-- D. Get-or-create contact + conversation for a raw phone number.
-- Single choke point used by (a) the inbound webhook trigger below, and
-- (b) any Edge Function/RPC that needs to resolve a conversation before
-- sending an outbound message. ON CONFLICT upserts make this race-safe
-- under concurrent webhook delivery.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_get_or_create_conversation(
  p_raw_phone    TEXT,
  p_display_name TEXT DEFAULT NULL
) RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
  v_normalized      TEXT;
  v_contact_id      UUID;
  v_conversation_id UUID;
  v_user_name       TEXT;
  v_user_id         BIGINT;
  v_resolved_name   TEXT;
BEGIN
  v_normalized := public.whatsapp_normalize_phone(p_raw_phone);

  -- 1. Try to find if there is a matching user in public.users
  SELECT id, user_name INTO v_user_id, v_user_name
  FROM public.users
  WHERE public.whatsapp_normalize_phone(number::text) = v_normalized
  LIMIT 1;

  -- 2. Resolve display name: user_name if matched user exists, otherwise webhook p_display_name
  IF v_user_id IS NOT NULL THEN
    v_resolved_name := v_user_name;
  ELSE
    v_resolved_name := p_display_name;
  END IF;

  -- 3. Upsert contact metadata
  INSERT INTO public.whatsapp_contacts_metadata (
    phone_number, 
    raw_phone_number, 
    display_name, 
    external_contact_id
  )
  VALUES (
    v_normalized, 
    p_raw_phone, 
    v_resolved_name, 
    v_user_id
  )
  ON CONFLICT (phone_number) 
  DO UPDATE SET 
    display_name = COALESCE(v_resolved_name, public.whatsapp_contacts_metadata.display_name),
    external_contact_id = COALESCE(v_user_id, public.whatsapp_contacts_metadata.external_contact_id),
    updated_at = now()
  RETURNING id INTO v_contact_id;

  -- 4. Upsert conversation
  INSERT INTO public.whatsapp_conversations (whatsapp_contact_id)
  VALUES (v_contact_id)
  ON CONFLICT (whatsapp_contact_id) DO UPDATE SET updated_at = now()
  RETURNING id INTO v_conversation_id;

  RETURN v_conversation_id;
END;
$$;

-- --------------------------------------------------------------------------
-- E. Resolve conversation_id on inbound message insert when not supplied.
-- The Meta webhook Edge Function inserts inbound rows with conversation_id
-- NULL and the sender's raw phone stashed in metadata->>'from_phone'; this
-- trigger transparently attaches (or creates) the correct conversation
-- instead of ever spawning a duplicate thread for the same number.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_resolve_message_conversation()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_raw_phone TEXT;
BEGIN
  IF NEW.conversation_id IS NULL THEN
    v_raw_phone := NEW.metadata ->> 'from_phone';
    IF v_raw_phone IS NULL OR length(trim(v_raw_phone)) = 0 THEN
      RAISE EXCEPTION
        'whatsapp_messages: conversation_id is NULL and metadata.from_phone is missing (message id=%)',
        NEW.id;
    END IF;
    NEW.conversation_id := public.fn_get_or_create_conversation(
      v_raw_phone,
      NEW.metadata ->> 'from_name'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_resolve_message_conversation ON public.whatsapp_messages;
CREATE TRIGGER trg_resolve_message_conversation
  BEFORE INSERT ON public.whatsapp_messages
  FOR EACH ROW EXECUTE FUNCTION public.fn_resolve_message_conversation();

-- --------------------------------------------------------------------------
-- F. Denormalization sync: every new message updates its parent conversation
-- row so the inbox list never has to aggregate whatsapp_messages at read
-- time. unread_count only increments for INBOUND traffic.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_sync_conversation_on_message()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  UPDATE public.whatsapp_conversations
  SET
    last_message_text = COALESCE(
      NEW.body, 
      CASE 
        WHEN NEW.message_type = 'media' THEN '[Attachment]'
        WHEN NEW.message_type = 'audio' THEN '🎵 Voice Note / Audio'
        WHEN NEW.message_type = 'location' THEN '📍 Location Shared'
        WHEN NEW.message_type = 'contacts' THEN '📇 Contact Card'
        WHEN NEW.message_type = 'reaction' THEN '📌 Reaction'
        ELSE '[' || NEW.message_type::text || ']'
      END
    ),
    last_message_at   = NEW.created_at,
    unread_count      = CASE WHEN NEW.direction = 'INBOUND' THEN unread_count + 1 ELSE unread_count END,
    updated_at        = now()
  WHERE id = NEW.conversation_id;

  -- If the message is inbound, update the Meta customer service session window (24 hours)
  IF NEW.direction = 'INBOUND' THEN
    UPDATE public.whatsapp_contacts_metadata
    SET meta_session_expires_at = now() + interval '24 hours',
        updated_at = now()
    WHERE id = (
      SELECT whatsapp_contact_id 
      FROM public.whatsapp_conversations 
      WHERE id = NEW.conversation_id
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_conversation_on_message ON public.whatsapp_messages;
CREATE TRIGGER trg_sync_conversation_on_message
  AFTER INSERT ON public.whatsapp_messages
  FOR EACH ROW EXECUTE FUNCTION public.fn_sync_conversation_on_message();

-- --------------------------------------------------------------------------
-- G. Denormalization sync: status history events update the conversation's
-- latest_status, but only when the event belongs to that conversation's
-- most recent message — an older message's late "delivered" webhook must
-- never stomp a newer message's status.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_sync_conversation_on_status()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_message RECORD;
BEGIN
  -- Update the base message's latest status
  UPDATE public.whatsapp_messages
  SET latest_status = NEW.status,
      updated_at    = now()
  WHERE id = NEW.message_id;

  SELECT conversation_id, created_at INTO v_message
  FROM public.whatsapp_messages
  WHERE id = NEW.message_id;

  IF v_message.conversation_id IS NOT NULL THEN
    UPDATE public.whatsapp_conversations c
    SET latest_status = NEW.status::text,
        updated_at    = now()
    WHERE c.id = v_message.conversation_id
      AND (c.last_message_at IS NULL OR c.last_message_at <= v_message.created_at);
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_conversation_on_status ON public.whatsapp_message_status_history;
CREATE TRIGGER trg_sync_conversation_on_status
  AFTER INSERT ON public.whatsapp_message_status_history
  FOR EACH ROW EXECUTE FUNCTION public.fn_sync_conversation_on_status();

-- --------------------------------------------------------------------------
-- H. Canonical outbound send RPC — see architecture note (§5) below.
-- Any decoupled internal service calls this instead of inserting into
-- whatsapp_messages directly, so conversation sync + realtime propagation
-- happen identically no matter which service originates the message.
-- SECURITY DEFINER means callers only need EXECUTE on this function, not
-- raw table INSERT rights.
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.fn_send_whatsapp_message(
  p_wamid           TEXT,
  p_conversation_id UUID,
  p_message_type    public.whatsapp_message_type,
  p_body            TEXT,
  p_template_id     UUID DEFAULT NULL,
  p_media_url       TEXT DEFAULT NULL,
  p_mime_type       TEXT DEFAULT NULL,
  p_metadata        JSONB DEFAULT '{}'::jsonb
) RETURNS public.whatsapp_messages
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_row public.whatsapp_messages;
BEGIN
  -- Insert or update (in case webhook status update arrived first and created a placeholder)
  INSERT INTO public.whatsapp_messages (
    id, conversation_id, direction, message_type, body, template_id, media_url, mime_type, metadata, latest_status
  ) VALUES (
    p_wamid, p_conversation_id, 'OUTBOUND', p_message_type, p_body, p_template_id, p_media_url, p_mime_type, p_metadata, 'sent'
  )
  ON CONFLICT (id) DO UPDATE SET
    conversation_id = EXCLUDED.conversation_id,
    direction = EXCLUDED.direction,
    message_type = EXCLUDED.message_type,
    body = EXCLUDED.body,
    template_id = EXCLUDED.template_id,
    media_url = EXCLUDED.media_url,
    mime_type = EXCLUDED.mime_type,
    metadata = EXCLUDED.metadata,
    latest_status = COALESCE(public.whatsapp_messages.latest_status, EXCLUDED.latest_status),
    updated_at = now()
  RETURNING * INTO v_row;

  IF NOT EXISTS (
    SELECT 1 FROM public.whatsapp_message_status_history
    WHERE message_id = v_row.id AND status = 'sent'
  ) THEN
    INSERT INTO public.whatsapp_message_status_history (message_id, status)
    VALUES (v_row.id, 'sent');
  END IF;

  RETURN v_row;
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_send_whatsapp_message TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.fn_get_or_create_conversation TO anon, authenticated, service_role;

-- ==========================================================================
-- SOFT DELETE LAYER
-- Postgres RULEs can auto-append a WHERE clause, but they are widely
-- discouraged for anything beyond trivial view-updates (surprising
-- interactions with triggers/RETURNING, hard to reason about). Row Level
-- Security is the Supabase-idiomatic equivalent: it transparently filters
-- every SELECT for anon/authenticated roles, while service_role (used by
-- Edge Functions/webhooks) bypasses RLS entirely for admin/recovery access.
-- ==========================================================================
ALTER TABLE public.whatsapp_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_contacts_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS whatsapp_templates_select_active ON public.whatsapp_templates;
CREATE POLICY whatsapp_templates_select_active ON public.whatsapp_templates
  FOR SELECT USING (deleted_at IS NULL);
DROP POLICY IF EXISTS whatsapp_templates_write ON public.whatsapp_templates;
CREATE POLICY whatsapp_templates_write ON public.whatsapp_templates
  FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS whatsapp_templates_update ON public.whatsapp_templates;
CREATE POLICY whatsapp_templates_update ON public.whatsapp_templates
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS whatsapp_contacts_select_active ON public.whatsapp_contacts_metadata;
CREATE POLICY whatsapp_contacts_select_active ON public.whatsapp_contacts_metadata
  FOR SELECT USING (deleted_at IS NULL);
DROP POLICY IF EXISTS whatsapp_contacts_write ON public.whatsapp_contacts_metadata;
CREATE POLICY whatsapp_contacts_write ON public.whatsapp_contacts_metadata
  FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS whatsapp_contacts_update ON public.whatsapp_contacts_metadata;
CREATE POLICY whatsapp_contacts_update ON public.whatsapp_contacts_metadata
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS whatsapp_conversations_select_active ON public.whatsapp_conversations;
CREATE POLICY whatsapp_conversations_select_active ON public.whatsapp_conversations
  FOR SELECT USING (deleted_at IS NULL);
DROP POLICY IF EXISTS whatsapp_conversations_write ON public.whatsapp_conversations;
CREATE POLICY whatsapp_conversations_write ON public.whatsapp_conversations
  FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS whatsapp_conversations_update ON public.whatsapp_conversations;
CREATE POLICY whatsapp_conversations_update ON public.whatsapp_conversations
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS whatsapp_messages_select_active ON public.whatsapp_messages;
CREATE POLICY whatsapp_messages_select_active ON public.whatsapp_messages
  FOR SELECT USING (deleted_at IS NULL);
DROP POLICY IF EXISTS whatsapp_messages_write ON public.whatsapp_messages;
CREATE POLICY whatsapp_messages_write ON public.whatsapp_messages
  FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS whatsapp_messages_update ON public.whatsapp_messages;
CREATE POLICY whatsapp_messages_update ON public.whatsapp_messages
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- NOTE: these write policies are intentionally permissive scaffolding.
-- Production hardening should scope INSERT/UPDATE by agent/department the
-- same way page_access/system_access already scope the checklist module.

-- ==========================================================================
-- INDEXING STRATEGY (millions-of-rows profile)
-- ==========================================================================

-- Composite: the single most-hit query — "give me this conversation's
-- messages, newest first" (paginated scroll-back in the chat stream).
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_conv_created
  ON public.whatsapp_messages (conversation_id, created_at DESC);

-- Partial: only active (non-soft-deleted) rows need to be scanned for the
-- live inbox — keeps the index small as deleted history accumulates.
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_active
  ON public.whatsapp_messages (conversation_id, created_at DESC)
  WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_parent
  ON public.whatsapp_messages (parent_message_id) WHERE parent_message_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_template
  ON public.whatsapp_messages (template_id) WHERE template_id IS NOT NULL;

-- Expression index mirroring whatsapp_normalize_phone(): lets the webhook
-- ingestion path look up a contact by any raw phone format in O(log n)
-- without depending on the caller having pre-normalized the string.
CREATE INDEX IF NOT EXISTS idx_whatsapp_contacts_local10
  ON public.whatsapp_contacts_metadata (public.whatsapp_normalize_phone(raw_phone_number));

-- Partial: phone lookups only ever care about non-deleted contacts.
CREATE INDEX IF NOT EXISTS idx_whatsapp_contacts_phone_active
  ON public.whatsapp_contacts_metadata (phone_number) WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_whatsapp_contacts_external
  ON public.whatsapp_contacts_metadata (external_contact_id);

CREATE INDEX IF NOT EXISTS idx_whatsapp_conversations_contact
  ON public.whatsapp_conversations (whatsapp_contact_id);

CREATE INDEX IF NOT EXISTS idx_whatsapp_conversations_last_message_at
  ON public.whatsapp_conversations (last_message_at DESC);

-- Partial: powers the sidebar's "Unread" / "Awaiting Reply" quick filters
-- without scanning fully-read conversations.
CREATE INDEX IF NOT EXISTS idx_whatsapp_conversations_unread
  ON public.whatsapp_conversations (last_message_at DESC) WHERE unread_count > 0;

CREATE INDEX IF NOT EXISTS idx_whatsapp_status_history_message
  ON public.whatsapp_message_status_history (message_id, changed_at DESC);

CREATE INDEX IF NOT EXISTS idx_whatsapp_error_logs_created
  ON public.whatsapp_error_logs (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_whatsapp_error_logs_source
  ON public.whatsapp_error_logs (error_source);

-- ==========================================================================
-- UNIFIED READ VIEW FOR THE REACT INBOX
-- Realtime caveat: Supabase Realtime's `postgres_changes` streams fire on
-- base TABLES, not views. Subscribe the React client directly to
-- whatsapp_conversations/whatsapp_messages for live deltas, and use this
-- view for the initial page load / pagination / search — merge the two
-- client-side (the same pattern the checklist module already uses for
-- notifications).
-- ==========================================================================
CREATE OR REPLACE VIEW public.vw_whatsapp_chat_inbox AS
SELECT
  conv.id                          AS conversation_id,
  conv.unread_count,
  conv.last_message_text,
  conv.last_message_at,
  conv.latest_status,
  contact.id                       AS whatsapp_contact_id,
  contact.phone_number,
  contact.raw_phone_number,
  contact.display_name,
  contact.meta_session_expires_at,
  (contact.meta_session_expires_at IS NOT NULL
     AND contact.meta_session_expires_at > now()) AS is_session_active,
  contact.external_contact_id,
  -- Placeholder join — replace with your real external Contacts table/columns.
  ext_user.user_name               AS external_contact_name,
  last_msg.id                      AS last_message_id,
  last_msg.direction               AS last_message_direction,
  last_msg.message_type            AS last_message_type,
  last_msg.mime_type               AS last_message_mime_type,
  last_msg.media_url               AS last_message_media_url,
  last_msg.is_forwarded            AS last_message_is_forwarded
FROM public.whatsapp_conversations conv
JOIN public.whatsapp_contacts_metadata contact
  ON contact.id = conv.whatsapp_contact_id AND contact.deleted_at IS NULL
LEFT JOIN public.users ext_user
  ON ext_user.id = contact.external_contact_id -- see header note
LEFT JOIN LATERAL (
  SELECT m.*
  FROM public.whatsapp_messages m
  WHERE m.conversation_id = conv.id AND m.deleted_at IS NULL
  ORDER BY m.created_at DESC
  LIMIT 1
) last_msg ON true
WHERE conv.deleted_at IS NULL
ORDER BY conv.last_message_at DESC NULLS LAST;

-- ==========================================================================
-- REALTIME CONFIGURATION
-- Enable Supabase Realtime for the WhatsApp CRM tables
-- ==========================================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.whatsapp_conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.whatsapp_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.whatsapp_message_status_history;
ALTER PUBLICATION supabase_realtime ADD TABLE public.whatsapp_contacts_metadata;

