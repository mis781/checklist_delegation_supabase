-- ======================================================
-- MIGRATION: Inventory Categories Table & Foreign Key Resolution
-- ======================================================

-- 1. Make category column nullable in inventory_materials
ALTER TABLE public.inventory_materials ALTER COLUMN category DROP NOT NULL;

-- 2. Drop existing FK constraint first to avoid dependency blocks
ALTER TABLE public.inventory_materials DROP CONSTRAINT IF EXISTS fk_inventory_materials_category;


-- 2. Create inventory_categories table with division column if not exists
CREATE TABLE IF NOT EXISTS public.inventory_categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    division TEXT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Ensure division column exists
ALTER TABLE public.inventory_categories ADD COLUMN IF NOT EXISTS division TEXT NULL;

-- 3. Drop legacy single-column constraint if present
ALTER TABLE public.inventory_categories DROP CONSTRAINT IF EXISTS inventory_categories_name_key CASCADE;

-- 4. Create unique index on category name to satisfy foreign key requirement
CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_categories_name ON public.inventory_categories(name);

-- 5. Auto-populate inventory_categories with existing categories from inventory_materials
INSERT INTO public.inventory_categories (name, division)
SELECT DISTINCT category, division 
FROM public.inventory_materials 
WHERE category IS NOT NULL AND TRIM(category) != ''
ON CONFLICT (name) DO NOTHING;

-- 6. Re-create Foreign Key linking inventory_materials(category) -> inventory_categories(name)
ALTER TABLE public.inventory_materials DROP CONSTRAINT IF EXISTS fk_inventory_materials_category;

ALTER TABLE public.inventory_materials
ADD CONSTRAINT fk_inventory_materials_category
FOREIGN KEY (category) REFERENCES public.inventory_categories(name)
ON UPDATE CASCADE ON DELETE SET NULL;


