-- ============================================================================
-- SQL Setup: Automatic Server-Side Cron Execution for Scheduled WhatsApp Broadcasts
-- Compatible with Supabase SQL Editor (Avoids CREATE EXTENSION pg_cron error)
-- ============================================================================

-- 1. Ensure HTTP net extension is enabled
CREATE EXTENSION IF NOT EXISTS pg_net;

-- 2. Safely unschedule previous job if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'whatsapp-broadcast-scheduler-cron') THEN
    PERFORM cron.unschedule('whatsapp-broadcast-scheduler-cron');
  END IF;
END $$;

-- 3. Schedule job to invoke whatsapp-recurring-cron every minute
SELECT cron.schedule(
    'whatsapp-broadcast-scheduler-cron',
    '* * * * *',
    $$
    SELECT net.http_post(
        url := 'https://' || current_setting('request.headers', true)::json->>'host' || '/functions/v1/whatsapp-recurring-cron',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer ' || COALESCE(current_setting('request.headers', true)::json->>'authorization', '')
        ),
        body := '{}'::jsonb
    );
    $$
);
