-- ==========================================================================
-- Migration: WhatsApp Message Status Ticks Sync
-- Run this in your Supabase SQL Editor to update your remote database schema.
-- ==========================================================================

-- 1. Add latest_status column to the base messages table if it doesn't exist
ALTER TABLE public.whatsapp_messages
ADD COLUMN IF NOT EXISTS latest_status public.whatsapp_message_status NULL;

-- 2. Update status sync trigger function to sync status to base message
CREATE OR REPLACE FUNCTION public.fn_sync_conversation_on_status()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_message RECORD;
BEGIN
  -- Update the base message's latest status
  UPDATE public.whatsapp_messages
  SET latest_status = NEW.status,
      updated_at    = now()
  WHERE id = NEW.message_id;

  SELECT conversation_id, created_at INTO v_message
  FROM public.whatsapp_messages
  WHERE id = NEW.message_id;

  IF v_message.conversation_id IS NOT NULL THEN
    UPDATE public.whatsapp_conversations c
    SET latest_status = NEW.status::text,
        updated_at    = now()
    WHERE c.id = v_message.conversation_id
      AND (c.last_message_at IS NULL OR c.last_message_at <= v_message.created_at);
  END IF;

  RETURN NEW;
END;
$$;

-- 3. Update the outbound message send RPC to use safe upsert (ON CONFLICT DO UPDATE)
CREATE OR REPLACE FUNCTION public.fn_send_whatsapp_message(
  p_wamid           TEXT,
  p_conversation_id UUID,
  p_message_type    public.whatsapp_message_type,
  p_body            TEXT,
  p_template_id     UUID DEFAULT NULL,
  p_media_url       TEXT DEFAULT NULL,
  p_mime_type       TEXT DEFAULT NULL,
  p_metadata        JSONB DEFAULT '{}'::jsonb
) RETURNS public.whatsapp_messages
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_row public.whatsapp_messages;
BEGIN
  -- Insert or update (in case webhook status update arrived first and created a placeholder)
  INSERT INTO public.whatsapp_messages (
    id, conversation_id, direction, message_type, body, template_id, media_url, mime_type, metadata, latest_status
  ) VALUES (
    p_wamid, p_conversation_id, 'OUTBOUND', p_message_type, p_body, p_template_id, p_media_url, p_mime_type, p_metadata, 'sent'
  )
  ON CONFLICT (id) DO UPDATE SET
    conversation_id = EXCLUDED.conversation_id,
    direction = EXCLUDED.direction,
    message_type = EXCLUDED.message_type,
    body = EXCLUDED.body,
    template_id = EXCLUDED.template_id,
    media_url = EXCLUDED.media_url,
    mime_type = EXCLUDED.mime_type,
    metadata = EXCLUDED.metadata,
    latest_status = COALESCE(public.whatsapp_messages.latest_status, EXCLUDED.latest_status),
    updated_at = now()
  RETURNING * INTO v_row;

  IF NOT EXISTS (
    SELECT 1 FROM public.whatsapp_message_status_history
    WHERE message_id = v_row.id AND status = 'sent'
  ) THEN
    INSERT INTO public.whatsapp_message_status_history (message_id, status)
    VALUES (v_row.id, 'sent');
  END IF;

  RETURN v_row;
END;
$$;

-- 4. Backfill latest_status for all existing messages from status history
UPDATE public.whatsapp_messages m
SET latest_status = h.status
FROM (
  SELECT DISTINCT ON (message_id) message_id, status
  FROM public.whatsapp_message_status_history
  ORDER BY message_id, changed_at DESC
) h
WHERE m.id = h.message_id;

-- 5. Add support for unhandled inbound formats (audio, location, contacts, reaction, sticker, unsupported)
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'audio';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'location';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'contacts';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'reaction';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'sticker';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'unsupported';

-- 6. Update trigger function for fallback descriptive placeholders
CREATE OR REPLACE FUNCTION public.fn_sync_conversation_on_message()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  UPDATE public.whatsapp_conversations
  SET
    last_message_text = COALESCE(
      NEW.body, 
      CASE 
        WHEN NEW.message_type = 'media' THEN '[Attachment]'
        WHEN NEW.message_type = 'audio' THEN '🎵 Voice Note / Audio'
        WHEN NEW.message_type = 'location' THEN '📍 Location Shared'
        WHEN NEW.message_type = 'contacts' THEN '📇 Contact Card'
        WHEN NEW.message_type = 'reaction' THEN '📌 Reaction'
        WHEN NEW.message_type = 'sticker' THEN '[Sticker]'
        WHEN NEW.message_type = 'unsupported' THEN '⚠️ Received unsupported format'
        ELSE '[' || NEW.message_type::text || ']'
      END
    ),
    last_message_at   = NEW.created_at,
    unread_count      = CASE WHEN NEW.direction = 'INBOUND' THEN unread_count + 1 ELSE unread_count END,
    updated_at        = now()
  WHERE id = NEW.conversation_id;

  -- Maintain the existing 24-hour customer session window logic
  IF NEW.direction = 'INBOUND' THEN
    UPDATE public.whatsapp_contacts_metadata
    SET meta_session_expires_at = now() + interval '24 hours',
        updated_at = now()
    WHERE id = (
      SELECT whatsapp_contact_id 
      FROM public.whatsapp_conversations 
      WHERE id = NEW.conversation_id
    );
  END IF;

  RETURN NEW;
END;
$$;

-- 7. Seed default message initiation template
INSERT INTO public.whatsapp_templates (element_name, category, language, body_text, status, header_type, buttons)
VALUES (
  'message_initiation',
  'UTILITY',
  'en',
  'Hello! Welcome to our portal. We have added you as a contact. Please reply to this message to confirm receipt and initiate our conversation.',
  'APPROVED',
  'NONE',
  '[]'::jsonb
)
ON CONFLICT (element_name) DO UPDATE SET
  category = EXCLUDED.category,
  language = EXCLUDED.language,
  body_text = EXCLUDED.body_text,
  status = EXCLUDED.status,
  header_type = EXCLUDED.header_type,
  buttons = EXCLUDED.buttons;

-- 8. Recalculate conversation last message on soft delete
CREATE OR REPLACE FUNCTION public.fn_recalculate_conversation_last_message()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  v_last RECORD;
BEGIN
  IF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL THEN
    SELECT * INTO v_last
    FROM public.whatsapp_messages
    WHERE conversation_id = NEW.conversation_id
      AND deleted_at IS NULL
    ORDER BY created_at DESC
    LIMIT 1;

    IF v_last.id IS NOT NULL THEN
      UPDATE public.whatsapp_conversations
      SET
        last_message_text = COALESCE(
          v_last.body, 
          CASE 
            WHEN v_last.message_type = 'media' THEN '[Attachment]'
            WHEN v_last.message_type = 'audio' THEN '🎵 Voice Note / Audio'
            WHEN v_last.message_type = 'location' THEN '📍 Location Shared'
            WHEN v_last.message_type = 'contacts' THEN '📇 Contact Card'
            WHEN v_last.message_type = 'reaction' THEN '📌 Reaction'
            WHEN v_last.message_type = 'sticker' THEN '[Sticker]'
            WHEN v_last.message_type = 'unsupported' THEN '⚠️ Received unsupported format'
            ELSE '[' || v_last.message_type::text || ']'
          END
        ),
        last_message_at   = v_last.created_at,
        latest_status     = v_last.latest_status::text,
        updated_at        = now()
      WHERE id = NEW.conversation_id;
    ELSE
      UPDATE public.whatsapp_conversations
      SET
        last_message_text = 'No messages',
        last_message_at   = NULL,
        latest_status     = NULL,
        updated_at        = now()
      WHERE id = NEW.conversation_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_recalculate_conversation_last_message ON public.whatsapp_messages;
CREATE TRIGGER trg_recalculate_conversation_last_message
  AFTER UPDATE OF deleted_at ON public.whatsapp_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_recalculate_conversation_last_message();

-- 9. Update vw_whatsapp_chat_inbox view to filter soft-deleted messages
CREATE OR REPLACE VIEW public.vw_whatsapp_chat_inbox AS
SELECT
  conv.id                          AS conversation_id,
  conv.unread_count,
  conv.last_message_text,
  conv.last_message_at,
  conv.latest_status,
  contact.id                       AS whatsapp_contact_id,
  contact.phone_number,
  contact.raw_phone_number,
  contact.display_name,
  contact.meta_session_expires_at,
  (contact.meta_session_expires_at IS NOT NULL
     AND contact.meta_session_expires_at > now()) AS is_session_active,
  contact.external_contact_id,
  ext_user.user_name               AS external_contact_name,
  last_msg.id                      AS last_message_id,
  last_msg.direction               AS last_message_direction,
  last_msg.message_type            AS last_message_type,
  last_msg.mime_type               AS last_message_mime_type,
  last_msg.media_url               AS last_message_media_url,
  last_msg.is_forwarded            AS last_message_is_forwarded
FROM public.whatsapp_conversations conv
JOIN public.whatsapp_contacts_metadata contact
  ON contact.id = conv.whatsapp_contact_id AND contact.deleted_at IS NULL
LEFT JOIN public.users ext_user
  ON ext_user.id = contact.external_contact_id
LEFT JOIN LATERAL (
  SELECT m.*
  FROM public.whatsapp_messages m
  WHERE m.conversation_id = conv.id AND m.deleted_at IS NULL
  ORDER BY m.created_at DESC
  LIMIT 1
) last_msg ON true
WHERE conv.deleted_at IS NULL
ORDER BY conv.last_message_at DESC NULLS LAST;

-- 10. Phone normalization function for Indian 10-digit edge cases (Right-to-Left substring logic)
CREATE OR REPLACE FUNCTION public.whatsapp_normalize_phone(p_raw TEXT)
RETURNS TEXT AS $$
DECLARE
    v_cleaned TEXT;
BEGIN
    IF p_raw IS NULL THEN
        RETURN NULL;
    END IF;

    -- Step 1: Strip all non-digit characters (+, spaces, hyphens, brackets)
    v_cleaned := regexp_replace(p_raw, '\D', '', 'g');

    -- Step 2: Extract right-most 10 digits
    IF length(v_cleaned) >= 10 THEN
        RETURN substring(v_cleaned from length(v_cleaned) - 9);
    ELSE
        RETURN v_cleaned; -- Fallback for short internal extensions/test numbers
    END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 11. Verification test suite for phone normalization
DO $$ DECLARE
    v_norm1 TEXT;
    v_norm2 TEXT;
    v_norm3 TEXT;
    v_norm4 TEXT;
BEGIN
    -- Test Case 1: 10-digit local number starting with '91'
    v_norm1 := public.whatsapp_normalize_phone('9165489512');
    
    -- Test Case 2: Same number with country code '91' prepended (12 digits total)
    v_norm2 := public.whatsapp_normalize_phone('919165489512');
    
    -- Test Case 3: Same number with '+91' and spaces
    v_norm3 := public.whatsapp_normalize_phone('+91 9165489512');
    
    -- Test Case 4: Standard 10-digit number starting with '98'
    v_norm4 := public.whatsapp_normalize_phone('+91 9876543210');
    
    -- Assertions
    IF v_norm1 <> '9165489512' THEN
        RAISE EXCEPTION 'FAILED Test 1: Expected 9165489512 but got %', v_norm1;
    END IF;

    IF v_norm2 <> '9165489512' THEN
        RAISE EXCEPTION 'FAILED Test 2: Expected 9165489512 but got %', v_norm2;
    END IF;

    IF v_norm3 <> '9165489512' THEN
        RAISE EXCEPTION 'FAILED Test 3: Expected 9165489512 but got %', v_norm3;
    END IF;

    IF v_norm4 <> '9876543210' THEN
        RAISE EXCEPTION 'FAILED Test 4: Expected 9876543210 but got %', v_norm4;
    END IF;

    RAISE NOTICE 'SUCCESS: Phone normalization right-most 10-digit logic is working perfectly!';
END $$;

-- ==========================================================================
-- Migration: WhatsApp Poll Support
-- Adds 'poll' enum value so outbound interactive list-based polls can be
-- stored with their own message_type in whatsapp_messages.
-- Run this in your Supabase SQL Editor.
-- ==========================================================================

ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'poll';

-- ==========================================================================
-- Migration: Raw Meta Webhook Recording Table
-- Stores unmodified incoming Meta webhook payloads for auditing & debugging.
-- ==========================================================================

CREATE TABLE IF NOT EXISTS public.whatsapp_raw_webhooks (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  received_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  message_type TEXT NULL,
  from_phone TEXT NULL,
  raw_payload JSONB NOT NULL
);

-- Index for fast queries ordered by date
CREATE INDEX IF NOT EXISTS idx_whatsapp_raw_webhooks_received_at
  ON public.whatsapp_raw_webhooks(received_at DESC);

-- Enable RLS & policies
ALTER TABLE public.whatsapp_raw_webhooks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow select on whatsapp_raw_webhooks"
  ON public.whatsapp_raw_webhooks
  FOR SELECT
  USING (true);

CREATE POLICY "Allow insert on whatsapp_raw_webhooks"
  ON public.whatsapp_raw_webhooks
  FOR INSERT
  WITH CHECK (true);

