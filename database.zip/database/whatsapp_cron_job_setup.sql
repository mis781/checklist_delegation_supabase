-- ==============================================================================
-- SUPABASE PG_CRON SETUP FOR AUTOMATED RECURRING WHATSAPP BROADCASTS
-- Project Ref: ztlhroslxqnzxdkedbcn
-- ==============================================================================

-- 1. Enable Required Extensions (Run in Supabase SQL Editor)
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- 2. Grant permissions to postgres role
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- 3. Unschedule existing job if already created (Prevents duplicate cron jobs)
SELECT cron.unschedule('whatsapp_recurring_broadcast_cron') 
WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'whatsapp_recurring_broadcast_cron');

-- 4. Schedule the cron job to trigger whatsapp-recurring-cron Edge Function every 1 minute
SELECT cron.schedule(
  'whatsapp_recurring_broadcast_cron',  -- Unique Cron Job Name
  '* * * * *',                          -- Schedule: Every 1 minute (* * * * *)
  $$
  SELECT net.http_post(
      url := 'https://ztlhroslxqnzxdkedbcn.supabase.co/functions/v1/whatsapp-recurring-cron',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := '{}'::jsonb
  );
  $$
);

-- ==============================================================================
-- HELPER QUERIES FOR MANAGEMENT & MONITORING
-- ==============================================================================

-- Check active scheduled cron jobs:
-- SELECT * FROM cron.job;

-- Check cron execution logs & HTTP response status:
-- SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 20;

-- To pause or stop this cron job in future:
-- SELECT cron.unschedule('whatsapp_recurring_broadcast_cron');
