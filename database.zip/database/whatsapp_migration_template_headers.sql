-- ==========================================================================
-- Migration: Template HEADER/FOOTER/BUTTONS support
-- Run this in your Supabase SQL Editor. Safe to re-run (idempotent).
-- ==========================================================================

-- Additive columns for the HEADER/FOOTER/BUTTONS support — safe to
-- re-run against an already-deployed table that predates these columns.
ALTER TABLE public.whatsapp_templates
    ADD COLUMN IF NOT EXISTS header_type TEXT NOT NULL DEFAULT 'NONE',
    ADD COLUMN IF NOT EXISTS header_text TEXT NULL,
    ADD COLUMN IF NOT EXISTS header_sample_url TEXT NULL,
    ADD COLUMN IF NOT EXISTS footer_text TEXT NULL,
    ADD COLUMN IF NOT EXISTS buttons JSONB NOT NULL DEFAULT '[]'::jsonb;

DO $$ BEGIN
  ALTER TABLE public.whatsapp_templates
    ADD CONSTRAINT whatsapp_templates_header_type_check
    CHECK (header_type IN ('NONE', 'TEXT', 'IMAGE', 'VIDEO', 'DOCUMENT'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
