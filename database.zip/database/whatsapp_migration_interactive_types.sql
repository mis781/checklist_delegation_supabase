-- ==============================================================================
-- MIGRATION: ADD INTERACTIVE & INBOUND TYPES TO whatsapp_message_type ENUM
-- Run this in Supabase SQL Editor if whatsapp_message_type is an ENUM type.
-- ==============================================================================

ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'button_reply';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'list_reply';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'flow_response';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'order';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'system';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'BUTTON_REPLY';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'LIST_REPLY';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'FLOW_RESPONSE';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'ORDER';
ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'SYSTEM';
