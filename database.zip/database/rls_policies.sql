-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES FOR CHECKLIST & INVENTORY SCHEMAS
-- Targeted Tables from:
--   1. database/checklist_schema.sql
--   2. database/inventory_categories_schema.sql
-- ==============================================================================

-- ==============================================================================
-- 1. INVENTORY CATEGORIES TABLE (from inventory_categories_schema.sql)
-- ==============================================================================

-- Enable RLS
ALTER TABLE public.inventory_categories ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow read access to inventory_categories for anon and authenticated users" ON public.inventory_categories;
DROP POLICY IF EXISTS "Allow write access to inventory_categories for authenticated users" ON public.inventory_categories;
DROP POLICY IF EXISTS "Allow full access to inventory_categories for anon and authenticated" ON public.inventory_categories;

-- Create Policies
CREATE POLICY "Allow read access to inventory_categories for all users" 
ON public.inventory_categories 
FOR SELECT 
TO anon, authenticated 
USING (true);

CREATE POLICY "Allow insert access to inventory_categories for authenticated users" 
ON public.inventory_categories 
FOR INSERT 
TO authenticated, anon 
WITH CHECK (true);

CREATE POLICY "Allow update access to inventory_categories for authenticated users" 
ON public.inventory_categories 
FOR UPDATE 
TO authenticated, anon 
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow delete access to inventory_categories for authenticated users" 
ON public.inventory_categories 
FOR DELETE 
TO authenticated, anon 
USING (true);


-- ==============================================================================
-- 2. CHECKLIST SYSTEM TABLES (from checklist_schema.sql)
-- ==============================================================================

--------------------------------------------------------------------------------
-- Table: public.assign_from
--------------------------------------------------------------------------------
ALTER TABLE public.assign_from ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read assign_from" ON public.assign_from;
DROP POLICY IF EXISTS "Allow all assign_from" ON public.assign_from;

CREATE POLICY "Allow read assign_from" ON public.assign_from FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert assign_from" ON public.assign_from FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update assign_from" ON public.assign_from FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete assign_from" ON public.assign_from FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.checklist
--------------------------------------------------------------------------------
ALTER TABLE public.checklist ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read checklist" ON public.checklist;
DROP POLICY IF EXISTS "Allow write checklist" ON public.checklist;

CREATE POLICY "Allow read checklist" ON public.checklist FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert checklist" ON public.checklist FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update checklist" ON public.checklist FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete checklist" ON public.checklist FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.delegation
--------------------------------------------------------------------------------
ALTER TABLE public.delegation ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read delegation" ON public.delegation;
DROP POLICY IF EXISTS "Allow write delegation" ON public.delegation;

CREATE POLICY "Allow read delegation" ON public.delegation FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert delegation" ON public.delegation FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update delegation" ON public.delegation FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete delegation" ON public.delegation FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.delegation_done
--------------------------------------------------------------------------------
ALTER TABLE public.delegation_done ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read delegation_done" ON public.delegation_done;
DROP POLICY IF EXISTS "Allow write delegation_done" ON public.delegation_done;

CREATE POLICY "Allow read delegation_done" ON public.delegation_done FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert delegation_done" ON public.delegation_done FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update delegation_done" ON public.delegation_done FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete delegation_done" ON public.delegation_done FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.departments
--------------------------------------------------------------------------------
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read departments" ON public.departments;
DROP POLICY IF EXISTS "Allow write departments" ON public.departments;

CREATE POLICY "Allow read departments" ON public.departments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert departments" ON public.departments FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update departments" ON public.departments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete departments" ON public.departments FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.dropdown_options
--------------------------------------------------------------------------------
ALTER TABLE public.dropdown_options ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read dropdown_options" ON public.dropdown_options;
DROP POLICY IF EXISTS "Allow write dropdown_options" ON public.dropdown_options;

CREATE POLICY "Allow read dropdown_options" ON public.dropdown_options FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert dropdown_options" ON public.dropdown_options FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update dropdown_options" ON public.dropdown_options FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete dropdown_options" ON public.dropdown_options FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.ea_tasks
--------------------------------------------------------------------------------
ALTER TABLE public.ea_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read ea_tasks" ON public.ea_tasks;
DROP POLICY IF EXISTS "Allow write ea_tasks" ON public.ea_tasks;

CREATE POLICY "Allow read ea_tasks" ON public.ea_tasks FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert ea_tasks" ON public.ea_tasks FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update ea_tasks" ON public.ea_tasks FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete ea_tasks" ON public.ea_tasks FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.ea_tasks_done
--------------------------------------------------------------------------------
ALTER TABLE public.ea_tasks_done ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read ea_tasks_done" ON public.ea_tasks_done;
DROP POLICY IF EXISTS "Allow write ea_tasks_done" ON public.ea_tasks_done;

CREATE POLICY "Allow read ea_tasks_done" ON public.ea_tasks_done FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert ea_tasks_done" ON public.ea_tasks_done FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update ea_tasks_done" ON public.ea_tasks_done FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete ea_tasks_done" ON public.ea_tasks_done FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.holidays
--------------------------------------------------------------------------------
ALTER TABLE public.holidays ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read holidays" ON public.holidays;
DROP POLICY IF EXISTS "Allow write holidays" ON public.holidays;

CREATE POLICY "Allow read holidays" ON public.holidays FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert holidays" ON public.holidays FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update holidays" ON public.holidays FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete holidays" ON public.holidays FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.maintenance_tasks
--------------------------------------------------------------------------------
ALTER TABLE public.maintenance_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read maintenance_tasks" ON public.maintenance_tasks;
DROP POLICY IF EXISTS "Allow write maintenance_tasks" ON public.maintenance_tasks;

CREATE POLICY "Allow read maintenance_tasks" ON public.maintenance_tasks FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert maintenance_tasks" ON public.maintenance_tasks FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update maintenance_tasks" ON public.maintenance_tasks FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete maintenance_tasks" ON public.maintenance_tasks FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.notifications
--------------------------------------------------------------------------------
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read notifications" ON public.notifications;
DROP POLICY IF EXISTS "Allow write notifications" ON public.notifications;

CREATE POLICY "Allow read notifications" ON public.notifications FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert notifications" ON public.notifications FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update notifications" ON public.notifications FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete notifications" ON public.notifications FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.repair_tasks
--------------------------------------------------------------------------------
ALTER TABLE public.repair_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read repair_tasks" ON public.repair_tasks;
DROP POLICY IF EXISTS "Allow write repair_tasks" ON public.repair_tasks;

CREATE POLICY "Allow read repair_tasks" ON public.repair_tasks FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert repair_tasks" ON public.repair_tasks FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update repair_tasks" ON public.repair_tasks FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete repair_tasks" ON public.repair_tasks FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.user_notifications
--------------------------------------------------------------------------------
ALTER TABLE public.user_notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read user_notifications" ON public.user_notifications;
DROP POLICY IF EXISTS "Allow write user_notifications" ON public.user_notifications;

CREATE POLICY "Allow read user_notifications" ON public.user_notifications FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert user_notifications" ON public.user_notifications FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update user_notifications" ON public.user_notifications FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete user_notifications" ON public.user_notifications FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.users
--------------------------------------------------------------------------------
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read users" ON public.users;
DROP POLICY IF EXISTS "Allow write users" ON public.users;

CREATE POLICY "Allow read users" ON public.users FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert users" ON public.users FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update users" ON public.users FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete users" ON public.users FOR DELETE TO anon, authenticated USING (true);


--------------------------------------------------------------------------------
-- Table: public.working_day_calender
--------------------------------------------------------------------------------
ALTER TABLE public.working_day_calender ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow read working_day_calender" ON public.working_day_calender;
DROP POLICY IF EXISTS "Allow write working_day_calender" ON public.working_day_calender;

CREATE POLICY "Allow read working_day_calender" ON public.working_day_calender FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Allow insert working_day_calender" ON public.working_day_calender FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Allow update working_day_calender" ON public.working_day_calender FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Allow delete working_day_calender" ON public.working_day_calender FOR DELETE TO anon, authenticated USING (true);

-- ==============================================================================
-- END OF RLS POLICIES SCRIPT
-- ==============================================================================
