-- SQL Migration for Recurring WhatsApp Broadcast Schedules
-- Run this script in the Supabase SQL Editor

ALTER TABLE public.whatsapp_broadcast_schedules 
  ADD COLUMN IF NOT EXISTS frequency VARCHAR(50),
  ADD COLUMN IF NOT EXISTS start_date TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS end_date TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS last_run_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS next_run_at TIMESTAMPTZ;

-- Update check constraint on send_type to allow 'recurring'
ALTER TABLE public.whatsapp_broadcast_schedules 
  DROP CONSTRAINT IF EXISTS whatsapp_broadcast_schedules_send_type_check;

ALTER TABLE public.whatsapp_broadcast_schedules 
  ADD CONSTRAINT whatsapp_broadcast_schedules_send_type_check 
  CHECK (send_type IN ('send', 'schedule', 'recurring'));

-- Index for cron execution performance
CREATE INDEX IF NOT EXISTS idx_broadcast_schedules_next_run 
  ON public.whatsapp_broadcast_schedules (status, next_run_at) 
  WHERE status = 'active';
