-- ==========================================================================
-- Migration: WhatsApp CRM Webhook Audits & Feature Extensions
-- Adds support for product_inquiry, catalog, order, and event message types
-- Adds marketing_opt_out column on whatsapp_contacts_metadata
-- ==========================================================================

DO $$ BEGIN
  ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'order';
  ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'product_inquiry';
  ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'catalog';
  ALTER TYPE public.whatsapp_message_type ADD VALUE IF NOT EXISTS 'event';
EXCEPTION WHEN OTHERS THEN NULL; END $$;

-- Add marketing_opt_out flag to whatsapp_contacts_metadata for Error 131026/131050 handling
ALTER TABLE public.whatsapp_contacts_metadata 
  ADD COLUMN IF NOT EXISTS marketing_opt_out BOOLEAN NOT NULL DEFAULT false;

-- Indexes to optimize querying edited messages, error messages, and opted-out contacts
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_is_edited 
  ON public.whatsapp_messages ((metadata->>'is_edited')) 
  WHERE (metadata->>'is_edited') = 'true';

CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_has_error 
  ON public.whatsapp_messages ((metadata->>'has_error')) 
  WHERE (metadata->>'has_error') = 'true';

CREATE INDEX IF NOT EXISTS idx_whatsapp_contacts_opt_out 
  ON public.whatsapp_contacts_metadata (marketing_opt_out) 
  WHERE marketing_opt_out = true;
