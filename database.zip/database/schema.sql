-- ==========================================
-- Database Schema for Inventory Management System (IMS) & FMS Integration
-- Designed for Supabase / PostgreSQL
-- ==========================================

-- 1. Custom Lists: Units of Measurement (UoM)
CREATE TABLE IF NOT EXISTS public.inventory_units (
    id SERIAL PRIMARY KEY,
    unit TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Custom Lists: Storage Locations / Warehouses
CREATE TABLE IF NOT EXISTS public.inventory_locations (
    id SERIAL PRIMARY KEY,
    location TEXT UNIQUE NOT NULL,
    division TEXT NULL, -- Firm / Division
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Custom Lists: Inventory Categories
CREATE TABLE IF NOT EXISTS public.inventory_categories (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    division TEXT NULL,
    material_type TEXT DEFAULT 'ALL' CHECK (material_type IN ('RM', 'FG', 'SPARE', 'ALL')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4a. Raw Materials Master Table (Catalog)
CREATE TABLE IF NOT EXISTS public.inventory_raw_materials (
    id SERIAL PRIMARY KEY,
    sku TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    status TEXT DEFAULT 'Active' NOT NULL CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_raw_materials_sku ON public.inventory_raw_materials(sku);

-- 4b. Finished Goods Master Table (Catalog)
CREATE TABLE IF NOT EXISTS public.inventory_finished_goods (
    id SERIAL PRIMARY KEY,
    sku TEXT NULL,           -- SKU Code (optional/custom)
    name TEXT NOT NULL,
    category TEXT NULL,      -- Classification / Category (e.g., 'Finished Goods', 'Sub-Assembly')
    division TEXT NULL,      -- Scoped Firm / Division (optional)
    status TEXT DEFAULT 'Active' NOT NULL CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_finished_goods_category ON public.inventory_finished_goods(category);
CREATE INDEX IF NOT EXISTS idx_finished_goods_division ON public.inventory_finished_goods(division);
CREATE INDEX IF NOT EXISTS idx_finished_goods_sku ON public.inventory_finished_goods(sku);

-- 4c. Active Materials Master Table (Stock Items with Opening Stock)
CREATE TABLE IF NOT EXISTS public.inventory_materials (
    id SERIAL PRIMARY KEY,
    sku TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    sub_category TEXT NULL,
    material_type TEXT NOT NULL DEFAULT 'RM' CHECK (material_type IN ('RM', 'FG', 'WIP', 'SPARE')),
    unit TEXT NOT NULL DEFAULT 'KG',
    location TEXT NULL,
    division TEXT NULL, -- Scoped Firm / Division
    opening NUMERIC DEFAULT 0 NOT NULL,
    adc NUMERIC DEFAULT 0 NOT NULL, -- Average Daily Consumption
    lead_time INTEGER DEFAULT 0 NOT NULL, -- Lead Time in Days
    safety_factor NUMERIC DEFAULT 0 NOT NULL,
    moq NUMERIC DEFAULT 0 NOT NULL, -- Minimum Order Quantity
    supplier_name TEXT NULL,
    supplier_code TEXT NULL,
    status TEXT DEFAULT 'Active' NOT NULL CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for fast material search and category filtering
CREATE INDEX IF NOT EXISTS idx_materials_sku ON public.inventory_materials(sku);
CREATE INDEX IF NOT EXISTS idx_materials_category ON public.inventory_materials(category);
CREATE INDEX IF NOT EXISTS idx_materials_location ON public.inventory_materials(location);
CREATE INDEX IF NOT EXISTS idx_materials_division ON public.inventory_materials(division);
CREATE INDEX IF NOT EXISTS idx_materials_material_type ON public.inventory_materials(material_type);

-- 5. Transactions Ledger (Stock Ledger)
CREATE TABLE IF NOT EXISTS public.inventory_transactions (
    id TEXT PRIMARY KEY, -- Formatted sequence: TXN-00001, TXN-00002, etc.
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    sku TEXT NOT NULL,
    name TEXT NOT NULL,
    material_type TEXT NOT NULL DEFAULT 'RM',
    qty NUMERIC NOT NULL,
    scraps NUMERIC DEFAULT 0,
    type TEXT NOT NULL CHECK (type IN ('IN', 'OUT', 'INWARD', 'OUTWARD', 'SCRAP', 'ADJUSTMENT')),
    ref TEXT NULL, -- Reference order number, e.g., GRN-1234, WO-5678
    remarks TEXT NULL,
    user_name TEXT NULL,
    firm TEXT NULL,
    is_job_card BOOLEAN DEFAULT FALSE,
    job_card_id TEXT NULL,
    fg_sku TEXT NULL,
    billing_date DATE NULL,
    receiving_date DATE NULL,
    party_name TEXT NULL,
    destination TEXT NULL,
    challan_no TEXT NULL,
    invoice_no TEXT NULL,
    vehicle_no TEXT NULL,
    fg_category TEXT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_sku ON public.inventory_transactions(sku);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON public.inventory_transactions(date);

-- 6. Job Card Batches (Production Batch Tracking)
CREATE TABLE IF NOT EXISTS public.inventory_job_card_batches (
    id SERIAL PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES public.inventory_transactions(id) ON DELETE CASCADE,
    batch_number INTEGER NOT NULL,
    sku TEXT NOT NULL,
    material_name TEXT NOT NULL,
    qty NUMERIC NOT NULL,
    num_batches INTEGER NULL,
    remaining_batches INTEGER NULL,
    remaining_material NUMERIC NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Indents (Material Requisitions)
CREATE TABLE IF NOT EXISTS public.inventory_indents (
    indent_no TEXT PRIMARY KEY, -- Formatted sequence: IND-00001, IND-00002, etc.
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    requested_by TEXT NOT NULL,
    department TEXT NOT NULL,
    items JSONB DEFAULT '[]'::jsonb, -- Requisition line items array
    remarks TEXT NULL,
    status TEXT DEFAULT 'Pending' NOT NULL CHECK (status IN ('Pending', 'Approved', 'Rejected', 'Order Placed', 'Fulfilled', 'Cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_indents_status ON public.inventory_indents(status);

-- 8. System Settings
CREATE TABLE IF NOT EXISTS public.inventory_settings (
    id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    page_size_master INTEGER DEFAULT 6 NOT NULL,
    page_size_txn INTEGER DEFAULT 6 NOT NULL,
    page_size_stock INTEGER DEFAULT 6 NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Audit Log Trail
CREATE TABLE IF NOT EXISTS public.inventory_audit (
    id BIGSERIAL PRIMARY KEY,
    ts TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    action TEXT NOT NULL,
    user_name TEXT,
    detail TEXT
);

CREATE INDEX IF NOT EXISTS idx_inventory_audit_ts ON public.inventory_audit(ts DESC);

-- 10. User Table Location Field Alteration
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS location TEXT NULL;
