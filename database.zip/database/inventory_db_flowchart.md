# Inventory Management System (IMS) — Database Flowchart & ERD Documentation

This document provides a comprehensive overview of the database schema, entity relationships, and data flow architecture for the **Inventory Management System (IMS)** backed by Supabase / PostgreSQL.

---

## 1. Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    DIVISIONS ||--o{ INVENTORY_LOCATIONS : "scopes"
    DIVISIONS ||--o{ INVENTORY_CATEGORIES : "scopes"
    DIVISIONS ||--o{ INVENTORY_MATERIALS : "filters"
    
    INVENTORY_CATEGORIES ||--o{ INVENTORY_MATERIALS : "classifies (FK: category -> name)"
    INVENTORY_UNITS ||--o{ INVENTORY_MATERIALS : "defines UoM"
    INVENTORY_LOCATIONS ||--o{ INVENTORY_MATERIALS : "stores in location"
    
    INVENTORY_MATERIALS ||--o{ INVENTORY_TRANSACTIONS : "logs ledger (FK: sku -> sku)"
    INVENTORY_MATERIALS ||--o{ INVENTORY_INDENTS : "raises requisitions (FK: sku -> sku)"

    USERS ||--o{ INVENTORY_TRANSACTIONS : "executes transaction"
    USERS ||--o{ INVENTORY_INDENTS : "requests indent"
    USERS ||--o{ INVENTORY_AUDIT : "triggers audit trail"

    INVENTORY_CATEGORIES {
        int id PK
        string name UK "Category Title"
        string division "Firm/Division"
        timestamp created_at
    }

    INVENTORY_UNITS {
        int id PK
        string unit UK "Measurement Symbol (e.g. KG, PCS)"
        timestamp created_at
    }

    INVENTORY_LOCATIONS {
        int id PK
        string location UK "Warehouse Rack/Bin Code"
        string division "Firm/Division"
        timestamp created_at
    }

    INVENTORY_MATERIALS {
        string sku PK "Stock Keeping Unit"
        string name "Material Name"
        string category FK "References inventory_categories(name)"
        string sub_category "Sub-Category"
        string unit "Unit Symbol"
        string location "Storage Location"
        string division "Firm/Division"
        numeric opening "Initial Stock"
        numeric adc "Average Daily Consumption"
        int lead_time "Lead Time in Days"
        numeric safety_factor "Safety Factor multiplier"
        numeric moq "Minimum Order Quantity"
        string supplier_name "Supplier Name"
        string supplier_code "Supplier Code"
        string status "Active / Inactive"
        timestamp created_at
        timestamp updated_at
    }

    INVENTORY_TRANSACTIONS {
        string id PK "TXN Sequence (e.g. TXN-00001)"
        date date "Transaction Date"
        string sku FK "References inventory_materials(sku)"
        string name "Material Name snapshot"
        numeric qty "Movement Quantity"
        numeric scraps "Scrap Quantity"
        string type "IN / OUT"
        string ref "Reference No (GRN / WO)"
        string remarks "Notes"
        string user_name "Performed By User"
        string firm "Firm/Division"
        boolean is_job_card "Job Card Flag"
        timestamp created_at
    }

    INVENTORY_INDENTS {
        string indent_no PK "Indent Sequence (e.g. IND-0001)"
        date date "Indent Date"
        string requested_by "User Name"
        string department "Department"
        string sku FK "References inventory_materials(sku)"
        string name "Material Name"
        numeric current_stock "Stock Level at Request Time"
        numeric reorder_qty "Quantity Requested"
        string supplier_name "Supplier Name"
        string status "Pending / Approved / Rejected"
        timestamp created_at
    }

    INVENTORY_SETTINGS {
        int id PK "Singleton ID = 1"
        int page_size_master "Master Pagination Size"
        int page_size_txn "Txn Pagination Size"
        int page_size_stock "Stock Pagination Size"
        timestamp updated_at
    }

    INVENTORY_AUDIT {
        bigint id PK
        timestamp ts "Timestamp"
        string action "Action Description"
        string user_name "User Name"
        string detail "Event Log Detail"
    }

    DIVISIONS {
        int id PK
        string name UK "Division / Firm Name"
    }

    USERS {
        string user_name PK
        string role "Admin / User / Viewer"
        string department "Department Name"
        string location "Warehouse Location Scope"
        string division "Firm Scope"
    }
```

---

## 2. Inventory Data Flow Architecture (DFD)

```mermaid
flowchart TD
    subgraph Master_Data_Setup["1. Master Data Configuration (Global Settings)"]
        A[Admin User] -->|Defines| B(inventory_categories)
        A -->|Defines| C(inventory_units)
        A -->|Defines| D(inventory_locations)
        A -->|Scopes by| E(divisions / Firms)
    end

    subgraph Material_Catalog["2. Material Master Management"]
        B & C & D -->|Provides Constraints to| F[inventory_materials]
        F -->|Defines| G["Material SKU, ADC, MOQ, Lead Time, Safety Factor"]
    end

    subgraph Stock_Operations["3. Daily Stock Transactions & Ledger"]
        H[Warehouse Operator] -->|Records IN / OUT Movement| I[inventory_transactions]
        I -->|ON DELETE CASCADE| F
        I -->|Calculates| J["Current Live Stock = Opening + SUM(IN) - SUM(OUT)"]
    end

    subgraph Requisition_Workflow["4. Auto Reorder & Indent Workflow"]
        J -->|Triggers Alert when Stock <= Reorder Level| K[Reorder Suggestion Engine]
        K -->|Raises Requisition| L[inventory_indents]
        L -->|Approves / Rejects| M[HOD / Admin Approval]
    end

    subgraph Audit_System["5. Audit Trail & Logging"]
        A & H & M -->|Every Add / Edit / Delete Action| N[inventory_audit]
    end
```

---

## 3. Database Table Definitions

### 1. `inventory_categories` (Master Data)
Stores product & material categories. Mapped optionally to specific **Firms (Divisions)**.
- **Columns**:
  - `id` (SERIAL PRIMARY KEY)
  - `name` (TEXT NOT NULL)
  - `division` (TEXT NULL) — References `divisions.name`
  - `created_at` (TIMESTAMPTZ DEFAULT NOW())
- **Constraints**:
  - `UNIQUE(name, division)`

### 2. `inventory_units` (Master Data)
Stores measurement units (e.g. `KG`, `PCS`, `MTR`, `LTR`, `BOX`).
- **Columns**:
  - `id` (SERIAL PRIMARY KEY)
  - `unit` (TEXT UNIQUE NOT NULL)
  - `created_at` (TIMESTAMPTZ DEFAULT NOW())

### 3. `inventory_locations` (Master Data)
Stores warehouse rack, bin, or zone storage location codes mapped to Firms.
- **Columns**:
  - `id` (SERIAL PRIMARY KEY)
  - `location` (TEXT UNIQUE NOT NULL)
  - `division` (TEXT NULL) — References `divisions.name`
  - `created_at` (TIMESTAMPTZ DEFAULT NOW())

### 4. `inventory_materials` (Core Material Master Table)
The main SKU-keyed catalog table for raw materials, finished goods, and components.
- **Columns**:
  - `sku` (TEXT PRIMARY KEY) — Stock Keeping Unit ID (e.g. `SKU-001`)
  - `name` (TEXT NOT NULL) — Standardized material title
  - `category` (TEXT NOT NULL) — References `inventory_categories(name)`
  - `sub_category` (TEXT NULL)
  - `unit` (TEXT NOT NULL) — References `inventory_units(unit)`
  - `location` (TEXT NULL) — References `inventory_locations(location)`
  - `division` (TEXT NULL) — References `divisions(name)`
  - `opening` (NUMERIC DEFAULT 0) — Initial starting balance
  - `adc` (NUMERIC DEFAULT 0) — Average Daily Consumption
  - `lead_time` (INTEGER DEFAULT 0) — Lead time in days
  - `safety_factor` (NUMERIC DEFAULT 0) — Safety factor multiplier
  - `moq` (NUMERIC DEFAULT 0) — Minimum Order Quantity
  - `supplier_name` (TEXT NULL)
  - `supplier_code` (TEXT NULL)
  - `status` (TEXT CHECK `status IN ('Active', 'Inactive')`)
- **Foreign Keys**:
  - `fk_inventory_materials_category`: `category -> inventory_categories(name) ON UPDATE CASCADE ON DELETE RESTRICT`

### 5. `inventory_transactions` (Stock Ledger)
Real-time stock ledger recording `IN` (receivings) and `OUT` (dispatches/consumption).
- **Columns**:
  - `id` (TEXT PRIMARY KEY) — e.g. `TXN-00001`
  - `date` (DATE DEFAULT CURRENT_DATE)
  - `sku` (TEXT NOT NULL) — References `inventory_materials(sku) ON DELETE CASCADE`
  - `name` (TEXT NOT NULL) — Material name snapshot
  - `qty` (NUMERIC CHECK `qty > 0`) — Transaction quantity
  - `scraps` (NUMERIC DEFAULT 0) — Scrap quantity
  - `type` (TEXT CHECK `type IN ('IN', 'OUT')`)
  - `ref` (TEXT NULL) — GRN number, Work Order number, Job Card ID
  - `remarks` (TEXT NULL)
  - `user_name` (TEXT NULL) — User who executed transaction
  - `firm` (TEXT NULL) — Firm/Division name
  - `is_job_card` (BOOLEAN DEFAULT false)

### 6. `inventory_indents` (Material Requisitions)
Tracks purchase requisitions raised when stock falls near or below reorder levels.
- **Columns**:
  - `indent_no` (TEXT PRIMARY KEY) — e.g. `IND-0001`
  - `date` (DATE DEFAULT CURRENT_DATE)
  - `requested_by` (TEXT NOT NULL)
  - `department` (TEXT NOT NULL)
  - `sku` (TEXT NOT NULL) — References `inventory_materials(sku) ON DELETE CASCADE`
  - `name` (TEXT NOT NULL)
  - `current_stock` (NUMERIC DEFAULT 0)
  - `reorder_qty` (NUMERIC DEFAULT 0)
  - `supplier_name` (TEXT NULL)
  - `status` (TEXT CHECK `status IN ('Pending', 'Approved', 'Rejected')`)

### 7. `inventory_settings` (UI Preferences)
Singleton configuration row (`id = 1`) storing user pagination preferences.
- **Columns**:
  - `id` (INTEGER PRIMARY KEY CHECK `id = 1`)
  - `page_size_master` (INTEGER DEFAULT 6)
  - `page_size_txn` (INTEGER DEFAULT 6)
  - `page_size_stock` (INTEGER DEFAULT 6)

### 8. `inventory_audit` (Audit Trail)
Immutable audit log for security, change tracking, and compliance.
- **Columns**:
  - `id` (BIGSERIAL PRIMARY KEY)
  - `ts` (TIMESTAMPTZ DEFAULT NOW())
  - `action` (TEXT NOT NULL) — Action title
  - `user_name` (TEXT NULL) — User who performed action
  - `detail` (TEXT NULL) — Event log details

---

## 4. Key Calculation Formulas

1. **Live Current Stock**:
   $$\text{Live Stock} = \text{Opening} + \sum \text{Qty}(\text{IN}) - \sum \text{Qty}(\text{OUT})$$

2. **Safety Stock**:
   $$\text{Safety Stock} = \text{ADC} \times \text{Safety Factor}$$

3. **Reorder Level (ROL)**:
   $$\text{Reorder Level} = (\text{ADC} \times \text{Lead Time}) + \text{Safety Stock}$$

4. **Maximum Stock Level**:
   $$\text{Max Stock} = \text{Reorder Level} + \text{MOQ}$$

---

## 5. Security & Access Control

- **Warehouse Scoping**: Users with `location` set in `public.users` can only view stock items located in their assigned warehouse location.
- **Firm / Division Scoping**: Materials, Locations, Categories, and Transactions record their assigned `division` for multi-firm multi-tenant isolation.
- **Role Permissions**:
  - `Admin` / `Superadmin`: Full access to Master Data configurations (`inventory_categories`, `inventory_units`, `inventory_locations`, `inventory_materials`), settings, and audit logs.
  - `User` / `Viewer`: Read-only access or restricted transaction entry based on `page_access`.
