# Leads & CRM System — Comprehensive Technical & Functional Documentation

> **Complete Database Schema, System Workflows, Page-by-Page Breakdown & Form Field Specifications**

---

## 📑 Table of Contents

1. [Executive Summary & System Architecture](#1-executive-summary--system-architecture)
2. [Database Schema & Architecture (`supabase_leads_schema.sql`)](#2-database-schema--architecture)
   - 2.1 [Master Tables](#21-master-tables)
   - 2.2 [CRM Companies & Contacts Master](#22-crm-companies--contacts-master)
   - 2.3 [Core Leads & Lead Contacts](#23-core-leads--lead-contacts)
   - 2.4 [Follow-up Tracker, Line Items & Drafts](#24-follow-up-tracker-line-items--drafts)
   - 2.5 [Request Quotation Queue (RQ)](#25-request-quotation-queue-rq)
   - 2.6 [Quotations & Quotation Line Items](#26-quotations--quotation-line-items)
   - 2.7 [Quotation Tracker, Advance Payment & Order Conversion](#27-quotation-tracker-advance-payment--order-conversion)
   - 2.8 [Entity-Relationship Diagram](#28-entity-relationship-diagram)
3. [End-to-End System Flow & Business Lifecycle](#3-end-to-end-system-flow--business-lifecycle)
4. [Page-by-Page Deep-Dive & Form Specifications](#4-page-by-page-deep-dive--form-specifications)
   - 4.1 [Page 1: Dashboard (`/dashboard/leads`)](#41-page-1-dashboard-dashboardleads)
   - 4.2 [Page 2: New Lead (`/dashboard/leads/new-lead`)](#42-page-2-new-lead-dashboardleadsnew-lead)
   - 4.3 [Page 3: Followup Tracker (`/dashboard/leads/followup-tracker`)](#43-page-3-followup-tracker-dashboardleadsfollowup-tracker)
   - 4.4 [Page 4: Request Quotation (`/dashboard/leads/request-quotation`)](#44-page-4-request-quotation-dashboardleadsrequest-quotation)
   - 4.5 [Page 5: Create Quotation / Pending Quotation (`/dashboard/leads/pending-quotation`)](#45-page-5-create-quotation--pending-quotation-dashboardleadspending-quotation)
   - 4.6 [Page 6: Quotation Approval (`/dashboard/leads/quotation-approval`)](#46-page-6-quotation-approval-dashboardleadsquotation-approval)
   - 4.7 [Page 7: Quotation Tracker (`/dashboard/leads/quotation-tracker`)](#47-page-7-quotation-tracker-dashboardleadsquotation-tracker)
   - 4.8 [Page 8: Contacts (`/dashboard/leads/contacts`)](#48-page-8-contacts-dashboardleadscontacts)
   - 4.9 [Page 9: Calendar (`/dashboard/leads/calendar`)](#49-page-9-calendar-dashboardleadscalendar)
5. [Cross-System Integrations & Core Engines](#5-cross-system-integrations--core-engines)
   - 5.1 [GPS Geolocation & Camera Watermarking](#51-gps-geolocation--camera-watermarking)
   - 5.2 [Automated Turnaround Time (TAT) & SLA Engine](#52-automated-turnaround-time-tat--sla-engine)
   - 5.3 [Automated Order-to-Dispatch (O2D) Bridge](#53-automated-order-to-dispatch-o2d-bridge)
   - 5.4 [Automated WhatsApp Notifications](#54-automated-whatsapp-notifications)
6. [Deployment, Migration & Setup Guide](#6-deployment-migration--setup-guide)

---

## 1. Executive Summary & System Architecture

The **Leads System** is an enterprise-grade Customer Relationship Management (CRM) and Sales Pipeline Automation platform built specifically for manufacturing, trading, and engineering enterprises. It covers the complete lifecycle of customer acquisition:

```
[Inquiry Ingestion] ➡️ [Follow-up & Qualification] ➡️ [Quotation Request & Estimation]
        ⬇️
[Management Approval] ➡️ [Post-Quotation Follow-up] ➡️ [Order Won & Handover to O2D]
```

### Key Technical Stack
- **Frontend Framework**: React 18 / 19 with Vite, Tailwind CSS, Lucide React icons, Framer Motion
- **Backend / Database**: Supabase (PostgreSQL 15+) with Row-Level Security (RLS) & Realtime Websockets
- **Object Storage**: Supabase Storage (`leads-attachments`, `rq-excel-sheets`)
- **Document Generation**: jsPDF & AutoTable for client-ready PDF quotations with corporate letterheads
- **Excel & Bulk Processing**: SheetJS (`xlsx`) for multi-row lead/contact imports and BOQ spreadsheets
- **Security & Geofencing**: Browser Geolocation API + Canvas-based GPS & timestamp photo watermarking

---

## 2. Database Schema & Architecture

The database is built on relational PostgreSQL tables inside Supabase. The schema file is available at `supabase/leads_system_schema.sql`.

### 2.1 Master Tables

| Table Name | Primary Key | Key Columns | Purpose |
|---|---|---|---|
| `leads_master_salespersons` | `id` (bigint) | `name` (unique), `email`, `phone`, `is_active`, `sort_order` | Master list of sales team members for lead allocation |
| `leads_master_sources` | `id` (bigint) | `name` (unique), `is_active`, `sort_order` | Ingestion channels (IndiaMART, Cold Call, Referral, etc.) |
| `leads_master_nobs` | `id` (bigint) | `name` (unique), `is_active`, `sort_order` | Nature of Business (Manufacturing, EPC, Trader, etc.) |
| `leads_master_terms` | `id` (bigint) | `name`, `term_text`, `is_active`, `sort_order` | Standard legal clauses (Payment, Freight, Warranty, etc.) |

---

### 2.2 CRM Companies & Contacts Master

#### `leads_companies`
Central customer directory and verified company registry.

```sql
CREATE TABLE public.leads_companies (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    gst VARCHAR(30),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    state VARCHAR(100),
    city VARCHAR(100),
    nob VARCHAR(100),
    division VARCHAR(100),
    status VARCHAR(50) DEFAULT 'Active',
    proof TEXT,
    proof_location JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `leads_company_contacts`
Secondary directory for individual points of contact within each company.

```sql
CREATE TABLE public.leads_company_contacts (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    company_id BIGINT REFERENCES public.leads_companies(id) ON DELETE CASCADE,
    company_name VARCHAR(255),
    name VARCHAR(255),
    designation VARCHAR(150),
    number VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 2.3 Core Leads & Lead Contacts

#### `leads`
Stores every new incoming or outgoing sales lead.

```sql
CREATE TABLE public.leads (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    lead_number VARCHAR(100) NOT NULL UNIQUE,       -- Auto-generated: LEAD-YYYY-XXXX
    date VARCHAR(50),                               -- Registration Date (DD/MM/YYYY)
    sales_type VARCHAR(50) DEFAULT 'New Customer',  -- 'New Customer' or 'Existing Customer'
    lead_type VARCHAR(50) DEFAULT 'Incoming',       -- 'Incoming' or 'Outgoing'
    source VARCHAR(100),                            -- Channel from leads_master_sources
    interaction VARCHAR(50) DEFAULT 'Call',         -- Initial mode: Call, Email, Visit, WhatsApp
    company_name VARCHAR(255),                      -- Prospect Company Name
    company_id BIGINT REFERENCES leads_companies(id),
    phone_number VARCHAR(50),                       -- Primary Contact Phone
    salesperson_name VARCHAR(255),                  -- Executive who captured the lead
    receiver_name VARCHAR(255),                     -- Assigned Salesperson
    assigned_to VARCHAR(255),                       -- Ownership tag
    email VARCHAR(255),                             -- Contact Email
    state VARCHAR(100),                             -- Indian State
    city VARCHAR(100),                              -- City/Town
    address TEXT,                                   -- Physical / Billing Address
    nob VARCHAR(100),                               -- Nature of Business
    division VARCHAR(100),                          -- Product Division (Cables, Composites, etc.)
    notes TEXT,                                     -- Discussion summary
    gst VARCHAR(30),                                -- GSTIN if available
    credit_access VARCHAR(10),                      -- 'Yes' / 'No'
    credit_days VARCHAR(50),                        -- Credit Period (15, 30, 45, 60 days)
    credit_limit VARCHAR(50),                       -- Max credit amount
    attachment_url TEXT,                            -- Storage URL (Visiting card / Enquiry doc)
    attachment_location JSONB,                      -- GPS coords {lat, lng, address, timestamp}
    status VARCHAR(50) DEFAULT 'pending',           -- 'pending', 'quotation_ready', 'won', 'lost'
    priority VARCHAR(20) DEFAULT 'Medium',          -- High, Medium, Low
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `leads_contact_persons`
Associates up to 3 specific decision-makers (Director, Purchase Head, Plant Head) directly to the lead record.

---

### 2.4 Follow-up Tracker, Line Items & Drafts

#### `leads_followups`
Logs every single follow-up touchpoint (call, meeting, email) conducted with the customer.

```sql
CREATE TABLE public.leads_followups (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    lead_id BIGINT REFERENCES public.leads(id) ON DELETE SET NULL,
    lead_number VARCHAR(100),
    company_name VARCHAR(255),
    receiver_name VARCHAR(255),
    person_name VARCHAR(255),
    assigned_to VARCHAR(255),
    date VARCHAR(50),
    interaction VARCHAR(50) DEFAULT 'Call',
    customer_feedback TEXT,
    enquiry_status VARCHAR(100),                    -- 'Make Quotation', 'Follow up required', 'Not Interested'
    not_interested_reason TEXT,                     -- Reason if customer dropped
    next_action TEXT,                               -- Next action description
    next_call_date DATE,                            -- Scheduled next follow-up date
    next_call_time VARCHAR(20),                     -- Scheduled next follow-up time
    enquiry_state VARCHAR(100),
    city VARCHAR(100),
    nob VARCHAR(100),
    division VARCHAR(100),
    billing_address TEXT,
    shipping_address TEXT,
    freight_type VARCHAR(100),                      -- 'FOR', 'Ex-Works', 'To-Pay', 'Actuals'
    gst VARCHAR(30),
    credit_access VARCHAR(10),
    credit_days VARCHAR(50),
    credit_limit VARCHAR(50),
    notes TEXT,
    attachment TEXT,
    attachment_location JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `leads_followup_items`
Line items of products/materials enquired during the follow-up.
- `item_name`, `sku`, `category`, `uom`, `quantity`, `hsn`, `sort_order`

#### `leads_followup_drafts`
Saves incomplete follow-up forms as temporary drafts so work is never lost if the salesperson gets interrupted.
- `lead_number`, `user_name`, `draft_data` (JSONB)

---

### 2.5 Request Quotation Queue (RQ)

#### `rq_request_headers` & `rq_request_lines`
Bridge between the field salesperson and the technical estimation/costing department when customized BOQs or price configurations are required.

---

### 2.6 Quotations & Quotation Line Items

#### `leads_quotations`
The core commercial quotation document.

```sql
CREATE TABLE public.leads_quotations (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    quotation_no VARCHAR(100) NOT NULL UNIQUE,     -- e.g. NTC/PO/24-25/001 or ...-R1
    po_number VARCHAR(100),
    lead_id BIGINT REFERENCES public.leads(id),
    lead_number VARCHAR(100),
    consignee_name VARCHAR(255),
    consignee_division VARCHAR(100),
    nob VARCHAR(100),
    billing_address TEXT,
    shipping_address TEXT,
    state VARCHAR(100),
    city VARCHAR(100),
    contact_name VARCHAR(255),
    contact_no VARCHAR(50),
    gst VARCHAR(30),
    quotation_at TIMESTAMPTZ DEFAULT NOW(),
    freight_type VARCHAR(100),
    payment_terms VARCHAR(100),
    custom_payment_terms TEXT,
    advance_payment VARCHAR(10) DEFAULT 'No',
    advance_amount NUMERIC(15, 2) DEFAULT 0.00,
    base_price NUMERIC(15, 2) DEFAULT 0.00,
    discount_amount NUMERIC(15, 2) DEFAULT 0.00,
    gst_amount NUMERIC(15, 2) DEFAULT 0.00,
    grand_total NUMERIC(15, 2) DEFAULT 0.00,
    prepared_by VARCHAR(255),
    sales_person VARCHAR(255),
    revised_from VARCHAR(100),                     -- Points to parent quote on revisions
    revision_number INTEGER DEFAULT 0,              -- 0 for original, 1 for R1, 2 for R2
    pdf_url TEXT,                                  -- Generated PDF in storage
    excel_file_url TEXT,                           -- Uploaded BOQ Excel sheet
    terms JSONB DEFAULT '[]'::jsonb,               -- Active legal terms snapshot
    status VARCHAR(50) DEFAULT 'Pending Approval', -- Draft, Pending Approval, Approved, Rejected, Won, Lost
    approval_status VARCHAR(50) DEFAULT 'pending', -- pending, approved, rejected
    approved_by VARCHAR(255),
    approved_at TIMESTAMPTZ,
    approval_remarks TEXT,
    rejection_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `leads_quotation_items`
- `item_name`, `hsn`, `qty`, `uom`, `rate`, `discount_percent`, `gst_percent`, `total`, `sort_order`

---

### 2.7 Quotation Tracker, Advance Payment & Order Conversion

#### `leads_quotation_updates`
Logs post-quote interactions, negotiation updates, advance payments, and customer PO confirmations.

```sql
CREATE TABLE public.leads_quotation_updates (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    quotation_id BIGINT REFERENCES leads_quotations(id),
    quotation_no VARCHAR(100) NOT NULL,
    lead_number VARCHAR(100),
    company_name VARCHAR(255),
    division VARCHAR(100),
    nob VARCHAR(100),
    sales_person VARCHAR(255),
    grand_total NUMERIC(15, 2) DEFAULT 0.00,
    status VARCHAR(100) NOT NULL,                  -- 'Call Back', 'Order Received', 'Lost'
    interaction_type VARCHAR(50) DEFAULT 'Call',
    customer_said TEXT,
    next_followup_at TIMESTAMPTZ,
    remarks TEXT,
    reason TEXT,                                   -- Reason for Loss if status = 'Lost'
    advance_payment VARCHAR(10) DEFAULT 'No',
    advance_amount NUMERIC(15, 2) DEFAULT 0.00,
    po_number_customer VARCHAR(100),               -- Client's official Purchase Order Number
    po_at TIMESTAMPTZ,                             -- Customer PO Date
    expected_delivery_at TIMESTAMPTZ,              -- Promised Dispatch Date
    gst_number VARCHAR(30),
    po_copy_url TEXT,                              -- Client PO Document Scan
    attachment_url TEXT,
    attachment_location JSONB,
    updated_by VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 2.8 Entity-Relationship Diagram

```mermaid
erDiagram
    leads_companies ||--o{ leads_company_contacts : "has contacts"
    leads_companies ||--o{ leads : "places enquiries"
    leads ||--o{ leads_contact_persons : "contains"
    leads ||--o{ leads_followups : "logs interactions"
    leads_followups ||--o{ leads_followup_items : "specifies products"
    leads ||--o{ leads_followup_drafts : "temporary draft"
    leads ||--o{ rq_request_headers : "triggers quotation request"
    rq_request_headers ||--o{ rq_request_lines : "items"
    leads ||--o{ leads_quotations : "quoted by"
    leads_quotations ||--o{ leads_quotation_items : "line items"
    leads_quotations ||--o{ leads_quotation_updates : "status updates & PO"
    leads_quotation_updates }o--|| o2d_orders : "converts to received order"
```

---

## 3. End-to-End System Flow & Business Lifecycle

The entire life of an inquiry follows a rigorous 8-stage pipeline:

```mermaid
flowchart TD
    A(["1. Lead Ingestion (New Lead Page)"]) --> B{"Existing Company?"}
    B -- No --> C["Create leads_companies & Contact Person"]
    B -- Yes --> D["Link to Existing Company Profile"]
    C --> E["Save to leads Table (Status: pending)"]
    D --> E
    
    E --> F["2. Followup Tracker (Pending Stage)"]
    F --> G["Salesperson calls / visits client"]
    G --> H{"Enquiry Status Decision"}
    
    H -- "Follow up required" --> I["Schedule Next Call Date & Time"]
    I --> F
    
    H -- "Not Interested" --> J["Mark as Lost with Reason"]
    J --> K["Archived to History & Unconverted Contacts"]
    
    H -- "Make Quotation" --> L["3. Create Quotation / Request Quotation"]
    
    L --> M["Build BOQ, Rates, GST & Terms"]
    M --> N["Submit Quotation (Status: Pending Approval)"]
    
    N --> O["4. Quotation Approval Matrix"]
    O --> P{"HOD / Admin Review"}
    P -- "Reject" --> Q["Return with Rejection Reason"]
    Q --> L
    
    P -- "Approve" --> R["Status: Approved + WhatsApp PDF to Party"]
    
    R --> S["5. Quotation Tracker"]
    S --> T{"Customer Follow-up"}
    T -- "Negotiation / Call Back" --> U["Log Feedback & Next Follow-up"]
    U --> S
    T -- "Order Lost" --> V["Log Loss Reason & Archive"]
    
    T -- "Order Confirmed / Won" --> W["Collect Advance & Customer PO"]
    W --> X["6. Automatic Handover to Order Management (O2D)"]
    X --> Y["Order Created in o2d_orders & Contacts Marked Converted"]
```

---

## 4. Page-by-Page Deep-Dive & Form Specifications

This section explains all **9 core pages** shown in the Leads System navigation:

```
Leads System
  ├── 1. Dashboard
  ├── 2. New Lead
  ├── 3. Followup Tracker
  ├── 4. Request Quotation
  ├── 5. Create Quotation
  ├── 6. Quotation Approval
  ├── 7. Quotation Tracker
  ├── 8. Contacts
  └── 9. Calendar
```

---

### 4.1 Page 1: Dashboard (`/dashboard/leads`)

#### Ye Page Kya Chij Hai? (What is this page?)
Yeh Leads System ka **Mission Control** hai. Admin, HOD aur Sales Executives sabhi ke liye central real-time performance analytics provide karta hai.

#### Kya Karte Hai? (Capabilities)
- Sales executives ko unka **Daily Agenda**, pending calls, aur aaj ke follow-ups dikhata hai.
- Admins ko conversion ratios, division-wise sales, pipeline value, aur salesperson rankings dikhata hai.
- Quick action shortcuts provide karta hai ("New Lead Entry", "Log Followup", "Request Quotation").
- System master settings (Salespersons, Sources, NOBs, Terms) configure karne ka access deta hai.

#### Kaise Karte Hai? (How to operate)
1. Screen par aate hi time-based greeting (Good morning / afternoon / evening) dikhta hai.
2. 4 main KPI cards dekhkar daily targets evaluate karein.
3. Kisi bhi KPI card par click karne se **Metric Detail Modal** open hota hai, jahan specific leads ki full table khul jati hai aur direct actions liye ja sakte hain.
4. "Master Settings" button se naye salespersons ya sources add karein.

#### Kis Page Mai Kya Form Hai? (Forms & Modals)
1. **Salesperson Filter / Division Filter Form**: Dropdowns to filter metrics by User and Division.
2. **Metric Detail Modal**: Interactive drill-down table with direct lead actions.
3. **Leads Master Settings Modal (`LeadsMasterSettingsView`)**: Master configuration form.

---

### 4.2 Page 2: New Lead (`/dashboard/leads/new-lead`)

#### Ye Page Kya Chij Hai?
Yeh naye customer ya prospect ki inquiry register karne ka primary intake point hai.

#### Kya Karte Hai?
- Cold call, website inquiry, exhibition, ya IndiaMART se aayi leads ko database me enter karte hain.
- Prospect company, phone, email, state, city, aur multiple contact persons capture karte hain.
- Enquired products ki line items add karte hain.
- Visiting card ya enquiry document ka photo/PDF GPS location watermark ke sath upload karte hain.
- Excel/CSV file se batch leads bulk upload karte hain.

#### Kaise Karte Hai?
1. `New Customer` select karein (ya existing customer search karein).
2. Lead Source (e.g. IndiaMART, Cold Call) choose karein.
3. Company Name, Mobile Number, Email, Address, State, aur City fill karein.
4. Contact Persons (Name, Designation, Number) enter karein (3 tak add kar sakte hain).
5. Enquired items table me Product select karein, UOM aur Quantity fill karein.
6. Visiting Card / Proof upload karein (Browser location allow karega taaki GPS stamp lag sake).
7. `Submit Lead` button dabayein. System automatically Lead Number generate karega (e.g., `LEAD-2024-0012`) aur record create karega.

#### Form Mai Kya Puch Rhe Hai? (Field-by-Field Breakdown)

| Field Name | Technical Key | Type | Required | Options / Source | Kyu Puch Rhe Hai? (Purpose) |
|---|---|---|---|---|---|
| **Lead Number** | `leadNumber` | Text (Read-only) | Auto | System Generated | Unique identifier for tracking throughout the lifecycle |
| **Registration Date** | `date` | Date (Read-only) | Auto | Current Date | Timestamp of lead registration |
| **Sales Type** | `salesType` | Radio / Select | Yes | "New Customer", "Existing Customer" | Determines whether to create a new company in CRM Master |
| **Lead Type** | `leadType` | Select | Yes | "Incoming", "Outgoing" | Identifies inbound inquiry vs outbound marketing cold reach |
| **Lead Source** | `source` | Dropdown | Yes | From `leads_master_sources` | Attribution tracking to measure marketing channel ROI |
| **Assigned Sales Person** | `receiverName` | Dropdown | Yes | From `leads_master_salespersons` | Ownership of lead for follow-up responsibility and SLA |
| **Company Name** | `companyName` | Combobox | Yes | Free text or existing company | Legal entity / organization making the inquiry |
| **Phone Number** | `phoneNumber` | Tel (10 digits) | Yes | Valid Phone String | Primary number for telecalling and WhatsApp notifications |
| **Email Address** | `email` | Email | No | Standard email format | Official quotation sending & email correspondence |
| **Nature of Business (NOB)**| `nob` | Dropdown | Yes | From `leads_master_nobs` | Categorization (Manufacturing, Trader, Contractor, EPC) |
| **Division** | `division` | Dropdown | Yes | From `divisions` table | Business unit handling this product line (e.g. Cables) |
| **State** | `state` | Dropdown | Yes | 36 Indian States/UTs | Geographic territory allocation & GST calculation (IGST vs CGST) |
| **City** | `city` | Dropdown / Text | Yes | Filtered by selected State | City-level routing & logistics planning |
| **Complete Address** | `address` | Textarea | No | Multiline text | Billing & shipping destination verification |
| **Contact Persons** | `contactPersons` | Dynamic Array (up to 3) | Yes | Sub-fields: Name, Designation, Phone | Key decision makers (Purchase Head, Director, Engineer) |
| **Product Items** | `items` | Dynamic Table | No | Material Name, SKU, Category, UOM, Qty, HSN | Initial products or materials the client wants to buy |
| **Interaction Mode** | `interaction` | Select | Yes | Call, Email, Meeting / Visit, WhatsApp | How the first conversation was conducted |
| **Notes / Remarks** | `notes` | Textarea | No | Multiline text | Specific customer requirements, dimensions, technical notes |
| **Attachment Proof** | `attachment` | File Upload (Img/PDF) | **Mandatory** | Max 10MB | Mandatory visiting card / enquiry scan with GPS watermark |

---

### 4.3 Page 3: Followup Tracker (`/dashboard/leads/followup-tracker`)

#### Ye Page Kya Chij Hai?
Sales pipeline ka engine jahan sabhi open leads ke follow-ups, calls, aur discussions track aur log kiye jaate hain.

#### Kya Karte Hai?
- Dekhte hain kis lead par kab call karna scheduled hai (Pending Tab).
- Check karte hain kaun si lead overdue ho chuki hai (TAT SLA violations).
- Call complete karne ke baad feedback aur enquiry status log karte hain.
- Quotation banane ke liye inquiry ko aage forward karte hain.
- Draft follow-ups resume karte hain.
- Past follow-up calls ka full history audit trail dekhte hain.

#### Kaise Karte Hai?
1. `Pending` tab me list dekhein. Filter by Salesperson, Division, ya Due Date.
2. Jis lead par call karna hai, uske action column me `Call` ya `Log Followup` button par click karein.
3. System `NewFollowUp` page / modal kholta hai with pre-filled lead details.
4. Discussion ke mutabiq `Customer Feedback` select karein (e.g. "Asked for Quotation").
5. `Enquiry Received Status` choose karein:
   - Agar deal aage badhani hai -> Select **"Make Quotation"**.
   - Agar dubara baat karni hai -> Select **"Follow up required"** aur Next Call Date/Time chunein.
   - Agar customer ne mana kar diya -> Select **"Not Interested"** aur reason mention karein.
6. `Submit Follow-up` dabayein.

#### Form Mai Kya Puch Rhe Hai? (`NewFollowUp` Form Breakdown)

| Field Name | Technical Key | Type | Required | Kyu Puch Rhe Hai? (Purpose) |
|---|---|---|---|---|
| **Lead Number** | `leadNo` | Text (Read-only) | Auto | Connects follow-up to the exact parent lead record |
| **Company Name** | `companyName` | Combobox | Yes | Prospect being called |
| **Interaction Type** | `interaction` | Select | Yes | Phone Call, Email, Office Meeting, Site Visit, WhatsApp |
| **Customer Feedback** | `customerFeedback` | Dropdown | Yes | "Interested", "Asked for Quotation", "Call Back Later", "Order Confirmed" |
| **Enquiry Status** | `enquiryStatus` | Select | Yes | Pipeline stage trigger: "Make Quotation", "Follow up required", "Not Interested" |
| **Not Interested Reason**| `notInterestedReason` | Textarea | If Not Int. | Mandatory reason if dropped (Price high, Competitor, Requirement cancelled) |
| **Next Call Date & Time**| `nextCallDate`, `time` | Date & Time Picker | If Followup | Schedules next reminder in Calendar & Agenda |
| **Billing & Shipping Addr**| `billingAddress`, `shipping` | Textarea | No | Pre-populates quotation and order logistics |
| **GST Number** | `gst` | Text | No | Verified 15-character GSTIN for B2B billing |
| **Freight Type** | `freightType` | Select | No | Transport terms: 'FOR', 'Ex-Works', 'To-Pay', 'Actuals' |
| **Credit Facility** | `creditAccess`, `days`, `limit`| Select & Number | No | Credit eligibility check (e.g. 30 Days, ₹2,00,000 Limit) |
| **Product Items** | `items` | Dynamic Table | If Quotation | Specific SKU, Category, UOM, and Quantity requested for quotation |
| **Attachment Proof** | `attachment` | File Upload | **Mandatory** | Call log screenshot / site photo / meeting minutes with GPS stamp |

---

### 4.4 Page 4: Request Quotation (`/dashboard/leads/request-quotation`)

#### Ye Page Kya Chij Hai?
Yeh queue un inquiries ke liye hai jinme field salesperson ko office technical estimation team ya plant engineering se quotation banwane ki zaroorat hoti hai.

#### Kya Karte Hai?
- Technical specs, custom dimensions, drawings, ya BOQ sheets upload karte hain.
- Payment terms, freight terms, aur delivery constraints specify karte hain.
- Request queue me pending status track karte hain taaki estimation team SLA ke andar quote ready kare.

#### Kaise Karte Hai?
1. Pending list se lead select karein ya `Create Request` tab par jayein.
2. Company, division, aur billing details verify karein.
3. Item details enter karein ya client ki BOQ Excel sheet upload karein.
4. Preferred Payment Terms (Advance, 30 Days, PDC) aur Freight Type select karein.
5. `Submit Request` dabayein. Yeh record `rq_request_headers` table me save hokar estimation department ko push ho jata hai.

---

### 4.5 Page 5: Create Quotation / Pending Quotation (`/dashboard/leads/pending-quotation`)

#### Ye Page Kya Chij Hai?
Commercial quotation generation studio jahan dynamic tax, discounts, line items, and terms & conditions configure karke professional PDF quotation banai jaati hai.

#### Kya Karte Hai?
- Pending quotation requests ko process karte hain.
- Multi-item pricing table banate hain (Finished goods selection, HSN code, UOM, Qty, Rate, Discount %, GST Slab 0/5/12/18/28%).
- Excel sheet se BOQ items direct import karte hain.
- Standard legal terms & conditions customize karte hain.
- Naye revisions create karte hain (e.g., `QT-2024-001-R1`, `...-R2`) agar customer price negotiation kare.
- Nutech letterhead ke sath A4 PDF generate aur download karte hain.

#### Kaise Karte Hai?
1. `Create` tab me pending lead select karein (sara customer data auto-fill ho jayega).
2. Quotation Number verify karein (system generated fiscal year sequence like `NTC/PO/24-25/001`).
3. Pricing table me items add karein:
   - Item search karein (Inventory material se SKU aur HSN auto-populate hoga).
   - Quantity aur Rate (₹) enter karein.
   - Discount % (if applicable) aur GST % select karein.
4. Summary card automatically Base Price, Total Discount, Taxable Amount, GST Amount, aur Grand Total calculate karega.
5. Payment Terms (Advance / Credit) aur Freight terms check karein.
6. Terms & Conditions checklist review karein.
7. `Submit Quotation` dabayein. Quotation automatically Management Approval queue me chali jayegi.

#### Form Mai Kya Puch Rhe Hai? (Quotation Form Fields)

| Field Name | Technical Key | Type | Required | Purpose |
|---|---|---|---|---|
| **Quotation / PO Number** | `poNumber` / `quotationNo` | Text (Auto) | Yes | Unique legal quotation serial with revision suffix (-R1, -R2) |
| **Quotation Date** | `quotationDate` | Date Picker | Yes | Issuance date defining the 15-day quotation validity window |
| **Consignee / Company** | `companyName` | Combobox | Yes | Party to whom quotation is formally addressed |
| **Division** | `division` | Dropdown | Yes | Factory / Division issuing the proposal |
| **Billing Address** | `billingAddress` | Textarea | Yes | Legal address for GST invoice printing |
| **Shipping Address** | `shippingAddress` | Textarea | Yes | Delivery plant/site address |
| **Contact Person & Phone**| `contactName`, `contactNo`| Text | Yes | Recipient who will receive quotation and WhatsApp PDF |
| **GST Number** | `gst` | Text | No | Client's tax identification |
| **Freight Type** | `freightType` | Select | Yes | FOR Site, Ex-Works, To-Pay, Actuals Extra |
| **Payment Terms** | `paymentTerms` | Dropdown | Yes | 100% Advance, 30 Days Credit, 45 Days Credit, PDC, Custom |
| **Advance Payment** | `advancePayment`, `amount` | Select & Number | If Adv | Indicates mandatory advance amount required before dispatch |
| **Line Items Table** | `items` array | Multi-row Table | **At least 1** | Detailed products, HSN, Quantities, Unit Rates, Discounts, Taxes |
| **Terms & Conditions** | `terms` array | Dynamic List | Yes | Binding commercial and warranty clauses |

---

### 4.6 Page 6: Quotation Approval (`/dashboard/leads/quotation-approval`)

#### Ye Page Kya Chij Hai?
Management, HODs, aur Administrators ke liye **Commercial Governance & Discount Control Gatekeeper** hai. Koi bhi salesperson management approval ke bina quotation client ko dispatch nahi kar sakta.

#### Kya Karte Hai?
- Submited quotations ka detailed line-by-line financial breakdown inspect karte hain.
- Unapproved high discounts ya credit terms evaluate karte hain.
- Quotation ko **Approve** karte hain with approval remarks.
- Quotation ko **Reject** karte hain with mandatory reason (taaki salesperson revision bana sake).
- Approve hote hi customer ke mobile par **Automated WhatsApp Notification with PDF Link** trigger karte hain.

#### Kaise Karte Hai?
1. `Pending` tab me pending approvals ki list dekhein.
2. `View / PDF` icon par click karke complete PDF preview inspect karein.
3. Agar commercial terms sahi hain -> Click **`Approve`** button -> Enter remarks -> Confirm.
   - Quotation status becomes `Approved`.
   - Client ko instant WhatsApp message chala jata hai.
4. Agar discount zyada hai ya rates galat hain -> Click **`Reject`** button -> Enter reason (e.g. "Margin too low, maximum allowable discount is 5%") -> Confirm.
   - Salesperson ko alert mil jata hai revise karne ke liye.

#### Form Mai Kya Puch Rhe Hai?
1. **Approve Dialog**:
   - `Approval Remarks` (Textarea - Optional notes for audit trail).
2. **Reject Dialog**:
   - `Rejection Reason` (Textarea - **Mandatory** explanation of why quotation was declined).

---

### 4.7 Page 7: Quotation Tracker (`/dashboard/leads/quotation-tracker`)

#### Ye Page Kya Chij Hai?
Quotation approve aur client ko bhejne ke baad ki **Deal Closing & Conversion Tracking Stage**. Yeh system ka sabse critical conversion checkpoint hai.

#### Kya Karte Hai?
- Approved quotations ka post-quote client follow-up log karte hain.
- Deal negotiation track karte hain.
- Agar order jeet gaye (**Order Won**): Customer ka Purchase Order (PO) number, PO copy scan, advance payment details, aur delivery date capture karte hain.
- Agar order haar gaye (**Lost**): Lost reason capture karte hain.
- **AUTOMATIC HANDOVER**: Jaise hi yahan "Order Received" submit hota hai, system automatically Order Management (O2D) me official Order create kar deta hai!

#### Kaise Karte Hai?
1. `Pending` tab me active quotations dekhein.
2. Update button (`Action`) par click karein to open the status update form.
3. Select `Status`:
   - Agar baat chal rahi hai -> Select **"Call Back"** -> Set `Next Followup Date`.
   - Agar order mil gaya -> Select **"Order Received"**.
     - `Has PO`: Yes/No select karein.
     - `Customer PO Number` aur `PO Date` fill karein.
     - `PO Copy Scan` upload karein (with GPS watermark).
     - `Advance Payment`: Received (Yes/No) aur `Advance Amount (₹)` enter karein.
     - `Expected Delivery Date` specify karein.
4. `Submit` dabayein.
   - Deal history tab me chali jayegi.
   - Order Management (O2D) me entry create ho jayegi.
   - Customer CRM Contacts me "Converted Customer" ban jayega.

#### Form Mai Kya Puch Rhe Hai? (Quotation Tracker Update Form)

| Field Name | Technical Key | Type | Required | Purpose |
|---|---|---|---|---|
| **Quotation / Lead No** | `quotationNo`, `leadNo` | Text (Read-only) | Auto | Links the closing transaction |
| **Interaction Type** | `interactionType` | Select | Yes | Call, Meeting, Email, Visit, WhatsApp |
| **Customer Said / Feedback**| `customerSaid` | Textarea | Yes | Client's exact feedback, negotiation points, counter-offer |
| **Status** | `status` | Select | Yes | "Call Back" (In progress), "Order Received" (Won), "Lost" (Closed) |
| **Next Follow-up Date** | `nextFollowupDate` | Date Picker | If Call Back | Reminder date for next commercial follow-up |
| **Reason for Loss** | `reason` | Textarea | If Lost | Root cause analysis for lost order (Competitor, Price, Delivery time) |
| **Has Customer PO?** | `hasPo` | Radio (Yes/No) | If Won | Indicates if client issued a written Purchase Order |
| **Customer PO Number** | `poNumber` | Text | If Has PO | Official PO reference number issued by customer |
| **Customer PO Date** | `poDate` | Date Picker | If Has PO | Date mentioned on client's purchase order |
| **Upload PO Copy** | `poCopy` | File Upload | If Has PO | PDF / Image of signed client PO with GPS stamp |
| **Advance Payment** | `advancePayment` | Radio (Yes/No) | If Won | Confirms if token / full advance was credited |
| **Advance Amount (₹)** | `advanceAmount` | Number | If Adv Yes | Exact amount received in bank |
| **Expected Delivery Date** | `expectedDeliveryDate`| Date Picker | If Won | Delivery commitment given to client |
| **GST Number** | `gstNumber` | Text | No | Verified GSTIN for e-way bill and invoice |

---

### 4.8 Page 8: Contacts (`/dashboard/leads/contacts`)

#### Ye Page Kya Chij Hai?
Enterprise CRM **Customer & Prospect Directory** (Address Book).

#### Kya Karte Hai?
- Dono categories ko alag-alag tabs me dekhte hain:
  1. **Converted Tab**: Active buyers jinhone kam se kam 1 order diya hai.
  2. **Unconverted Tab**: Inquiries jo abhi pipeline me hain ya jo drop / cancel ho gayi hain.
- Unconverted contacts me exact **"Cancellation Stage"** (Initial Lead Stage, Follow-up Stage, Quotation Stage) aur failure reason display hota hai.
- Direct quick buttons se call, email, ya direct "New Enquiry" initiate kar sakte hain.
- "Add Contact" modal se standalone client create kar sakte hain.
- Excel / CSV se bulk contacts import kar sakte hain.

#### Form Mai Kya Puch Rhe Hai? ("Add Company Contact" Modal Form)
- `Company Name` (Unique client name)
- `GST Number` (GSTIN)
- `Email Address` & `Phone Number`
- `Nature of Business (NOB)` & `Division`
- `State` & `City`
- `Complete Office / Factory Address`
- `Contact Persons Array` (Name, Designation, Contact Mobile)
- `Visiting Card / Proof Upload` (with GPS location stamp)

---

### 4.9 Page 9: Calendar (`/dashboard/leads/calendar`)

#### Ye Page Kya Chij Hai?
Visual **SLA & Sales Activity Scheduler** jo pura month/week ka calendar view render karta hai.

#### Kya Karte Hai?
- Sales team ke sabhi scheduled follow-ups, calls, site visits, aur quotation deadlines ko calendar format me visualizes karta hai.
- Company holidays aur working days calendar ke sath integrated hai.
- Events color-coded status me dikhte hain:
  - 🔵 **Planned**: Future scheduled task
  - 🟡 **Today**: Today's high-priority agenda
  - 🔴 **Overdue**: Missed SLA / TAT violation needing urgent escalation
  - 🟢 **Completed**: Successfully finished interaction
- `Grid View` (Monthly Box Calendar) aur `Agenda View` (Chronological task list) me switch kar sakte hain.
- Filter by Salesperson, Division, ya Event Category.
- Kisi bhi date ya event par click karke direct us lead ke form me navigate kar sakte hain.

---

## 5. Cross-System Integrations & Core Engines

### 5.1 GPS Geolocation & Camera Watermarking
Field accountability ke liye system me mandatory photo verification engine integrated hai:
- Sales executive jab bhi visiting card ya site proof upload karta hai, browser Geolocation API (`navigator.geolocation.getCurrentPosition`) se exact Latitude, Longitude, aur Address reverse-geocode hota hai.
- HTML5 Canvas engine photo ke bottom par live watermark bake karta hai:
  - `📍 Address / City`
  - `🌐 Coords: Lat, Long`
  - `🕒 Date & Timestamp`
- Yeh fraud prevent karta hai aur verify karta hai ki sales rep sach me client ki factory ya office par maujood tha.

### 5.2 Automated Turnaround Time (TAT) & SLA Engine
- `leadsTatEngine.jsx` table `tat_rules` se rules fetch karta hai:
  - New Lead Contact: 4 hours
  - Follow-up Call: 24 hours
  - Quotation Preparation: 12 hours
  - Management Approval: 6 hours
  - Post-Quote Follow-up: 48 hours
- Agar planned date cross hoti hai, card automatically Red badge me badal jata hai aur calendar me overdue mark ho jata hai.

### 5.3 Automated Order-to-Dispatch (O2D) Bridge
Jab Quotation Tracker me status `Order Received` hota hai:
1. System quotation data aur customer PO data ko compile karta hai.
2. `createReceivedOrder()` API call hoti hai jo `o2d_orders` aur `o2d_order_items` tables me entry push karti hai.
3. Order Management team ko instant alert mil jata hai dispatch planning aur production shuru karne ke liye.
4. Agar database insert me koi error aaye to compensating rollback trigger hota hai taaki data integrity bani rahe.

### 5.4 Automated WhatsApp Notifications
- Quotation approve hote hi party ke mobile number par pre-configured WhatsApp message deliver hota hai with direct PDF download link.
- Sales executives ko daily morning pending follow-ups summary WhatsApp par broadcast hoti hai.

---

## 6. Deployment, Migration & Setup Guide

### 6.1 Database Migration
1. Supabase Dashboard me jayein -> `SQL Editor`.
2. `supabase/leads_system_schema.sql` ka complete content paste karein.
3. `Run` par click karein. Sabhi master tables, leads tables, quotations tables, triggers, aur seed data create ho jayenge.

### 6.2 Environment Configuration
Apni `.env` file me Supabase keys configure karein:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### 6.3 Standalone Integration
Agar is module ko kisi naye React project me use karna ho:
1. `leads_system.zip` extract karein.
2. `src/systems/leads/` folder ko apne project me copy karein.
3. Dependencies install karein:
   ```bash
   npm install @supabase/supabase-js jspdf jspdf-autotable lucide-react xlsx
   ```
4. Apne router (`App.jsx`) me routes import karke configure karein (as outlined in this documentation).
