# Leads & CRM System Package

Welcome to the standalone export package of the **Leads & CRM System**.

## 📦 Package Contents

1. **`LEADS_SYSTEM_DOCUMENTATION.md`**: Complete, comprehensive Hindi & English documentation covering:
   - System Overview & Architecture
   - Database Schema (all tables, columns, relations, indexes)
   - Lifecycle Flowcharts
   - Page-by-Page breakdown of all 9 pages shown in the sidebar:
     1. Dashboard (`/dashboard/leads`)
     2. New Lead (`/dashboard/leads/new-lead`)
     3. Followup Tracker (`/dashboard/leads/followup-tracker`)
     4. Request Quotation (`/dashboard/leads/request-quotation`)
     5. Create Quotation (`/dashboard/leads/pending-quotation`)
     6. Quotation Approval (`/dashboard/leads/quotation-approval`)
     7. Quotation Tracker (`/dashboard/leads/quotation-tracker`)
     8. Contacts (`/dashboard/leads/contacts`)
     9. Calendar (`/dashboard/leads/calendar`)
   - Detailed breakdown of every single form, modal, and field (what is asked, why it is asked, validation, DB storage).
   - Core engines (GPS Geofencing, TAT / SLA Engine, Automated Order O2D bridge, WhatsApp integration).

2. **`leads_system_schema.sql`**: Production-ready PostgreSQL / Supabase migration script containing:
   - All 14+ database tables
   - Master data & seed data (Salespersons, Sources, NOBs, Terms, TAT SLA rules)
   - Foreign keys, constraints, and indexes
   - Triggers for auto-updating timestamps
   - Storage bucket declarations (`leads-attachments`, `rq-excel-sheets`)

3. **`src/systems/leads/`**: Complete clean source code for all pages, components, services, context, data, and utilities.

4. **`src/components/`, `src/context/`, `src/utils/`, `src/assets/`**: Supporting helper modules for location permission, watermarking, role utilities, toast notifications, and corporate assets.

## 🚀 Quick Setup

1. **Execute Schema**:
   Open Supabase -> **SQL Editor** -> Paste the content of `leads_system_schema.sql` -> Run.

2. **Copy Code**:
   Copy the `src/` directory into your React / Vite project.

3. **Install Dependencies**:
   ```bash
   npm install @supabase/supabase-js jspdf jspdf-autotable lucide-react xlsx
   ```

4. **Configure Environment**:
   Add to `.env`:
   ```env
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key
   ```
