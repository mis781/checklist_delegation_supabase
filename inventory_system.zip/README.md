# Inventory Management System (IMS) — Enterprise Standalone Package

Welcome to the standalone export package of the **Inventory Management System (IMS)**.

This package contains the complete source code, database migration scripts, Redux state management layer, and end-to-end technical documentation for an enterprise-grade manufacturing inventory, multi-batch job card consumption, inter-warehouse transfer, and reorder automation platform.

---

## 📦 Package Contents

1. **`INVENTORY_SYSTEM_DOCUMENTATION.md`**:
   Comprehensive 10-chapter technical and functional manual covering:
   - System Architecture & Executive Overview
   - Complete Material Lifecycle & Mermaid Process Flowcharts
   - Data Ingestion Streams (Where data comes from: Purchase GRN, Order Returns, Job Cards, Inter-Division Transfers)
   - Database Schema breakdown of all 15 tables with column-level specifications
   - Detailed breakdown of all 11 sub-tabs and views
   - Complete field specifications for all modals and forms
   - Mathematical Stock Calculation Engine (Closing stock, Safety stock, Reorder level, Max stock, Scrap recycling)
   - Redux state architecture, PostgREST pagination (`fetchAllRows`), and Supabase Realtime subscriptions
   - Multi-tenant division isolation and Role-Based Access Control (RBAC)

2. **`inventory_system_schema.sql`**:
   Production-ready PostgreSQL / Supabase migration script containing:
   - 15 relational tables with safe `IF NOT EXISTS` guards
   - Complete indexes for high-speed SKU, date, and division queries
   - Automated timestamp triggers (`handle_inventory_updated_at`)
   - Supabase Storage bucket registration (`inventory-attachments`)
   - Permissive Row-Level Security (RLS) policies
   - Default seed data for material types, units of measurement, categories, and warehouse racks

3. **`src/systems/inventory/`**:
   Complete source code including:
   - `pages/InventoryPage.jsx`: Main routing container, tab switcher, credentials manager, and Realtime WebSocket listeners.
   - `components/StockDashboardView.jsx`: Master IMS Stock grid, closing stock calculator, health bands, and transaction modal.
   - `components/PhysicalStockView.jsx` & `PhysicalStockModal.jsx`: Physical count auditing, variance tracking, and supervisor auto-adjustment.
   - `components/TransactionsView.jsx`: Double-entry movement ledger, job card batch expander, and CSV exporter.
   - `components/ReorderView.jsx`: Automated replenishment engine isolating low-stock items.
   - `components/IndentView.jsx`: Requisition lifecycle management (`IND-XXXX`).
   - `components/TransferRequestView.jsx`, `TransferApprovalView.jsx` & `TransferModal.jsx`: Inter-division transfer requisitions and approval.
   - `components/DailyConsumptionModal.jsx`: Daily shop-floor burn rate and RM-to-FG conversion analysis.
   - `components/RecycleModal.jsx` & `utils/scrapUtils.js`: Scrap, transit damage, and quality rejection tracking.
   - `components/BatchDetailPdfModal.jsx` & `batchDetailPdfTemplate.js`: jsPDF factory batch specification sheet generator.
   - `components/SettingsView.jsx`: Central catalog, master materials, units, categories, and warehouse locations.
   - `components/AuditLogView.jsx`: Immutable system audit trail.
   - `components/InventoryTrainingVideoView.jsx`: SOP video repository.

4. **`src/redux/`**:
   - `api/inventoryApi.js`: API connector communicating with Supabase tables, audit logging, and `fetchAllRows` pagination.
   - `api/transferApi.js`: Inter-division transfer submission and approval handlers.
   - `slice/inventorySlice.js`: Redux Toolkit slice and async thunks.
   - `slice/transferSlice.js`: Redux Toolkit slice for internal transfer state.

5. **`src/services/pendingSummary/inventoryPending.js`**:
   Real-time badge counter service feeding pending tasks into sidebars and navigation headers.

6. **`src/utils/` & Supporting Modules**:
   - `src/SupabaseClient.js`: Supabase JavaScript SDK client instance.
   - `src/context/MagicToastContext.jsx`: User toast notification system.
   - `src/components/ReadOnlyBanner.jsx`: View-only mode protection.
   - `src/utils/roleUtils.js`: Role checking and division authorization helpers.
   - `src/utils/pagePermissionUtils.js`: Granular page permission parser.
   - `src/systems/purchase/utils/dateUtils.js`: Timezone-safe date and time formatting utilities.

---

## 🚀 Quick Setup & Integration Guide

### Step 1: Database Migration
1. Log in to your Supabase project dashboard.
2. Open the **SQL Editor**.
3. Open `inventory_system_schema.sql`, paste its entire contents, and click **Run**.
4. Confirm that all 15 tables are visible under the **Table Editor**.

### Step 2: Storage Bucket Verification
Ensure the `inventory-attachments` storage bucket exists and is set to **Public** so uploaded damage photos render properly.

### Step 3: Install NPM Dependencies
Make sure your project has the required dependencies installed:
```bash
npm install @supabase/supabase-js @reduxjs/toolkit react-redux lucide-react recharts papaparse jspdf
```

### Step 4: Configure Redux Store
In your `store.js` (or `index.js` where `configureStore` is called):
```javascript
import { configureStore } from '@reduxjs/toolkit';
import inventoryReducer from './redux/slice/inventorySlice';
import transferReducer from './redux/slice/transferSlice';

export const store = configureStore({
  reducer: {
    inventory: inventoryReducer,
    transfers: transferReducer,
    // your other reducers...
  },
});
```

### Step 5: Configure Application Routes
In your router configuration (e.g., `App.jsx`):
```jsx
import { Routes, Route } from 'react-router-dom';
import InventoryPage from './systems/inventory/pages/InventoryPage';

function App() {
  return (
    <Routes>
      <Route path="/dashboard/inventory/:tabId?" element={<InventoryPage />} />
    </Routes>
  );
}
```

### Step 6: Environment Variables
Ensure your `.env` contains your Supabase credentials:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

---

## 📊 Summary of System Data Flows

```
[Purchase GRN / Receipt] ──> IN Transaction ──┐
[Customer Order Return]  ──> IN Transaction ──┼──> [IMS Closing Stock Engine]
[Approved Transfer IN]   ──> Transferred Qty ─┘           │
                                                          ├──> [Stock < Reorder Level?] ──> [Auto Indent IND-XXXX]
[Production Job Card]    ──> OUT Transaction ─┐           │
[Finished Goods Dispatch]──> OUT Transaction ─┼──<────────┘
[Approved Transfer OUT]  ──> OUT Transaction ─┤
[Scrap / Damage Entry]   ──> Recycle Log ─────┘
                                   │
[Physical Stock Audit] ──> Variance Count ──> [Approved with Auto-Adj?] ──> [ADJ-PHY Inward/Outward]
```

---

## 📄 License & Attribution
Designed and built for enterprise material planning and manufacturing execution. Clean, modular, and ready for immediate deployment.
