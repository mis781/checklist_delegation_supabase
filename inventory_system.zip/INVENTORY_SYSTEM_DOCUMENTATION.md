# Inventory Management System (IMS) — Comprehensive Technical & Functional Documentation

> **Complete Database Schema, System Architecture, End-to-End Workflows, Page-by-Page Deep-Dive & Form Field Specifications**

---

## 📑 Table of Contents

1. [Executive Summary & System Architecture](#1-executive-summary--system-architecture)
2. [End-to-End Material Lifecycle & System Flow](#2-end-to-end-material-lifecycle--system-flow)
   - 2.1 [Material Lifecycle Flowchart](#21-material-lifecycle-flowchart)
   - 2.2 [Double-Entry Stock Ledger Mechanics](#22-double-entry-stock-ledger-mechanics)
   - 2.3 [Inter-Division Transfer Protocol](#23-inter-division-transfer-protocol)
   - 2.4 [Physical Stock Audit & Auto-Reconciliation Flow](#24-physical-stock-audit--auto-reconciliation-flow)
3. [Data Origins & Cross-System Integrations (Where Data Comes From)](#3-data-origins--cross-system-integrations)
   - 3.1 [Inward Data Streams (Procurement, Order Returns & Transfers)](#31-inward-data-streams)
   - 3.2 [Outward Data Streams (Production Job Cards, Dispatches & Vendor Returns)](#32-outward-data-streams)
   - 3.3 [Cross-System Integration Matrix](#33-cross-system-integration-matrix)
4. [Database Schema & Architecture (`inventory_system_schema.sql`)](#4-database-schema--architecture)
   - 4.1 [Master & Configuration Tables](#41-master--configuration-tables)
   - 4.2 [Central Material Catalog & Division Balances](#42-central-material-catalog--division-balances)
   - 4.3 [Transactions & Job Card Batches](#43-transactions--job-card-batches)
   - 4.4 [Physical Stock Verification](#44-physical-stock-verification)
   - 4.5 [Reorders & Purchase Indents](#45-reorders--purchase-indents)
   - 4.6 [Inter-Division Transfers](#46-inter-division-transfers)
   - 4.7 [Recycling, Scrap & Rejections](#47-recycling-scrap--rejections)
   - 4.8 [System Settings & Audit Log](#48-system-settings--audit-log)
   - 4.9 [Entity-Relationship Diagram (ERD)](#49-entity-relationship-diagram-erd)
5. [Page-by-Page Deep Dive & Functional Specifications](#5-page-by-page-deep-dive--functional-specifications)
   - 5.1 [Page 1: IMS Dashboard (`/dashboard/inventory/dashboard`)](#51-page-1-ims-dashboard)
   - 5.2 [Page 2: Stock IMS Matrix (`/dashboard/inventory/stock`)](#52-page-2-stock-ims-matrix)
   - 5.3 [Page 3: Physical Stock Audit (`/dashboard/inventory/physical-stock`)](#53-page-3-physical-stock-audit)
   - 5.4 [Page 4: Stock Transactions Ledger (`/dashboard/inventory/transactions`)](#54-page-4-stock-transactions-ledger)
   - 5.5 [Page 5: Reorder Management (`/dashboard/inventory/reorder`)](#55-page-5-reorder-management)
   - 5.6 [Page 6: Indent Management (`/dashboard/inventory/indent`)](#56-page-6-indent-management)
   - 5.7 [Page 7: Transfer Request (`/dashboard/inventory/transfer-request`)](#57-page-7-transfer-request)
   - 5.8 [Page 8: Transfer Approval Queue (`/dashboard/inventory/transfer-approval`)](#58-page-8-transfer-approval-queue)
   - 5.9 [Page 9: Inventory Master Settings (`/dashboard/inventory/settings`)](#59-page-9-inventory-master-settings)
   - 5.10 [Page 10: Training Videos & SOPs (`/dashboard/inventory/video`)](#510-page-10-training-videos--sops)
   - 5.11 [Page 11: Audit Trail Log (`AuditLogView`)](#511-page-11-audit-trail-log)
6. [Modal Windows & Form Specifications](#6-modal-windows--form-specifications)
   - 6.1 [Stock Inward / Outward / Job Card Transaction Modal](#61-stock-inward--outward--job-card-transaction-modal)
   - 6.2 [Physical Stock Audit Entry Modal (`PhysicalStockModal.jsx`)](#62-physical-stock-audit-entry-modal)
   - 6.3 [Daily Production Consumption Modal (`DailyConsumptionModal.jsx`)](#63-daily-production-consumption-modal)
   - 6.4 [Scrap, Damage & Recycling Modal (`RecycleModal.jsx`)](#64-scrap-damage--recycling-modal)
   - 6.5 [Inter-Division Transfer Modal (`TransferModal.jsx`)](#65-inter-division-transfer-modal)
   - 6.6 [Batch Detail Factory PDF Generator (`BatchDetailPdfModal.jsx`)](#66-batch-detail-factory-pdf-generator)
   - 6.7 [Master Material & Catalog Modal (`SettingsView.jsx`)](#67-master-material--catalog-modal)
7. [Mathematical Formulas & Stock Calculation Engine](#7-mathematical-formulas--stock-calculation-engine)
   - 7.1 [Dynamic Closing Stock Calculation](#71-dynamic-closing-stock-calculation)
   - 7.2 [Safety Stock & Reorder Point Formulas](#72-safety-stock--reorder-point-formulas)
   - 7.3 [Maximum Stock & Health Band Classification](#73-maximum-stock--health-band-classification)
   - 7.4 [Physical Count Variance & Auto-Ledger Adjustment](#74-physical-count-variance--auto-ledger-adjustment)
8. [State Management, Redux Architecture & Realtime WebSockets](#8-state-management-redux-architecture--realtime-websockets)
   - 8.1 [Redux Slices & Async Thunks](#81-redux-slices--async-thunks)
   - 8.2 [Large Dataset Safe Pagination (`fetchAllRows`)](#82-large-dataset-safe-pagination)
   - 8.3 [Supabase Realtime Subscriptions](#83-supabase-realtime-subscriptions)
9. [Role-Based Access Control (RBAC) & Multi-Tenant Divisions](#9-role-based-access-control-rbac--multi-tenant-divisions)
10. [Deployment, Migration & Setup Guide](#10-deployment-migration--setup-guide)

---

## 1. Executive Summary & System Architecture

The **Inventory Management System (IMS)** is an enterprise-grade material resource planning and warehouse automation platform engineered specifically for manufacturing, fabrication, assembly, and multi-branch distribution enterprises.

It unifies raw material procurement, job card production consumption, finished goods warehousing, inter-unit stock transfers, periodic physical auditing, scrap recycling, and automated reorder replenishment into a single, unified double-entry ledger.

```
       [Purchase GRN / Inward Receipt]
                    ⬇️
    ┌───────────────────────────────────┐
    │     Raw Materials Warehouse       │
    └───────────────────────────────────┘
         ⬇️                        ⬇️
  [Production Job Card]   [Inter-Division Transfer]
         ⬇️                        ⬇️
  [Finished Goods (FG)]    [Target Branch WH]
         ⬇️                        ⬇️
  [O2D Dispatch / Sales]  [Physical Stock Audit & Auto-Adj]
```

### Key Technical Stack
- **Frontend Architecture**: React 18 / 19 with Vite, Tailwind CSS, Lucide React icons, Recharts for analytics, PapaParse for CSV parsing/exporting.
- **State Management**: Redux Toolkit (`@reduxjs/toolkit`) with asynchronous thunks, centralized API adapters, and local storage simulation overrides.
- **Backend / Database**: Supabase (PostgreSQL 15+) with Row-Level Security (RLS), custom trigger procedures, and WebSocket Realtime subscriptions.
- **Reporting & Document Generation**: jsPDF for dynamic factory batch specification sheets and barcoded material tags.
- **Multi-Tenancy**: Built-in division isolation supporting simultaneous multi-firm operations (`Universal / ALL`, `Division A`, `Division B`).

---

## 2. End-to-End Material Lifecycle & System Flow

### 2.1 Material Lifecycle Flowchart

```mermaid
flowchart TD
    subgraph S1["1. INWARD LOGISTICS"]
        PO["Purchase Order"] --> GRN["Material Receipt (GRN)"]
        GRN --> IN_TXN["IN Transaction posted to inventory_transactions"]
        ORD_RET["Customer Order Return"] --> IN_RET["Return IN posted to inventory_transactions"]
        TRF_IN["Approved Inter-Division Transfer"] --> IN_TRF["Transfer IN accumulated into transferred_qty"]
    end

    subgraph S2["2. INVENTORY STORAGE & REAL-TIME BALANCING"]
        IN_TXN --> STOCK["IMS Real-time Closing Stock Engine"]
        IN_RET --> STOCK
        IN_TRF --> STOCK
        STOCK --> HEALTH{"Stock Health Check"}
        HEALTH -- "Stock < Reorder Level" --> RO["Reorder Management Alert"]
        RO --> IND["Purchase Indent (IND-XXXX)"]
        IND --> PO
        HEALTH -- "Normal / Excess" --> PROD_AVAIL["Available for Production / Sale"]
    end

    subgraph S3["3. PRODUCTION & OUTWARD CONSUMPTION"]
        PROD_AVAIL --> JC["Production Job Card Outward"]
        JC --> BATCH["inventory_job_card_batches Breakdown"]
        JC --> OUT_TXN["OUT Transaction posted to inventory_transactions"]
        PROD_AVAIL --> PR_RET["Purchase Return (Vendor RTV)"]
        PR_RET --> OUT_TXN
        PROD_AVAIL --> DISP["O2D Finished Goods Dispatch"]
        DISP --> OUT_TXN
    end

    subgraph S4["4. AUDITING, RECYCLING & SCRAP"]
        OUT_TXN --> SCRAP["Damage / Rejection / Scrap Generation"]
        SCRAP --> RECYCLE["inventory_recycle Entry"]
        RECYCLE --> SCRAP_BAL["Scrap Material Balance Updated"]
        PROD_AVAIL --> PHY["Physical Stock Verification"]
        PHY --> DRAFT["Audit Draft Saved"]
        DRAFT --> SUBMIT["Submitted to Supervisor"]
        SUBMIT --> APPROVE{"Approved & Auto-Adjust?"}
        APPROVE -- Yes --> ADJ_TXN["ADJ-PHY Transaction auto-posted to ledger"]
        ADJ_TXN --> STOCK
    end
```

### 2.2 Double-Entry Stock Ledger Mechanics
IMS enforces strict ledger integrity:
- **No Direct Column Overwrite**: Closing stock is never directly mutated by arbitrary updates. Instead, closing balance is computed dynamically from opening stock plus the delta of all verified ledger movements.
- **Transaction Types**:
  - `IN`: Increases physical stock (Supplier receipts, customer returns, initial stock additions, positive audit adjustments).
  - `OUT`: Decreases physical stock (Production issues, customer dispatches, vendor returns, negative audit adjustments).
  - `Job Card`: Specialized outward consumption linked to manufactured Finished Good (FG) SKUs with detailed batch breakdowns.
- **Immutable Audit Trail**: Every transaction insertion, update, or deletion automatically logs the action, timestamp, operator, and payload into `inventory_audit`.

### 2.3 Inter-Division Transfer Protocol
When material moves between distinct operating divisions:
1. Operator initiates a transfer request via `TransferModal.jsx`.
2. Source division stock availability is verified in real time (`available_qty`).
3. Record is inserted into `inventory_internal_transfer` with status `Pending`.
4. Management reviews the transfer in `TransferApprovalView.jsx`.
5. Upon approval:
   - Status updates to `Approved` with timestamp and approver identity.
   - For the **Target Division**: If the SKU does not exist in `inventory_materials`, a new record is created with opening = 0. The incoming quantity is added to `transferred_qty`.
   - For the **Source Division**: Outward transfer is accounted dynamically in stock calculations.

### 2.4 Physical Stock Audit & Auto-Reconciliation Flow
1. Storekeeper counts actual warehouse stock and enters values in `PhysicalStockModal.jsx`.
2. System computes `difference_qty = physical_qty - system_stock`.
3. Storekeeper can save progress as a `[Draft #ID]` or submit for review (`Pending`).
4. Manager reviews submissions in `PhysicalStockView.jsx`.
5. Upon approval, if `shouldAdjustStock` is toggled on:
   - System automatically generates a compensating transaction in `inventory_transactions`.
   - Positive variance generates an `IN` movement with reference `ADJ-PHY-[ID]`.
   - Negative variance generates an `OUT` movement with reference `ADJ-PHY-[ID]`.
   - `inventory_physical_stock.is_stock_adjusted` is marked `true`.

---

## 3. Data Origins & Cross-System Integrations

### 3.1 Inward Data Streams

| Inward Source | Initiating Module | Target IMS Table | Key Inward Parameters | Trigger / API |
|---|---|---|---|---|
| **Purchase Receipt (GRN)** | Purchase Logistics (`purchaseLogisticsApi.js`) | `inventory_transactions` | `type: 'IN'`, `ref: GRN-XXXX`, `party_name: Supplier`, `qty: Received Qty` | Material receipt confirmation in Purchase module |
| **Customer Order Return** | Order Return (`OrderReturnContext.jsx`) | `inventory_transactions` | `type: 'IN'`, `movement_type: 'Order Return'`, `ref: Return ID`, `qty: Restocked Qty` | Restock approval in Order Return module |
| **Inter-Division Transfer In** | Inventory (`transferApi.js`) | `inventory_materials` & `inventory_internal_transfer` | `transferred_qty: Qty`, `transferred_division: Source Div` | Management approval in Transfer Approval View |
| **Physical Stock Gain** | Inventory (`inventoryApi.js`) | `inventory_transactions` | `type: 'IN'`, `movement_type: 'Physical Stock Adjustment'`, `ref: ADJ-PHY-[ID]` | Supervisor approves physical count with positive variance |
| **Manual / Direct Inward** | Inventory (`StockDashboardView.jsx`) | `inventory_transactions` | `type: 'IN'`, `movement_type: 'Direct Inward'`, `challan_no`, `invoice_no` | Storekeeper posts direct inward modal |

### 3.2 Outward Data Streams

| Outward Source | Initiating Module | Target IMS Table | Key Outward Parameters | Trigger / API |
|---|---|---|---|---|
| **Production Job Card** | Inventory (`StockDashboardView.jsx`) | `inventory_transactions` & `inventory_job_card_batches` | `type: 'OUT'`, `is_job_card: true`, `fg_sku: FG Item`, `batches: [...]` | Production manager creates job card issue |
| **Purchase Return (RTV)** | Purchase Return (`purchaseReturnApi.js`) | `inventory_transactions` | `type: 'OUT'`, `movement_type: 'Purchase Return'`, `ref: PR-XXXX`, `party_name: Vendor` | Return to vendor dispatch confirmation |
| **Order-to-Dispatch (O2D)** | O2D System (`orderDelivery`) | `inventory_transactions` | `type: 'OUT'`, `movement_type: 'Dispatch'`, `invoice_no`, `destination` | Final delivery gate-pass creation |
| **Physical Stock Loss** | Inventory (`inventoryApi.js`) | `inventory_transactions` | `type: 'OUT'`, `movement_type: 'Physical Stock Adjustment'`, `ref: ADJ-PHY-[ID]` | Supervisor approves physical count with negative variance |
| **Scrap / Rejection** | Inventory (`RecycleModal.jsx`) | `inventory_recycle` | `quantity`, `weight`, `damage_type`, `attachment_url` | Storekeeper records scrap/damage |

### 3.3 Cross-System Integration Matrix

```mermaid
graph LR
    P[Purchase System] -- "GRN Inward" --> IT[inventory_transactions]
    PR[Purchase Return] -- "Vendor Return OUT" --> IT
    OR[Order Return] -- "Restock IN" --> IT
    IMS_JC[IMS Job Card] -- "RM Consumption OUT" --> IT
    IMS_JC -- "Multi-Batch Data" --> JMB[inventory_job_card_batches]
    IMS_PHY[IMS Physical Audit] -- "Auto Adj IN/OUT" --> IT
    IT --> IMS_STOCK[IMS Closing Stock Engine]
    IMS_STOCK -- "Stock < Reorder" --> IND[inventory_indents]
    IND -- "Purchase Requisition" --> P
    IMS_TRF[Inter-Division Transfer] -- "Transfer Stock" --> IM[inventory_materials]
    REC[Recycle / Scrap] -- "Weight / Qty" --> IR[inventory_recycle]
    IR --> IMS_STOCK
```

---

## 4. Database Schema & Architecture

The database is built on relational PostgreSQL tables inside Supabase. The migration script is located at `supabase/inventory_system_schema.sql`.

### 4.1 Master & Configuration Tables

#### `divisions`
Operating firms, branches, and legal entities.
```sql
CREATE TABLE public.divisions (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    code VARCHAR(50),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `material_types`
Classification types for materials across the enterprise.
```sql
CREATE TABLE public.material_types (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE, -- 'Finished Goods', 'Raw Material', etc.
    type_code VARCHAR(50) NOT NULL UNIQUE, -- 'FG', 'RM', 'SPARE', 'WIP', 'CONSUMABLE'
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `inventory_units`
Universal units of measurement (UoM).
```sql
CREATE TABLE public.inventory_units (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    unit VARCHAR(50) NOT NULL UNIQUE,       -- 'KG', 'MTR', 'PCS', 'LTR', etc.
    description VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `inventory_categories`
Product hierarchy categories scoped by division and material type.
```sql
CREATE TABLE public.inventory_categories (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    division VARCHAR(100),
    material_type VARCHAR(50) DEFAULT 'ALL',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_category_name_div UNIQUE (name, division)
);
```

#### `inventory_locations`
Specific warehouse bins, racks, and plant storage zones.
```sql
CREATE TABLE public.inventory_locations (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    location VARCHAR(150) NOT NULL,          -- e.g., 'WH-A / Rack 4'
    division VARCHAR(100),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_location_name_div UNIQUE (location, division)
);
```

---

### 4.2 Central Material Catalog & Division Balances

#### `inventory_master_material`
Central enterprise master material directory for all items (both Raw Materials and Finished Goods).
```sql
CREATE TABLE public.inventory_master_material (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    sku VARCHAR(100),
    name VARCHAR(255) NOT NULL,
    material_type VARCHAR(50) NOT NULL DEFAULT 'RM',
    category VARCHAR(150) NOT NULL DEFAULT 'RAW MATERIAL',
    sub_category VARCHAR(150),
    division VARCHAR(100) NOT NULL DEFAULT 'ALL',
    hsn_code VARCHAR(50),
    status VARCHAR(50) NOT NULL DEFAULT 'Active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `inventory_materials`
Division-specific material parameters, reorder thresholds, and baseline opening balances.
```sql
CREATE TABLE public.inventory_materials (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    master_material_id BIGINT REFERENCES public.inventory_master_material(id) ON DELETE SET NULL,
    category VARCHAR(150) NOT NULL,
    sub_category VARCHAR(150),
    material_type VARCHAR(50) NOT NULL DEFAULT 'RM',
    unit VARCHAR(50) NOT NULL,
    location VARCHAR(150),
    division VARCHAR(100) NOT NULL DEFAULT 'ALL',
    opening NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    adc NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    lead_time NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    safety_factor NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    moq NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    supplier_name VARCHAR(255),
    supplier_code VARCHAR(100),
    status VARCHAR(50) NOT NULL DEFAULT 'Active',
    transferred_division VARCHAR(100),
    transferred_qty NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    transfer_date DATE,
    transfer_id BIGINT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_material_sku_division UNIQUE (sku, division)
);
```

---

### 4.3 Transactions & Job Card Batches

#### `inventory_transactions`
The immutable double-entry movement ledger.
```sql
CREATE TABLE public.inventory_transactions (
    id VARCHAR(50) PRIMARY KEY,                  -- e.g., 'TXN-00001'
    date DATE NOT NULL,
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    material_id BIGINT REFERENCES public.inventory_master_material(id) ON DELETE SET NULL,
    material_type VARCHAR(50) NOT NULL DEFAULT 'RM',
    qty NUMERIC(14, 2) NOT NULL,
    scraps NUMERIC(14, 2) DEFAULT 0.00,
    type VARCHAR(50) NOT NULL,                   -- 'IN' | 'OUT' | 'Job Card'
    movement_type VARCHAR(100) NOT NULL,         -- 'Goods Receipt', 'Direct Issue', etc.
    ref VARCHAR(150),
    remarks TEXT,
    user_name VARCHAR(150),
    firm VARCHAR(100),
    is_job_card BOOLEAN NOT NULL DEFAULT false,
    job_card_id VARCHAR(100),
    fg_sku VARCHAR(100),
    billing_date DATE,
    receiving_date DATE,
    party_name VARCHAR(255),
    destination VARCHAR(255),
    challan_no VARCHAR(100),
    invoice_no VARCHAR(100),
    vehicle_no VARCHAR(100),
    fg_category VARCHAR(150),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### `inventory_job_card_batches`
Detailed batch consumption breakdown for production job cards.
```sql
CREATE TABLE public.inventory_job_card_batches (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    transaction_id VARCHAR(50) NOT NULL REFERENCES public.inventory_transactions(id) ON DELETE CASCADE,
    batch_number INTEGER NOT NULL,
    sku VARCHAR(100) NOT NULL,
    material_name VARCHAR(255) NOT NULL,
    qty NUMERIC(14, 2) NOT NULL,
    num_batches NUMERIC(10, 2),
    remaining_batches NUMERIC(10, 2),
    remaining_material NUMERIC(14, 2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 4.4 Physical Stock Verification

#### `inventory_physical_stock`
Physical stock counts, audit verification, and variance records.
```sql
CREATE TABLE public.inventory_physical_stock (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    material_type VARCHAR(50) NOT NULL DEFAULT 'RM',
    division VARCHAR(100) NOT NULL DEFAULT 'ALL',
    location VARCHAR(150),
    unit VARCHAR(50),
    system_stock NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    physical_qty NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    difference_qty NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    counted_by VARCHAR(150) NOT NULL,
    counted_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(50) NOT NULL DEFAULT 'Pending', -- 'Draft', 'Pending', 'Approved', 'Rejected'
    reviewed_by VARCHAR(150),
    reviewed_at TIMESTAMPTZ,
    review_remarks TEXT,
    remarks TEXT,
    is_stock_adjusted BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 4.5 Reorders & Purchase Indents

#### `inventory_indents`
Procurement requisitions triggered manually or auto-generated by the reorder engine.
```sql
CREATE TABLE public.inventory_indents (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY,
    indent_no VARCHAR(50) PRIMARY KEY,           -- e.g., 'IND-0001'
    date DATE NOT NULL,
    requested_by VARCHAR(150) NOT NULL,
    department VARCHAR(100) NOT NULL DEFAULT 'General',
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    material_type VARCHAR(50) NOT NULL DEFAULT 'RM',
    source VARCHAR(50) NOT NULL DEFAULT 'Manual',
    current_stock NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    reorder_qty NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    supplier_name VARCHAR(255),
    status VARCHAR(50) NOT NULL DEFAULT 'Pending',
    firm VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 4.6 Inter-Division Transfers

#### `inventory_internal_transfer`
Inter-warehouse and inter-division inventory transfer requisitions.
```sql
CREATE TABLE public.inventory_internal_transfer (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    from_division VARCHAR(100) NOT NULL,
    to_division VARCHAR(100) NOT NULL,
    sku_code VARCHAR(100) NOT NULL,
    sku_name VARCHAR(255) NOT NULL,
    unit VARCHAR(50),
    quantity NUMERIC(14, 2) NOT NULL,
    available_qty NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    transfer_date DATE NOT NULL,
    operator_name VARCHAR(150) NOT NULL,
    remarks TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'Pending',
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    approver_name VARCHAR(150),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 4.7 Recycling, Scrap & Rejections

#### `inventory_recycle`
Scrap generation, damaged material logging, and rejection recycling tracking.
```sql
CREATE TABLE public.inventory_recycle (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    recycle_type VARCHAR(100) NOT NULL,          -- 'Scrap', 'Rejection', 'Re-melt', 'Return'
    firm VARCHAR(100),
    material_name VARCHAR(255) NOT NULL,
    material_sku VARCHAR(100),
    quantity NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    weight NUMERIC(14, 3),                       -- Weight in KG
    damage_type VARCHAR(100),                    -- 'Transit Damage', 'Production Scrap', etc.
    date DATE NOT NULL,
    reason TEXT,
    approved_by VARCHAR(150),
    attachment_url TEXT,                         -- Supabase Storage Public URL
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

### 4.8 System Settings & Audit Log

#### `inventory_settings`
Singleton user preferences and pagination limits.
```sql
CREATE TABLE public.inventory_settings (
    id INTEGER PRIMARY KEY DEFAULT 1,
    page_size_master INTEGER NOT NULL DEFAULT 6,
    page_size_txn INTEGER NOT NULL DEFAULT 6,
    page_size_stock INTEGER NOT NULL DEFAULT 6,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT chk_singleton_inventory_settings CHECK (id = 1)
);
```

#### `inventory_audit`
Immutable system audit log for all user and API interactions.
```sql
CREATE TABLE public.inventory_audit (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    action VARCHAR(150) NOT NULL,
    user_name VARCHAR(150),
    detail TEXT
);
```

---

### 4.9 Entity-Relationship Diagram (ERD)

```mermaid
erDiagram
    DIVISIONS ||--o{ INVENTORY_MATERIALS : belongs_to
    DIVISIONS ||--o{ INVENTORY_TRANSACTIONS : executed_in
    DIVISIONS ||--o{ INVENTORY_CATEGORIES : scopes
    DIVISIONS ||--o{ INVENTORY_LOCATIONS : scopes

    INVENTORY_MASTER_MATERIAL ||--o{ INVENTORY_MATERIALS : references
    INVENTORY_MASTER_MATERIAL ||--o{ INVENTORY_TRANSACTIONS : classifies

    INVENTORY_MATERIALS ||--o{ INVENTORY_TRANSACTIONS : records_moves
    INVENTORY_MATERIALS ||--o{ INVENTORY_INDENTS : triggers_reorder
    INVENTORY_MATERIALS ||--o{ INVENTORY_PHYSICAL_STOCK : audits

    INVENTORY_TRANSACTIONS ||--o{ INVENTORY_JOB_CARD_BATCHES : contains_batches
    INVENTORY_INTERNAL_TRANSFER ||--o{ INVENTORY_MATERIALS : creates_or_increments
    INVENTORY_RECYCLE ||--o{ INVENTORY_MATERIALS : impacts_scrap_balance
```

---

## 5. Page-by-Page Deep Dive & Functional Specifications

### 5.1 Page 1: IMS Dashboard (`/dashboard/inventory/dashboard`)
The central executive summary view providing key inventory health indicators, financial exposure estimates, and real-time activity feeds.

- **KPI Cards**:
  1. *Total Catalog SKUs*: Total count of active materials in the system.
  2. *Low Stock Alerts*: Count of items currently operating below safety reorder levels.
  3. *Pending Indents*: Open procurement requisitions awaiting purchase action.
  4. *Pending Stock Transfers*: Inter-division transfers awaiting manager sign-off.
- **Visual Analytics**:
  - *Stock Health Distribution*: Pie/Donut chart breaking down inventory into Excess, Normal, 66.33%, and Below 33% bands.
  - *Monthly Consumption & Receipt Trends*: Bar charts comparing total Inward (GRN) vs Outward (Job Card/Dispatch) movements.
  - *Category-Wise Value & Stock Breakdown*: Inventory volume segmented by Raw Materials, Packaging, Finished Goods, and Scrap.
- **Action Widgets**:
  - One-click shortcuts to Post Transaction, Create Indent, and Launch Physical Stock Audit.

### 5.2 Page 2: Stock IMS Matrix (`/dashboard/inventory/stock`)
The workhorse table and live operational matrix of the inventory system.

- **Dual-Catalog Toggle**: Seamlessly switch between **Raw Materials (RM)** and **Finished Goods (FG)**.
- **Grid Columns**:
  - `S.No`: Sequential row index.
  - `SKU Code`: Unique item identifier with copy-to-clipboard pill.
  - `Material Name`: Full descriptive title.
  - `Category & Sub-Category`: Classification tags.
  - `UoM`: Unit of measurement (`KG`, `MTR`, `PCS`, etc.).
  - `Location / Bin`: Warehouse rack location.
  - `Opening Stock`: Division baseline stock.
  - `Total IN`: Cumulative receipts (`Transactions IN + Approved Transfer IN`).
  - `Total OUT`: Cumulative issues (`Transactions OUT + Transfer OUT`).
  - `Closing Stock`: Real-time net available stock (highlighted with color-coded health badges).
  - `Reorder Level & Safety Stock`: Calculated dynamic thresholds.
  - `Physical Stock Badge`: Quick indicator showing status and variance of the latest physical audit.
- **Top Bar Controls**:
  - Multi-attribute search (SKU, Name, Category, Location, Supplier).
  - Division / Firm filter dropdown.
  - Stock Health filter (All, Excess, Normal, Below 33%).
  - Action Buttons:
    - `+ Post Transaction`: Opens the universal transaction modal.
    - `Daily Consumption`: Launches daily consumption & RM-to-FG conversion view.
    - `Recycle & Scrap`: Opens scrap/rejection modal.
    - `Batch Detail PDF`: Generates factory-standard batch detail PDF for production runs.
    - `Export Excel/CSV`: Instant download of the filtered grid.

### 5.3 Page 3: Physical Stock Audit (`/dashboard/inventory/physical-stock`)
Ensures physical warehouse accountability by recording ground-truth counts against system balances.

- **Status Tabs**:
  - `Pending Reviews`: Counts submitted by operators awaiting manager review.
  - `Drafts`: Incomplete audit sheets saved by warehouse operators.
  - `Approved & Reconciled`: Historical audit records with auto-adjust status.
  - `Rejected`: Counts returned to operators for recount.
- **Audit Grid Columns**:
  - `Count Date & Time`: Timestamp of count.
  - `SKU & Material Name`: Target item.
  - `Division & Location`: Storage zone verified.
  - `System Stock`: Expected balance in IMS at count time.
  - `Physical Qty`: Ground-truth quantity counted by the operator.
  - `Variance / Difference`: `physical_qty - system_stock` (Green `+` for excess, Red `-` for shortage).
  - `Counted By`: Identity of the counting operator.
  - `Review Status`: Current lifecycle state.
  - `Auto-Adjusted`: Pill indicating whether an `ADJ-PHY` transaction was written to the ledger.
- **Manager Approval Actions**:
  - *Approve Count*: Validates the count. Includes an optional checkbox: **"Auto-Adjust Stock Balance"**. When checked, IMS automatically injects an `ADJ-PHY` transaction into `inventory_transactions`, instantly syncing the ledger.
  - *Reject Count*: Returns count to operator with mandatory feedback remarks.
  - *Bulk Review*: Select multiple pending counts to approve or reject simultaneously.

### 5.4 Page 4: Stock Transactions Ledger (`/dashboard/inventory/transactions`)
The comprehensive, immutable ledger of all stock movements.

- **Ledger Columns**:
  - `Transaction ID`: Formatted identifier (`TXN-00001`).
  - `Date`: Date of material movement.
  - `Movement Type`: `IN` (Green badge) vs `OUT` (Rose badge) vs `Job Card` (Amber badge).
  - `SKU & Material`: Item details.
  - `Quantity & Scraps`: Quantity moved and any associated scrap recorded.
  - `Reference`: PO number, GRN number, Invoice number, Challan number, or Job Card ID.
  - `Party / Destination`: Vendor name, Customer name, or receiving plant.
  - `Operator`: User who posted the transaction.
  - `Division / Firm`: Operating entity.
- **Job Card Batch Expander**: Clicking a Job Card transaction expands the row to show the multi-batch raw material consumption breakdown (`inventory_job_card_batches`).
- **Audit Features**:
  - Inline editing of reference documents (Invoice, Challan, Vehicle No).
  - Single and bulk transaction deletion (Administrator only) with mandatory audit justification.
  - Date range filtering and PapaParse CSV export.

### 5.5 Page 5: Reorder Management (`/dashboard/inventory/reorder`)
Automated replenishment engine identifying low-stock items before stockouts occur.

- **Low Stock Filter**: Automatically isolates materials where `Closing Stock < Reorder Level`.
- **Exclusion Logic**: Automatically filters out items that already have a pending or approved purchase indent (`IND-XXXX`), preventing duplicate ordering.
- **Calculation Columns**:
  - `Current Closing Stock`: Actual available stock.
  - `Average Daily Consumption (ADC)`: Daily burn rate.
  - `Lead Time (Days)`: Vendor delivery timeline.
  - `Safety Buffer`: Calculated safety buffer quantity.
  - `Reorder Level`: Threshold trigger point.
  - `Suggested Reorder Qty`: Recommended procurement quantity based on Minimum Order Quantity (MOQ).
  - `Primary Supplier`: Preferred vendor name and supplier code.
- **Bulk Indent Creation**: Operators can select multiple low-stock items and click **"Generate Purchase Indents"**, instantly creating official procurement requisitions.

### 5.6 Page 6: Indent Management (`/dashboard/inventory/indent`)
Requisition tracking bridging the warehouse team with the procurement department.

- **Indent Lifecycle States**:
  - `Pending`: Awaiting procurement review.
  - `Approved`: Indent cleared for PO generation.
  - `PO Raised`: Procurement team has issued a Purchase Order.
  - `Completed`: Material has arrived and GRN has been posted.
  - `Rejected`: Requisition declined with remarks.
- **Grid Columns**:
  - `Indent No`: Auto-incremented sequence (`IND-0001`).
  - `Date`: Creation date.
  - `Requested By & Department`: Initiating operator and cost center.
  - `SKU & Description`: Requested material.
  - `Closing Stock at Request`: Baseline stock when indent was created.
  - `Reorder Qty`: Quantity requested.
  - `Assigned Supplier`: Target vendor.
  - `Status Dropdown`: Lifecycle status update control.

### 5.7 Page 7: Transfer Request (`/dashboard/inventory/transfer-request`)
Initiation portal for inter-division and inter-plant material transfers.

- **Transfer Form**:
  - *Source Division*: Division where stock currently resides.
  - *Destination Division*: Division receiving the material.
  - *Material SKU & Name*: Searchable dropdown displaying source division available stock.
  - *Transfer Quantity*: Validated against available stock (prevents over-transfer).
  - *Transfer Date & Operator*: Timestamp and user tracking.
  - *Remarks / Purpose*: Transfer justification.
- **Historical Request Feed**: Displays recent transfers submitted by the user with real-time approval status badges.

### 5.8 Page 8: Transfer Approval Queue (`/dashboard/inventory/transfer-approval`)
Management portal for reviewing, approving, and rejecting inter-division transfer requests.

- **Queue Table**:
  - Lists all `Pending` transfers across divisions.
  - Displays source division closing stock, requested quantity, transfer date, and operator remarks.
- **Approval Actions**:
  - *Approve*: Triggers real-time material creation/accumulation in the target division and logs approval timestamp.
  - *Reject*: Cancels the transfer and preserves source stock.
  - *Bulk Approve / Reject*: Multi-row batch action.

### 5.9 Page 9: Inventory Master Settings (`/dashboard/inventory/settings`)
Configuration panel for materials, master lists, units, locations, and pagination.

- **Sub-Tabs**:
  1. *Materials Master*: Create and edit division-specific materials, opening stocks, ADC, lead time, safety factor, MOQ, and vendor assignments.
  2. *Central Catalog*: Add/manage enterprise-wide Raw Materials and Finished Goods in `inventory_master_material`.
  3. *Categories & Sub-Categories*: Manage hierarchical category taxonomy.
  4. *Units of Measurement (UoM)*: Add/edit measurement units (`KG`, `MTR`, `PCS`, etc.).
  5. *Storage Locations*: Define warehouse racks and plant locations.
  6. *Pagination Settings*: Set table page size for Master, Stock, and Transactions.
  7. *Role Simulation Switcher*: Dev/test feature to simulate different roles (Admin, Storekeeper, Operator) and divisions.

### 5.10 Page 10: Training Videos & SOPs (`/dashboard/inventory/video`)
Standard Operating Procedures (SOPs) and video tutorials for warehouse personnel.

- Curated video library on:
  - How to perform physical stock counts.
  - Proper job card outward consumption recording.
  - Handling scrap and damage entries.
  - Processing inter-division transfers.

### 5.11 Page 11: Audit Trail Log (`AuditLogView`)
System-wide immutable activity feed recording all user actions.

- Displays timestamp, action type (e.g., `Material created`, `Transaction posted`, `Physical count reviewed`), operator name, and detailed JSON payload summary.

---

## 6. Modal Windows & Form Specifications

### 6.1 Stock Inward / Outward / Job Card Transaction Modal

Accessible from the Stock IMS Matrix by clicking **"+ Post Transaction"**.

| Field Name | Component Type | Required | Default Value | Validation & Rules |
|---|---|---|---|---|
| `Transaction Type` | Tab / Pill Selector | Yes | `IN` | Options: `IN` (Receipt), `OUT` (Issue), `Job Card` (Production Issue). |
| `Date` | Date Input | Yes | Current Date | Cannot be empty. Formatted `YYYY-MM-DD`. |
| `Division / Firm` | Dropdown Select | Yes | User Division | Restricted to user's permitted divisions. |
| `SKU / Material Name` | Searchable Dropdown | Yes | Empty | Auto-completes from active materials in the selected division. |
| `Quantity` | Numeric Input | Yes | `0` | Must be strictly > 0. For `OUT`, warns if `Qty > Closing Stock`. |
| `Scraps Quantity` | Numeric Input | No | `0` | Optional scrap generated during the transaction. |
| `Reference Document` | Text Input | No | Empty | Invoice No, PO No, Delivery Challan, or Work Order ID. |
| `Party / Vendor / Customer` | Text Input | No | Empty | Name of the supplier or client. |
| `Destination / Plant` | Text Input | No | Empty | Receiving machine, plant line, or dispatch destination. |
| `Vehicle Number` | Text Input | No | Empty | Logistics transport vehicle registration number. |
| `Remarks` | Textarea | No | Empty | Explanatory notes. |
| **Job Card Fields (Conditional on Type = Job Card)** | | | | |
| `Job Card ID` | Text Input | Yes (if JC) | Empty | Work order identifier (e.g., `JC-2026-001`). |
| `Finished Good (FG) SKU` | Searchable Dropdown | Yes (if JC) | Empty | Selects target produced item from FG catalog. |
| `Multi-Batch Breakdown` | Dynamic Table | No | 1 Batch | Allows adding multiple batch rows with batch number, SKU, consumption qty, and remaining material. |

### 6.2 Physical Stock Audit Entry Modal (`PhysicalStockModal.jsx`)

Used by storekeepers to record ground-truth inventory counts.

| Field Name | Component Type | Required | Validation & Rules |
|---|---|---|---|
| `Division / Firm` | Dropdown Select | Yes | Selects operating division being audited. |
| `Warehouse Location` | Dropdown Select | No | Filter by specific rack or warehouse zone. |
| `Count Date` | DateTime Input | Yes | Defaults to current device timestamp. |
| `Auditor Name` | Text Input | Yes | Defaults to logged-in user name. |
| **Material Count Table** | Dynamic Matrix | | |
| `Material SKU & Name` | Searchable Select | Yes | Loaded from division catalog. |
| `System Stock` | Read-only Display | — | Auto-fetched from real-time IMS calculation. |
| `Physical Qty` | Numeric Input | Yes | Ground-truth count entered by auditor. |
| `Variance (Diff)` | Computed Display | — | Auto-calculated: `physical_qty - system_stock`. |
| `Remarks` | Text Input | No | Reason for discrepancy (damage, misplaced, shrinkage). |
| **Actions** | | | |
| *Save as Draft* | Button | — | Saves count with `[Draft #ID]` tag; status = `Pending` (editable). |
| *Submit for Review* | Button | — | Submits count to supervisor queue; status = `Pending`. |

### 6.3 Daily Production Consumption Modal (`DailyConsumptionModal.jsx`)

Analyzes daily shop-floor raw material burn rates and Finished Goods conversion.

- **Ledger View**: Aggregates daily outflows grouped by date, material type (RM vs FG), product, and destination plant.
- **RM to FG Conversion View**: Compares input raw material weight against output finished goods weight to compute manufacturing yield and wastage percentage.
- **Date Filters**: Quick presets (`Today`, `Yesterday`, `Last 7 Days`, `Custom Range`).
- **CSV Export**: Exports daily consumption sheet via PapaParse.

### 6.4 Scrap, Damage & Recycling Modal (`RecycleModal.jsx`)

Captures manufacturing scrap, quality rejections, and transit damages.

| Field Name | Component Type | Required | Validation & Rules |
|---|---|---|---|
| `Recycle Type` | Dropdown Select | Yes | Options: `Production Scrap`, `Quality Rejection`, `Transit Damage`, `Re-melt`. |
| `Division / Firm` | Dropdown Select | Yes | Operating division where scrap occurred. |
| `Material Name & SKU` | Searchable Select | Yes | Item being scrapped. Auto-detects if item is a designated scrap material. |
| `Quantity (Pieces)` | Numeric Input | Yes | Number of defective/scrapped units. |
| `Weight (Kilograms)` | Numeric Input | Conditional | Required for scrap metal, polymers, and raw material waste. |
| `Damage Type` | Dropdown Select | Yes | Options: `Crack`, `Dimension Out`, `Surface Blemish`, `Contaminated`. |
| `Date` | Date Input | Yes | Date damage was detected. |
| `Reason / Observations`| Textarea | No | Defect details and root-cause notes. |
| `Photo Attachment` | File Upload | No | Uploads image to Supabase Storage bucket `inventory-attachments`. |

### 6.5 Inter-Division Transfer Modal (`TransferModal.jsx`)

Facilitates inter-branch material movements.

| Field Name | Component Type | Required | Validation & Rules |
|---|---|---|---|
| `From Division` | Dropdown Select | Yes | Originating warehouse firm. |
| `To Division` | Dropdown Select | Yes | Receiving warehouse firm (must differ from From Division). |
| `Material SKU & Name` | Searchable Select | Yes | Populated with materials having active stock in From Division. |
| `Available Stock` | Read-only Display | — | Real-time closing stock at the source division. |
| `Transfer Quantity` | Numeric Input | Yes | Must be > 0 and <= Available Stock. |
| `Transfer Date` | Date Input | Yes | Scheduled or dispatch date. |
| `Operator Name` | Text Input | Yes | Storekeeper executing the transfer. |
| `Remarks` | Textarea | No | Transport details, vehicle number, or branch request ID. |

### 6.6 Batch Detail Factory PDF Generator (`BatchDetailPdfModal.jsx`)

Generates the standard factory-floor batch detail specification sheet matching strict industrial layout standards.

- **Template Engine**: `batchDetailPdfTemplate.js` utilizing `jsPDF` vector coordinate mapping.
- **Page Specifications**: True A4 dimensions ($210 \times 297\text{ mm}$), $6\text{ mm}$ margins, industrial header styling.
- **Automated Filtering**: Includes only raw materials with active opening stock > 0.
- **Grouping**: Merges materials sharing common categories with combined span cells.
- **Write-in Sections**: Generates factory-floor pen-and-paper tracking blocks for Operator Sign, Batch Weight, Tare Weight, and QA Clearance.

### 6.7 Master Material & Catalog Modal (`SettingsView.jsx`)

Used to register new items in the central catalog or configure division-level parameters.

| Field Name | Component Type | Required | Validation & Rules |
|---|---|---|---|
| `SKU Code` | Text Input | Yes | Unique item code (e.g., `SKU-1001`). Auto-uppercased. |
| `Material Name` | Text Input | Yes | Descriptive title. |
| `Material Type` | Dropdown Select | Yes | Options: `Raw Material (RM)`, `Finished Goods (FG)`, `Spare Parts`, `Consumables`. |
| `Category & Sub-Category`| Dropdown / Text | Yes | Classification category. Auto-registered if new. |
| `Unit of Measurement` | Dropdown Select | Yes | Select from `inventory_units` (`KG`, `MTR`, `PCS`, etc.). |
| `Storage Location` | Dropdown / Text | No | Rack or bin location. |
| `Division` | Dropdown Select | Yes | Target operating division or `ALL`. |
| `Opening Stock` | Numeric Input | Yes | Baseline stock quantity at system migration. |
| `Average Daily Consumption (ADC)` | Numeric Input | No | Units consumed per day on average. |
| `Lead Time (Days)` | Numeric Input | No | Vendor procurement lead time in calendar days. |
| `Safety Factor (Days)` | Numeric Input | No | Buffer multiplier days. |
| `Minimum Order Qty (MOQ)` | Numeric Input | No | Minimum procurement packaging lot size. |
| `Preferred Supplier` | Text Input | No | Vendor name and supplier code. |
| `Status` | Dropdown Select | Yes | `Active` or `Inactive`. |

---

## 7. Mathematical Formulas & Stock Calculation Engine

### 7.1 Dynamic Closing Stock Calculation

IMS uses distinct mathematical formulas depending on whether an item is a **Regular Material** (Raw Material or Finished Good) or a **Designated Scrap Material**:

#### Formula for Regular Materials (RM & FG)
$$\text{Closing Stock} = \text{Opening} + (\text{Total IN} - \text{Total OUT}) - \text{Direct Rejections}$$

Where:
- $\text{Opening}$: Baseline stock recorded in `inventory_materials.opening`.
- $\text{Total IN} = \sum \text{Transactions}_{\text{IN}} + \sum \text{Transfers}_{\text{Approved IN}}$.
- $\text{Total OUT} = \sum \text{Transactions}_{\text{OUT}} + \sum \text{Transfers}_{\text{Approved OUT}}$.
- $\text{Direct Rejections} = \sum \text{Recycle}_{\text{Quantity}}$ (for rejected units of this specific material).

#### Formula for Scrap Materials
Scrap materials accumulate weight from both direct scrap logging and Finished Goods manufacturing rejections:
$$\text{Closing Stock}_{\text{Scrap}} = \text{Opening} + (\text{Total IN} - \text{Total OUT}) + \text{Direct Scrap Qty} + \text{FG Scrap Weight}$$

Where:
- $\text{FG Scrap Weight}$: Net weight in kilograms contributed by rejections of finished goods linked to this scrap category.

### 7.2 Safety Stock & Reorder Point Formulas

$$\text{Safety Stock} = \text{ADC} \times \text{Safety Factor}$$

$$\text{Reorder Level (ROP)} = (\text{ADC} \times \text{Lead Time}) + \text{Safety Stock}$$

$$\text{Maximum Stock Level} = \text{Reorder Level} + \text{MOQ}$$

Where:
- $\text{ADC}$: Average Daily Consumption.
- $\text{Lead Time}$: Supplier procurement timeline in days.
- $\text{Safety Factor}$: Buffer days to absorb supply chain shocks.
- $\text{MOQ}$: Minimum Order Quantity.

### 7.3 Maximum Stock & Health Band Classification

Each material's inventory health is continuously categorized based on current closing stock relative to the Maximum Stock Level ($\text{Max}$):

$$\text{Stock Health \%} = \left(\frac{\text{Closing Stock}}{\text{Maximum Stock Level}}\right) \times 100$$

| Stock Percentage ($\%$) | Health Classification | Visual Badge | Operational Meaning |
|---|---|---|---|
| $> 100\%$ | **Excess Stock** | Blue Badge | Overstocked; capital tied up. Restrict further purchasing. |
| $66.33\% - 100\%$ | **Normal Stock** | Green Badge | Healthy inventory balance; optimal buffer maintained. |
| $33.00\% - 66.33\%$ | **66.33% Stock** | Yellow Badge | Stock declining; monitor consumption pace. |
| $< 33.00\%$ | **Below 33% (Critical)** | Red Badge | Critical stockout risk; immediate reorder indent required. |

### 7.4 Physical Count Variance & Auto-Ledger Adjustment

During physical stock counting:
$$\text{Difference Qty} = \text{Physical Qty} - \text{System Stock}$$

When approved with auto-adjustment enabled:
- If $\text{Difference Qty} > 0$: An `IN` transaction is created with $\text{Qty} = |\text{Difference Qty}|$ and movement type `Physical Stock Adjustment`.
- If $\text{Difference Qty} < 0$: An `OUT` transaction is created with $\text{Qty} = |\text{Difference Qty}|$ and movement type `Physical Stock Adjustment`.
- If $\text{Difference Qty} = 0$: No adjustment transaction is required; physical count is logged as verified.

---

## 8. State Management, Redux Architecture & Realtime WebSockets

### 8.1 Redux Slices & Async Thunks

IMS state is centralized in Redux Toolkit across two primary slices:
1. `src/redux/slice/inventorySlice.js`: Manages materials, transactions, indents, master catalog, physical stock counts, scrap recycling, and system settings.
2. `src/redux/slice/transferSlice.js`: Manages inter-division transfer requests and approval workflows.

#### Key Thunks in `inventorySlice`:
- `fetchInventoryData`: Executes parallel Supabase fetches for all 15 inventory tables.
- `saveMaterial`: Upserts material master data with automatic category synchronization.
- `postTransaction`: Posts stock movements with atomic ID sequence generation and batch creation.
- `updateTransaction` & `deleteTransaction`: Modifies or deletes movements with audit logging.
- `submitPhysicalStockCount`: Submits ground-truth counts and draft sheets.
- `reviewPhysicalStock` & `bulkReviewPhysicalStock`: Executes manager approval and optional auto-adjustment.
- `createIndents`: Generates official procurement requisitions from reorder alerts.

### 8.2 Large Dataset Safe Pagination (`fetchAllRows`)

PostgREST enforces a default 1,000-row response limit per HTTP request. In high-volume manufacturing environments, `inventory_transactions` quickly surpasses 1,000 rows.

A naive `.select('*')` would truncate historical records, causing older job cards and receipts to vanish from Redux state.

To guarantee complete ledger hydration, IMS implements the recursive `fetchAllRows` engine in `inventoryApi.js`:

```javascript
const fetchAllRows = async (table, { select = '*', orderColumn = 'id', ascending = true, pageSize = 1000 } = {}) => {
  let rows = [];
  let from = 0;
  while (true) {
    let query = supabase
      .from(table)
      .select(select)
      .order(orderColumn, { ascending });
    if (orderColumn !== 'id') query = query.order('id', { ascending: true });
    const { data, error } = await query.range(from, from + pageSize - 1);
    if (error) return { data: null, error };
    rows = rows.concat(data || []);
    if (!data || data.length < pageSize) break;
    from += pageSize;
  }
  return { data: rows, error: null };
};
```

### 8.3 Supabase Realtime Subscriptions

`InventoryPage.jsx` establishes persistent WebSocket listeners on component mount:
- `internal-transfer-watch`: Listens to `*` events on `inventory_internal_transfer`. Whenever a transfer is submitted, approved, or rejected by any operator, all connected clients automatically refresh their transfer lists and stock balances.
- `inventory-recycle-watch`: Listens to `*` events on `inventory_recycle` to immediately update scrap balances across all client sessions.

---

## 9. Role-Based Access Control (RBAC) & Multi-Tenant Divisions

### 9.1 Access Levels
- **Administrator / SuperAdmin**: Unrestricted access to all tabs, master data configuration, transaction deletions, physical audit approvals, and settings.
- **Storekeeper / Warehouse Manager**: Access to IMS Stock, Physical Stock auditing, Posting Transactions, Indent creation, and Transfer requests.
- **Production Operator**: Access restricted to posting Job Card consumption and viewing the IMS stock matrix.
- **Auditor / Viewer**: Read-only access across the stock matrix and transaction ledger.

### 9.2 Division Multi-Tenancy
- Users are assigned permitted operating divisions (`localStorage.getItem('division')`).
- In multi-firm environments, users only view stock, transactions, and reorders belonging to their authorized division.
- System administrators can toggle the **Simulated Division Switcher** in settings to inspect branch balances across `Universal / ALL`, `Division A`, or `Division B`.

---

## 10. Deployment, Migration & Setup Guide

### 10.1 Database Migration
1. Open your Supabase project dashboard.
2. Navigate to the **SQL Editor**.
3. Load and execute `supabase/inventory_system_schema.sql`.
4. Verify that all 15 tables, indexes, triggers, and RLS policies are created successfully.

### 10.2 Storage Bucket Configuration
Ensure the `inventory-attachments` storage bucket exists and is set to public:
```sql
INSERT INTO storage.buckets (id, name, public)
VALUES ('inventory-attachments', 'inventory-attachments', true)
ON CONFLICT (id) DO UPDATE SET public = true;
```

### 10.3 Environment Variables
Configure your `.env` file with your Supabase credentials:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### 10.4 Verifying Real-Time WebSocket Feeds
Ensure that the following tables are added to Supabase Realtime publication:
```sql
ALTER PUBLICATION supabase_realtime ADD TABLE public.inventory_internal_transfer;
ALTER PUBLICATION supabase_realtime ADD TABLE public.inventory_recycle;
```
