// src/redux/slice/inventorySlice.js
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import {
  fetchInventoryDataApi,
  saveMaterialApi,
  saveMaterialsBatchApi,
  deleteMaterialApi,
  postTransactionApi,
  updateTransactionApi,
  deleteTransactionApi,
  bulkDeleteTransactionsApi,
  updateJobCardBatchApi,
  createIndentsApi,
  updateIndentStatusApi,
  saveSettingsApi,
  saveListApi,
  saveUsersApi,
  logAuditApi,
  resetToDummyDataApi,
  submitPhysicalStockCountApi,
  reviewPhysicalStockApi,
  bulkReviewPhysicalStockApi
} from '../api/inventoryApi';

export const fetchInventoryData = createAsyncThunk(
  'inventory/fetchData',
  async (_, thunkAPI) => {
    const response = await fetchInventoryDataApi();
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const submitPhysicalStockCount = createAsyncThunk(
  'inventory/submitPhysicalStockCount',
  async ({ physicalData, currentUser, deletedIds = [] }, thunkAPI) => {
    const response = await submitPhysicalStockCountApi(physicalData, currentUser, deletedIds);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const reviewPhysicalStock = createAsyncThunk(
  'inventory/reviewPhysicalStock',
  async ({ id, status, reviewRemarks, shouldAdjustStock, currentUser }, thunkAPI) => {
    const response = await reviewPhysicalStockApi({ id, status, reviewRemarks, shouldAdjustStock, currentUser });
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const bulkReviewPhysicalStock = createAsyncThunk(
  'inventory/bulkReviewPhysicalStock',
  async ({ items, currentUser }, thunkAPI) => {
    const response = await bulkReviewPhysicalStockApi({ items, currentUser });
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const saveMaterial = createAsyncThunk(
  'inventory/saveMaterial',
  async ({ material, currentUser }, thunkAPI) => {
    const response = await saveMaterialApi(material, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const saveMaterialsBatch = createAsyncThunk(
  'inventory/saveMaterialsBatch',
  async ({ materials, currentUser }, thunkAPI) => {
    const response = await saveMaterialsBatchApi(materials, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const deleteMaterial = createAsyncThunk(
  'inventory/deleteMaterial',
  async (payload, thunkAPI) => {
    const param = (payload && typeof payload === 'object' && ('id' in payload || 'sku' in payload))
      ? { id: payload.id, sku: payload.sku }
      : payload;
    const currentUser = payload?.currentUser || 'Admin';
    const response = await deleteMaterialApi(param, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const postTransaction = createAsyncThunk(
  'inventory/postTransaction',
  async ({ transaction, currentUser }, thunkAPI) => {
    const response = await postTransactionApi(transaction, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const updateTransaction = createAsyncThunk(
  'inventory/updateTransaction',
  async ({ transaction, currentUser }, thunkAPI) => {
    const response = await updateTransactionApi(transaction, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const deleteTransaction = createAsyncThunk(
  'inventory/deleteTransaction',
  async ({ id, currentUser }, thunkAPI) => {
    const response = await deleteTransactionApi(id, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const updateJobCardBatch = createAsyncThunk(
  'inventory/updateJobCardBatch',
  async ({ batchId, fields, currentUser }, thunkAPI) => {
    const response = await updateJobCardBatchApi(batchId, fields, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const bulkDeleteTransactions = createAsyncThunk(
  'inventory/bulkDeleteTransactions',
  async ({ ids, currentUser }, thunkAPI) => {
    const response = await bulkDeleteTransactionsApi(ids, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const createIndents = createAsyncThunk(
  'inventory/createIndents',
  async ({ items, requestedBy, department, currentUser }, thunkAPI) => {
    const response = await createIndentsApi(items, requestedBy, department, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const updateIndentStatus = createAsyncThunk(
  'inventory/updateIndentStatus',
  async ({ indentNo, status, currentUser }, thunkAPI) => {
    const response = await updateIndentStatusApi(indentNo, status, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const saveSettings = createAsyncThunk(
  'inventory/saveSettings',
  async ({ settings, currentUser }, thunkAPI) => {
    const response = await saveSettingsApi(settings, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const saveList = createAsyncThunk(
  'inventory/saveList',
  async ({ type, list, newList, currentUser }, thunkAPI) => {
    const targetList = list !== undefined ? list : newList;
    const response = await saveListApi(type, targetList, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const saveUsers = createAsyncThunk(
  'inventory/saveUsers',
  async ({ users, currentUser }, thunkAPI) => {
    const response = await saveUsersApi(users, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const logAudit = createAsyncThunk(
  'inventory/logAudit',
  async ({ action, detail, currentUser }, thunkAPI) => {
    const response = await logAuditApi(action, detail, currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

export const resetToDummyData = createAsyncThunk(
  'inventory/resetToDummyData',
  async ({ currentUser }, thunkAPI) => {
    const response = await resetToDummyDataApi(currentUser);
    if (response.error) return thunkAPI.rejectWithValue(response.error);
    return response.data;
  }
);

const initialState = {
  materials: [],
  transactions: [],
  indents: [],
  units: [],
  locations: [],
  divisions: [],
  materialNames: [],
  finishedGoodsNames: [],
  masterMaterials: [],
  categories: [],
  materialTypes: [],
  physicalStocks: [],
  settings: {
    pageSize: { master: 6, txn: 6, stock: 6 }
  },
  users: [],
  audit: [],
  jobCardBatches: [],
  recycles: [],
  loading: false,
  error: null
};

const handleFulfilled = (state, action) => {
  state.loading = false;
  state.error = null;
  if (action.payload) {
    state.materials = action.payload.materials || [];
    state.transactions = action.payload.transactions || [];
    state.indents = action.payload.indents || [];
    state.units = action.payload.units || [];
    state.locations = action.payload.locations || [];
    state.divisions = action.payload.divisions || [];
    state.materialNames = action.payload.materialNames || [];
    state.finishedGoodsNames = action.payload.finishedGoodsNames || [];
    state.masterMaterials = action.payload.masterMaterials || [];
    state.categories = action.payload.categories || [];
    state.materialTypes = action.payload.materialTypes || [];
    state.physicalStocks = action.payload.physicalStocks || [];
    state.settings = action.payload.settings || { pageSize: { master: 6, txn: 6, stock: 6 } };
    state.users = action.payload.users || [];
    state.audit = action.payload.audit || [];
    state.jobCardBatches = action.payload.jobCardBatches || [];
    state.recycles = action.payload.recycles || [];
  }
};

const handlePending = (state) => {
  state.loading = true;
  state.error = null;
};

const handleRejected = (state, action) => {
  state.loading = false;
  state.error = action.payload || 'An error occurred';
};

const inventorySlice = createSlice({
  name: 'inventory',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch data
      .addCase(fetchInventoryData.pending, handlePending)
      .addCase(fetchInventoryData.fulfilled, handleFulfilled)
      .addCase(fetchInventoryData.rejected, handleRejected)
      // Submit Physical Stock Count
      .addCase(submitPhysicalStockCount.pending, handlePending)
      .addCase(submitPhysicalStockCount.fulfilled, handleFulfilled)
      .addCase(submitPhysicalStockCount.rejected, handleRejected)
      // Review Physical Stock
      .addCase(reviewPhysicalStock.pending, handlePending)
      .addCase(reviewPhysicalStock.fulfilled, handleFulfilled)
      .addCase(reviewPhysicalStock.rejected, handleRejected)
      // Bulk Review Physical Stock
      .addCase(bulkReviewPhysicalStock.pending, handlePending)
      .addCase(bulkReviewPhysicalStock.fulfilled, handleFulfilled)
      .addCase(bulkReviewPhysicalStock.rejected, handleRejected)
      // Save material
      .addCase(saveMaterial.pending, handlePending)
      .addCase(saveMaterial.fulfilled, handleFulfilled)
      .addCase(saveMaterial.rejected, handleRejected)
      // Save materials batch
      .addCase(saveMaterialsBatch.pending, handlePending)
      .addCase(saveMaterialsBatch.fulfilled, handleFulfilled)
      .addCase(saveMaterialsBatch.rejected, handleRejected)
      // Delete material
      .addCase(deleteMaterial.pending, handlePending)
      .addCase(deleteMaterial.fulfilled, handleFulfilled)
      .addCase(deleteMaterial.rejected, handleRejected)
      // Post transaction
      .addCase(postTransaction.pending, handlePending)
      .addCase(postTransaction.fulfilled, handleFulfilled)
      .addCase(postTransaction.rejected, handleRejected)
      // Update transaction
      .addCase(updateTransaction.pending, handlePending)
      .addCase(updateTransaction.fulfilled, handleFulfilled)
      .addCase(updateTransaction.rejected, handleRejected)
      // Delete transaction
      .addCase(deleteTransaction.pending, handlePending)
      .addCase(deleteTransaction.fulfilled, handleFulfilled)
      .addCase(deleteTransaction.rejected, handleRejected)
      // Bulk delete transactions
      .addCase(bulkDeleteTransactions.pending, handlePending)
      .addCase(bulkDeleteTransactions.fulfilled, handleFulfilled)
      .addCase(updateJobCardBatch.fulfilled, handleFulfilled)
      .addCase(bulkDeleteTransactions.rejected, handleRejected)
      // Create indents
      .addCase(createIndents.pending, handlePending)
      .addCase(createIndents.fulfilled, handleFulfilled)
      .addCase(createIndents.rejected, handleRejected)
      // Update indent status
      .addCase(updateIndentStatus.pending, handlePending)
      .addCase(updateIndentStatus.fulfilled, handleFulfilled)
      .addCase(updateIndentStatus.rejected, handleRejected)
      // Save settings
      .addCase(saveSettings.pending, handlePending)
      .addCase(saveSettings.fulfilled, handleFulfilled)
      .addCase(saveSettings.rejected, handleRejected)
      // Save custom lists
      .addCase(saveList.pending, handlePending)
      .addCase(saveList.fulfilled, handleFulfilled)
      .addCase(saveList.rejected, handleRejected)
      // Save users
      .addCase(saveUsers.pending, handlePending)
      .addCase(saveUsers.fulfilled, handleFulfilled)
      .addCase(saveUsers.rejected, handleRejected)
      // Log audit
      .addCase(logAudit.pending, handlePending)
      .addCase(logAudit.fulfilled, handleFulfilled)
      .addCase(logAudit.rejected, handleRejected)
      // Reset to dummy data
      .addCase(resetToDummyData.pending, handlePending)
      .addCase(resetToDummyData.fulfilled, handleFulfilled)
      .addCase(resetToDummyData.rejected, handleRejected);
  }
});

export const { clearError } = inventorySlice.actions;
export default inventorySlice.reducer;
