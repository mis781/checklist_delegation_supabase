import { useState, useEffect, useRef, useMemo } from "react";
import { X, CheckCircle2, Loader2, Paperclip, ExternalLink, Plus, Trash2 } from "lucide-react";
import { fetchRecycleApi, saveRecycleApi, updateRecycleStatusApi } from "../../../redux/api/inventoryApi";
import {
  isScrapItem,
  getMaterialCategory,
  matchScrapMaterialForFg,
} from "../utils/scrapUtils";
import { getUserAllowedDivisions, isDivisionAllowed } from "../../../utils/roleUtils";

// Internal CustomSelect component to ensure consistent dark/light styling and overflow behavior
function CustomSelect({
  value,
  onChange,
  options = [],
  placeholder = "Select...",
  required = false,
  className = "",
  disabled = false,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const containerRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const normalizedOptions = (options || [])
    .filter(Boolean)
    .map((opt) => {
      if (typeof opt === "string" || typeof opt === "number") {
        return { label: String(opt), value: String(opt) };
      }
      if (opt && typeof opt === "object") {
        const label = String(opt.label ?? opt.value ?? "");
        const value = String(opt.value ?? opt.label ?? "");
        return { label, value };
      }
      return null;
    })
    .filter((opt) => opt && opt.label);

  const filteredOptions = normalizedOptions.filter((opt) =>
    (opt.label || "").toLowerCase().includes((searchQuery || "").toLowerCase()),
  );

  const selectedOption = normalizedOptions.find((opt) => opt.value === value);

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      {required && (
        <input
          tabIndex={-1}
          value={value || ""}
          onChange={() => {}}
          required
          className="opacity-0 absolute inset-0 w-full h-full pointer-events-none -z-10"
        />
      )}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-gray-900 dark:text-white text-sm text-left focus:ring-2 focus:ring-indigo-500 transition-all ${
          disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-900"
        }`}
      >
        <span className={selectedOption ? "font-medium" : "text-gray-400 dark:text-slate-500"}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <svg
          className={`w-4 h-4 text-gray-400 dark:text-slate-500 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute z-50 mt-1 w-full bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-scale-up">
          {normalizedOptions.length > 5 && (
            <div className="p-2 border-b border-gray-150 dark:border-slate-800">
              <input
                type="text"
                autoFocus
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-200 dark:border-slate-800 rounded-lg bg-gray-50 dark:bg-slate-950 text-xs text-gray-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}
          <div className="max-h-48 overflow-y-auto p-1">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((opt) => (
                <div
                  key={opt.value}
                  onClick={() => {
                    onChange(opt.value);
                    setIsOpen(false);
                    setSearchQuery("");
                  }}
                  className={`px-3.5 py-2 rounded-lg text-sm cursor-pointer transition-colors ${
                    opt.value === value
                      ? "bg-indigo-600 text-white font-medium"
                      : "text-gray-700 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 dark:hover:text-indigo-300"
                  }`}
                >
                  {opt.label}
                </div>
              ))
            ) : (
              <div className="px-3.5 py-2 text-xs text-gray-400 dark:text-slate-500 text-center">
                No matching options
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function RecycleModal({
  isOpen,
  onClose,
  activeUser,
  materials = [],
  finishedGoodsNames = [],
  divisions = [],
  onRecycleUpdated,
}) {
  const [activeTab, setActiveTab] = useState("form"); // 'form' | 'list'
  const [listSubTab, setListSubTab] = useState("pending"); // 'pending' | 'history'

  // Form state
  const [recycleType, setRecycleType] = useState("Raw Material");
  const [firm, setFirm] = useState("");
  const [items, setItems] = useState([{ id: 1, sku: "", qty: "", weight: "" }]);
  const [damageType, setDamageType] = useState("Expiry");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [reason, setReason] = useState("");
  const [approvedBy, setApprovedBy] = useState(activeUser?.name || "");
  const [attachmentFile, setAttachmentFile] = useState(null);

  // Finished Goods lookup map for category resolution
  const fgLookupMap = useMemo(() => {
    const map = {};
    (materials || []).forEach((m) => {
      if (m.sku) map[m.sku] = m;
      if (m.name) map[m.name] = m;
    });
    (finishedGoodsNames || []).forEach((fg) => {
      if (typeof fg === "object") {
        if (fg.sku) map[fg.sku] = fg;
        if (fg.name) map[fg.name] = fg;
      }
    });
    return map;
  }, [materials, finishedGoodsNames]);

  // List state
  const [recycleList, setRecycleList] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [isLoadingList, setIsLoadingList] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  // Allowed divisions
  const allowedDivisions = useMemo(() => getUserAllowedDivisions(activeUser), [activeUser]);

  // Derived filtered lists for the 2 sub tabs
  const pendingRecords = (recycleList || []).filter(
    (r) => (r.status || "pending").toLowerCase() === "pending" && isDivisionAllowed(r.firm || r.division, allowedDivisions)
  );
  const historyRecords = (recycleList || []).filter(
    (r) => (r.status || "").toLowerCase() === "completed" && isDivisionAllowed(r.firm || r.division, allowedDivisions)
  );

  // Items manipulation helpers
  const handleAddItem = () => {
    setItems((prev) => [...prev, { id: Date.now() + Math.random(), sku: "", qty: "", weight: "" }]);
  };

  const handleRemoveItem = (index) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleItemChange = (index, field, value) => {
    setItems((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  // Reset form when modal opens or activeUser changes
  useEffect(() => {
    if (isOpen) {
      setApprovedBy(activeUser?.name || "");
      if (!firm || !isDivisionAllowed(firm, allowedDivisions)) {
        if (allowedDivisions && allowedDivisions.length > 0) {
          setFirm(allowedDivisions[0]);
        } else if (activeUser?.division) {
          setFirm(activeUser.division);
        }
      }
      if (activeTab === "list") {
        loadRecycleList();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- activeTab intentionally excluded: tab switches are handled by the effect below, adding it here would duplicate loadRecycleList calls
  }, [isOpen, activeUser, allowedDivisions]);

  // Load list when switching to list tab
  useEffect(() => {
    if (isOpen && activeTab === "list") {
      loadRecycleList();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- isOpen intentionally excluded: modal-open is handled by the effect above, adding it here would duplicate loadRecycleList calls
  }, [activeTab]);

  const loadRecycleList = async () => {
    setIsLoadingList(true);
    setSelectedIds([]);
    const res = await fetchRecycleApi();
    if (res.data) {
      setRecycleList(res.data);
    }
    setIsLoadingList(false);
  };

  const handleToggleSelectAll = () => {
    if (selectedIds.length === pendingRecords.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(pendingRecords.map((r) => r.id));
    }
  };

  const handleToggleSelectRow = (id) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleMarkComplete = async (idsToComplete) => {
    if (!idsToComplete || idsToComplete.length === 0) return;
    setIsUpdatingStatus(true);
    const res = await updateRecycleStatusApi(idsToComplete, "completed", activeUser?.name);
    setIsUpdatingStatus(false);
    if (res.error) {
      alert(`Failed to mark completed: ${res.error}`);
    } else {
      setSelectedIds((prev) => prev.filter((id) => !idsToComplete.includes(id)));
      await loadRecycleList();
      if (onRecycleUpdated) {
        onRecycleUpdated();
      }
    }
  };

  const handleRecycleTypeChange = (val) => {
    setRecycleType(val);
    setItems([{ id: Date.now(), sku: "", qty: "", weight: "" }]);
  };

  const resetForm = () => {
    setRecycleType("Raw Material");
    setFirm("");
    setItems([{ id: Date.now(), sku: "", qty: "", weight: "" }]);
    setDamageType("Expiry");
    setDate(new Date().toISOString().slice(0, 10));
    setReason("");
    setApprovedBy(activeUser?.name || "");
    setAttachmentFile(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!recycleType) {
      alert("Please select a Recycle Type.");
      return;
    }
    if (!firm) {
      alert("Please select a Firm.");
      return;
    }
    if (!damageType) {
      alert("Please select a Damage Type.");
      return;
    }
    if (!date) {
      alert("Please select a Date.");
      return;
    }

    // Validate each item row
    const validatedItems = [];
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const skuVal = (it.sku || "").trim();
      if (!skuVal) {
        alert(`Please select a Material in row #${i + 1}.`);
        return;
      }
      const qtyNum = Number(it.qty);
      if (!qtyNum || qtyNum <= 0) {
        alert(`Please enter a valid quantity greater than zero in row #${i + 1}.`);
        return;
      }
      const weightVal = it.weight !== undefined && it.weight !== null && it.weight !== "" ? Number(it.weight) : null;
      if (weightVal !== null && (isNaN(weightVal) || weightVal < 0)) {
        alert(`Please enter a valid non-negative weight in row #${i + 1}.`);
        return;
      }
      if (recycleType === "Finished Good" && (weightVal === null || weightVal <= 0)) {
        alert(
          `Please enter the weight (kg) for Finished Good in row #${i + 1}. This weight is required to calculate Scrap Raw Material addition.`
        );
        return;
      }

      let materialName = "";
      let materialSku = skuVal;

      if (recycleType === "Raw Material") {
        const mat = materials.find((m) => m.sku === skuVal || m.name === skuVal);
        if (mat) {
          materialName = mat.name || mat.sku;
          materialSku = mat.sku || skuVal;
        } else {
          materialName = skuVal;
          materialSku = skuVal;
        }
      } else {
        const mat = materials.find((m) => m.sku === skuVal || m.name === skuVal);
        if (mat) {
          materialName = mat.name || mat.sku;
          materialSku = mat.sku || skuVal;
        } else {
          const fg = (finishedGoodsNames || []).find((f) =>
            typeof f === "object"
              ? f.sku === skuVal || f.name === skuVal
              : f === skuVal
          );
          if (fg) {
            materialName = typeof fg === "object" ? fg.name : fg;
            materialSku = typeof fg === "object" && fg.sku ? fg.sku : skuVal;
          } else {
            materialName = skuVal;
            materialSku = skuVal;
          }
        }
      }

      validatedItems.push({
        materialName,
        materialSku,
        quantity: qtyNum,
        weight: weightVal,
      });
    }

    if (validatedItems.length === 0) {
      alert("Please add at least one material row.");
      return;
    }

    setIsSubmitting(true);

    const payload = {
      recycleType,
      firm: firm || activeUser?.division || null,
      damageType,
      date,
      reason: reason.trim(),
      approvedBy: approvedBy.trim() || activeUser?.name || "Admin",
      items: validatedItems,
    };

    const res = await saveRecycleApi(payload, attachmentFile, activeUser?.name);
    setIsSubmitting(false);

    if (res.error) {
      alert(`Failed to save Rejected record: ${res.error}`);
    } else {
      alert(`${validatedItems.length} rejected item(s) recorded successfully!`);
      resetForm();
      setActiveTab("list");
      setListSubTab("pending");
      await loadRecycleList();
      if (onRecycleUpdated) {
        onRecycleUpdated();
      }
    }
  };

  if (!isOpen) return null;

  // Derive firm options
  const firmOptions = [
    ...new Set([
      ...divisions,
      ...(activeUser?.division ? [activeUser.division] : []),
      ...materials.map((m) => m.division).filter(Boolean),
    ]),
  ].filter((f) => isDivisionAllowed(f, allowedDivisions));

  // Derive material SKU options based on Recycle Type
  let materialOptions = [];
  if (recycleType === "Raw Material") {
    materialOptions = (materials || [])
      .filter((m) => m && (m.sku || m.name))
      .filter((m) => m.materialType === "RM" || m.material_type === "RM" || m.category === "Raw Material" || (!m.material_type && !m.materialType))
      .map((m) => {
        const skuStr = m.sku || m.name || "";
        const labelStr = m.sku ? (m.name && m.name !== m.sku ? `${m.sku} — ${m.name}` : m.sku) : m.name;
        return {
          label: labelStr,
          value: skuStr,
        };
      });
  } else {
    // Finished Goods SKUs from materials list and finishedGoodsNames
    const seen = new Set();
    const fgOptionsList = [];

    // 1. From materials array (FG materials)
    (materials || [])
      .filter((m) => m && (m.materialType === "FG" || m.material_type === "FG" || (m.category && m.category.toLowerCase() !== "raw material")))
      .forEach((m) => {
        const skuStr = m.sku || m.name || "";
        if (skuStr && !seen.has(skuStr)) {
          seen.add(skuStr);
          const labelStr = m.sku ? (m.name && m.name !== m.sku ? `${m.sku} — ${m.name}` : m.sku) : m.name;
          fgOptionsList.push({ label: labelStr, value: skuStr });
        }
      });

    // 2. From finishedGoodsNames list
    (finishedGoodsNames || [])
      .filter(Boolean)
      .forEach((fg) => {
        const skuStr = typeof fg === "object" ? (fg.sku || fg.name) : fg;
        const nameStr = typeof fg === "object" ? fg.name : fg;
        if (skuStr && !seen.has(skuStr)) {
          seen.add(skuStr);
          const labelStr = (typeof fg === "object" && fg.sku) ? (fg.name && fg.name !== fg.sku ? `${fg.sku} — ${fg.name}` : fg.sku) : nameStr;
          fgOptionsList.push({ label: labelStr, value: skuStr });
        }
      });

    materialOptions = fgOptionsList;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-5xl shadow-2xl animate-scale-up flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Modal Header with Switcher Tabs */}
        <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4 bg-gray-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-black text-gray-900 dark:text-white">
              Rejected
            </h3>

            {/* Switcher Header Tabs */}
            <div className="flex items-center p-1 bg-gray-200 dark:bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveTab("form")}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === "form"
                    ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm"
                    : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                }`}
              >
                Rejected Form
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("list")}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === "list"
                    ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm"
                    : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                }`}
              >
                Rejected List
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === "form" ? (
            <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* 1. Recycle Type (Full width - 2 cols) */}
              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Rejected Type *
                </label>
                <CustomSelect
                  required
                  value={recycleType}
                  onChange={handleRecycleTypeChange}
                  options={[
                    { label: "Raw Material", value: "Raw Material" },
                    { label: "Finished Good", value: "Finished Good" },
                  ]}
                  placeholder="Select Rejected Type..."
                />
              </div>

              {/* 2. Firm (Full width - 2 cols) */}
              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Firm *
                </label>
                <CustomSelect
                  required
                  value={firm}
                  onChange={(val) => setFirm(val)}
                  options={firmOptions}
                  placeholder="Select firm..."
                />
              </div>

              {/* 3. Multiple Material Items (Full width - 2 cols) */}
              <div className="flex flex-col gap-2.5 col-span-2 text-left">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    {recycleType === "Raw Material" ? "Raw Material Items *" : "Finished Goods Items *"} ({items.length})
                  </label>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/80 cursor-pointer transition-all active:scale-95 shadow-xs"
                  >
                    <Plus size={14} />
                    <span>Add Material</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {items.map((item, index) => {
                    const selectedMat = materials.find(
                      (m) => m.sku === item.sku || m.name === item.sku
                    );
                    const isThisScrap = item.sku
                      ? isScrapItem(item.sku) || isScrapItem(selectedMat)
                      : false;

                    const isFg =
                      recycleType === "Finished Good" ||
                      (selectedMat &&
                        (selectedMat.materialType === "FG" ||
                          selectedMat.material_type === "FG"));

                    let matchedScrapMaterial = null;
                    if (isFg && item.sku) {
                      const fgCat = getMaterialCategory(
                        selectedMat || { sku: item.sku, name: item.sku },
                        fgLookupMap
                      );
                      matchedScrapMaterial = (materials || []).find(
                        (m) =>
                          isScrapItem(m) &&
                          matchScrapMaterialForFg(
                            m,
                            { firm: firm || activeUser?.division },
                            fgCat
                          )
                      );
                    }

                    return (
                      <div
                        key={item.id || index}
                        className="flex flex-col gap-1.5 p-3 rounded-2xl border border-gray-200/80 dark:border-slate-800 bg-gray-50/60 dark:bg-slate-950/50"
                      >
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                          <span className="text-xs font-bold text-gray-400 dark:text-slate-500 w-6 text-center shrink-0">
                            #{index + 1}
                          </span>

                          <div className="flex-1 min-w-[200px]">
                            <CustomSelect
                              required
                              value={item.sku}
                              onChange={(val) => handleItemChange(index, "sku", val)}
                              options={materialOptions}
                              placeholder={`Select ${recycleType === "Raw Material" ? "Raw Material" : "Finished Good"} SKU...`}
                            />
                          </div>

                          <div className="w-full sm:w-32 shrink-0">
                            <input
                              type="number"
                              required
                              min="0.0001"
                              step="any"
                              value={item.qty}
                              onChange={(e) => handleItemChange(index, "qty", e.target.value)}
                              placeholder="Quantity..."
                              className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                            />
                          </div>

                          <div className="w-full sm:w-32 shrink-0">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              required={recycleType === "Finished Good"}
                              value={item.weight}
                              onChange={(e) => handleItemChange(index, "weight", e.target.value)}
                              placeholder={recycleType === "Finished Good" ? "Weight (kg) *" : "Weight (kg)..."}
                              className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-hidden"
                            />
                          </div>

                          {items.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(index)}
                              title="Remove item"
                              className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-all cursor-pointer shrink-0 self-center"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>

                        {/* Status / Scrap Conversion Badges */}
                        {isThisScrap && (
                          <div className="sm:ml-8.5 flex items-center gap-1.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800/40 w-fit">
                            <span>🟢 Scrap Material:</span>
                            <span className="font-normal text-gray-600 dark:text-slate-300">
                              Quantity will be added to scrap closing stock.
                            </span>
                          </div>
                        )}

                        {matchedScrapMaterial && (
                          <div className="sm:ml-8.5 flex items-center gap-1.5 text-[11px] font-semibold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-200 dark:border-amber-800/40 w-fit">
                            <span>♻️ Scrap Conversion:</span>
                            <span className="font-normal text-gray-600 dark:text-slate-300">
                              Weight ({item.weight ? `${Number(item.weight).toLocaleString()} kg` : "entered above"}) will be added to{" "}
                              <span className="font-semibold text-amber-700 dark:text-amber-300">
                                {matchedScrapMaterial.name || matchedScrapMaterial.sku}
                              </span>{" "}
                              Raw Material closing stock upon completion.
                            </span>
                          </div>
                        )}

                        {isFg && !matchedScrapMaterial && item.sku && (
                          <div className="sm:ml-8.5 flex items-center gap-1.5 text-[11px] font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800/40 w-fit">
                            <span>ℹ️ Finished Good:</span>
                            <span className="font-normal text-gray-600 dark:text-slate-300">
                              Closing stock will be reduced by {item.qty ? Number(item.qty).toLocaleString() : "quantity"}.
                            </span>
                          </div>
                        )}

                        {!isFg && !isThisScrap && item.sku && (
                          <div className="sm:ml-8.5 flex items-center gap-1.5 text-[11px] font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1 rounded-lg border border-rose-200 dark:border-rose-800/40 w-fit">
                            <span>🔻 Raw Material:</span>
                            <span className="font-normal text-gray-600 dark:text-slate-300">
                              Closing stock will be reduced by {item.qty ? Number(item.qty).toLocaleString() : "quantity"}.
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 4. Date (1 col) */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Date *
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* 5. Damage Type (1 col) */}
              <div className="flex flex-col gap-1.5 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Damage Type *
                </label>
                <CustomSelect
                  required
                  value={damageType}
                  onChange={(val) => setDamageType(val)}
                  options={[
                    { label: "Expiry", value: "Expiry" },
                    { label: "Damage", value: "Damage" },
                    { label: "Theft", value: "Theft" },
                  ]}
                  placeholder="Select Damage Type..."
                />
              </div>

              {/* 7. Approved By (Full width - 2 cols) */}
              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Approved By *
                </label>
                <input
                  type="text"
                  required
                  value={approvedBy}
                  onChange={(e) => setApprovedBy(e.target.value)}
                  placeholder="Enter approver name..."
                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* 8. Reason (Full width - 2 cols) */}
              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Reason
                </label>
                <textarea
                  rows={2}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Reason for rejection..."
                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* 9. Attachments (Full width - 2 cols) */}
              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                  Attachments
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-xs font-bold text-gray-700 dark:text-slate-300 hover:border-indigo-500 cursor-pointer">
                    <Paperclip size={14} />
                    <span>Choose File</span>
                    <input
                      type="file"
                      onChange={(e) => setAttachmentFile(e.target.files[0] || null)}
                      className="hidden"
                    />
                  </label>
                  {attachmentFile ? (
                    <span className="text-xs text-indigo-600 dark:text-indigo-400 font-medium truncate max-w-xs">
                      {attachmentFile.name}
                    </span>
                  ) : (
                    <span className="text-xs text-gray-400 dark:text-slate-500">
                      No file chosen
                    </span>
                  )}
                </div>
              </div>

              {/* Buttons */}
              <div className="col-span-2 flex items-center justify-end gap-3 pt-4 border-t border-gray-150 dark:border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-slate-800 text-sm font-bold text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-sm font-bold shadow-md cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="animate-spin" size={16} />
                      Saving...
                    </>
                  ) : (
                    "Submit Rejected Record"
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* TAB 2: Rejected List with Pending and History sub-tabs */
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                {/* Sub-tabs: Pending & History */}
                <div className="flex items-center p-1 bg-gray-100 dark:bg-slate-800 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setListSubTab("pending");
                      setSelectedIds([]);
                    }}
                    className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      listSubTab === "pending"
                        ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm"
                        : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                    }`}
                  >
                    <span>Pending</span>
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        listSubTab === "pending"
                          ? "bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300"
                          : "bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-300"
                      }`}
                    >
                      {pendingRecords.length}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setListSubTab("history");
                      setSelectedIds([]);
                    }}
                    className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      listSubTab === "history"
                        ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm"
                        : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                    }`}
                  >
                    <span>History</span>
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        listSubTab === "history"
                          ? "bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300"
                          : "bg-gray-200 dark:bg-slate-700 text-gray-600 dark:text-slate-300"
                      }`}
                    >
                      {historyRecords.length}
                    </span>
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  {listSubTab === "pending" && selectedIds.length > 0 && (
                    <button
                      type="button"
                      disabled={isUpdatingStatus}
                      onClick={() => handleMarkComplete(selectedIds)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer disabled:opacity-50 transition-all"
                    >
                      <CheckCircle2 size={14} />
                      <span>Mark Completed ({selectedIds.length})</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={loadRecycleList}
                    className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                  >
                    Refresh List
                  </button>
                </div>
              </div>

              {isLoadingList ? (
                <div className="flex items-center justify-center py-12 text-gray-400">
                  <Loader2 className="animate-spin mr-2" size={20} />
                  Loading records...
                </div>
              ) : listSubTab === "pending" ? (
                /* PENDING TABLE */
                <div className="overflow-x-auto border border-gray-200 dark:border-slate-800 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-slate-400 font-bold uppercase">
                        <th className="w-10 px-3 py-3 text-center">
                          <input
                            type="checkbox"
                            checked={pendingRecords.length > 0 && selectedIds.length === pendingRecords.length}
                            onChange={handleToggleSelectAll}
                            className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                          />
                        </th>
                        <th className="px-4 py-3">Rejected Type</th>
                        <th className="px-4 py-3">Firm</th>
                        <th className="px-4 py-3">Material SKU</th>
                        <th className="px-4 py-3">Quantity</th>
                        <th className="px-4 py-3">Weight</th>
                        <th className="px-4 py-3">Damage Type</th>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Reason</th>
                        <th className="px-4 py-3">Approved By</th>
                        <th className="px-4 py-3">Attachment</th>
                        <th className="px-4 py-3 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-slate-800">
                      {pendingRecords.length === 0 ? (
                        <tr>
                          <td colSpan={12} className="text-center py-10 text-sm text-gray-400 dark:text-slate-500">
                            No pending rejected records found. Create one using the Rejected Form.
                          </td>
                        </tr>
                      ) : (
                        pendingRecords.map((row) => {
                          const isChecked = selectedIds.includes(row.id);
                          return (
                            <tr
                              key={row.id}
                              className={`transition-colors ${
                                isChecked
                                  ? "bg-emerald-50/50 dark:bg-emerald-950/20"
                                  : "hover:bg-gray-50 dark:hover:bg-slate-955/50"
                              }`}
                            >
                              <td className="px-3 py-3 text-center">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => handleToggleSelectRow(row.id)}
                                  className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                                />
                              </td>
                              <td className="px-4 py-3 font-semibold text-gray-900 dark:text-white">
                                {row.recycle_type}
                              </td>
                              <td className="px-4 py-3 text-gray-600 dark:text-slate-400">
                                {row.firm || "—"}
                              </td>
                              <td className="px-4 py-3 text-gray-900 dark:text-white font-medium">
                                <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                                  {row.material_sku || row.material_name}
                                </span>
                                {row.material_name && row.material_name !== row.material_sku && (
                                  <span className="text-gray-500 dark:text-slate-400 text-xs ml-1.5 font-normal">
                                    ({row.material_name})
                                  </span>
                                )}
                              </td>
                              <td className="px-4 py-3 font-bold">
                                {(() => {
                                  const isRowScrap = isScrapItem(row);
                                  return (
                                    <div className="flex items-center gap-1.5">
                                      <span
                                        className={
                                          isRowScrap
                                            ? "text-emerald-600 dark:text-emerald-400"
                                            : "text-rose-600 dark:text-rose-400"
                                        }
                                      >
                                        {isRowScrap ? "+" : ""}
                                        {Number(row.quantity).toLocaleString()}
                                      </span>
                                      {isRowScrap && (
                                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300">
                                          Scrap (+)
                                        </span>
                                      )}
                                    </div>
                                  );
                                })()}
                              </td>
                              <td className="px-4 py-3 font-semibold text-gray-700 dark:text-slate-300">
                                {row.weight !== null && row.weight !== undefined && row.weight !== "" ? (
                                  <div className="flex flex-col">
                                    <span>{Number(row.weight).toLocaleString()} kg</span>
                                    {String(row.recycle_type || "").toLowerCase().includes("finish") && (
                                      <span className="text-[10px] text-amber-600 dark:text-amber-400 font-normal">
                                        Adds to Scrap RM
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  "—"
                                )}
                              </td>
                              <td className="px-4 py-3">
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300">
                                  {row.damage_type}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-gray-600 dark:text-slate-400 whitespace-nowrap">
                                {row.date}
                              </td>
                              <td className="px-4 py-3 text-gray-600 dark:text-slate-400 max-w-[160px] truncate">
                                {row.reason || "—"}
                              </td>
                              <td className="px-4 py-3 text-gray-900 dark:text-white">
                                {row.approved_by || "—"}
                              </td>
                              <td className="px-4 py-3">
                                {row.attachment_url ? (
                                  <a
                                    href={row.attachment_url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                                  >
                                    <ExternalLink size={12} />
                                    View
                                  </a>
                                ) : (
                                  <span className="text-gray-400">—</span>
                                )}
                              </td>
                              <td className="px-4 py-3 text-center">
                                <button
                                  type="button"
                                  title="Mark as Completed"
                                  disabled={isUpdatingStatus}
                                  onClick={() => handleMarkComplete([row.id])}
                                  className="p-1.5 text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-950/60 rounded-lg cursor-pointer transition-colors"
                                >
                                  <CheckCircle2 size={18} />
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              ) : (
                /* HISTORY TABLE */
                <div className="overflow-x-auto border border-gray-200 dark:border-slate-800 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-slate-400 font-bold uppercase">
                        <th className="px-4 py-3">Rejected Type</th>
                        <th className="px-4 py-3">Firm</th>
                        <th className="px-4 py-3">Material SKU</th>
                        <th className="px-4 py-3">Quantity</th>
                        <th className="px-4 py-3">Weight</th>
                        <th className="px-4 py-3">Damage Type</th>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Reason</th>
                        <th className="px-4 py-3">Approved By</th>
                        <th className="px-4 py-3">Attachment</th>
                        <th className="px-4 py-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-slate-800">
                      {historyRecords.length === 0 ? (
                        <tr>
                          <td colSpan={11} className="text-center py-10 text-sm text-gray-400 dark:text-slate-500">
                            No completed rejected records in history.
                          </td>
                        </tr>
                      ) : (
                        historyRecords.map((row) => (
                          <tr
                            key={row.id}
                            className="hover:bg-gray-50 dark:hover:bg-slate-955/50 transition-colors"
                          >
                            <td className="px-4 py-3 font-semibold text-gray-900 dark:text-white">
                              {row.recycle_type}
                            </td>
                            <td className="px-4 py-3 text-gray-600 dark:text-slate-400">
                              {row.firm || "—"}
                            </td>
                            <td className="px-4 py-3 text-gray-900 dark:text-white font-medium">
                              <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                                {row.material_sku || row.material_name}
                              </span>
                              {row.material_name && row.material_name !== row.material_sku && (
                                <span className="text-gray-500 dark:text-slate-400 text-xs ml-1.5 font-normal">
                                  ({row.material_name})
                                </span>
                              )}
                            </td>
                            <td className="px-4 py-3 font-bold">
                              {(() => {
                                const isRowScrap = isScrapItem(row);
                                return (
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className={
                                        isRowScrap
                                          ? "text-emerald-600 dark:text-emerald-400"
                                          : "text-rose-600 dark:text-rose-400"
                                      }
                                    >
                                      {isRowScrap ? "+" : ""}
                                      {Number(row.quantity).toLocaleString()}
                                    </span>
                                    {isRowScrap && (
                                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300">
                                        Scrap (+)
                                      </span>
                                    )}
                                  </div>
                                );
                              })()}
                            </td>
                            <td className="px-4 py-3 font-semibold text-gray-700 dark:text-slate-300">
                              {row.weight !== null && row.weight !== undefined && row.weight !== "" ? (
                                <div className="flex flex-col">
                                  <span>{Number(row.weight).toLocaleString()} kg</span>
                                  {String(row.recycle_type || "").toLowerCase().includes("finish") && (
                                    <span className="text-[10px] text-amber-600 dark:text-amber-400 font-normal">
                                      Adds to Scrap RM
                                    </span>
                                  )}
                                </div>
                              ) : (
                                "—"
                              )}
                            </td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300">
                                {row.damage_type}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-gray-600 dark:text-slate-400 whitespace-nowrap">
                              {row.date}
                            </td>
                            <td className="px-4 py-3 text-gray-600 dark:text-slate-400 max-w-[160px] truncate">
                              {row.reason || "—"}
                            </td>
                            <td className="px-4 py-3 text-gray-900 dark:text-white">
                              {row.approved_by || "—"}
                            </td>
                            <td className="px-4 py-3">
                              {row.attachment_url ? (
                                <a
                                  href={row.attachment_url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                                >
                                  <ExternalLink size={12} />
                                  View
                                </a>
                              ) : (
                                <span className="text-gray-400">—</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-center">
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                                <CheckCircle2 size={10} />
                                Completed
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
