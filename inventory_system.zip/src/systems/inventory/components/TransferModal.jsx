// src/systems/inventory/components/TransferModal.jsx
import { useState, useMemo, useRef, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  X,
  Send,
  CheckCircle,
  Search,
  Building2,
  Calendar,
  FileText,
  Boxes,
  ChevronDown,
  ArrowLeftRight,
  UserCheck,
  Package,
} from "lucide-react";
import { submitTransfer, fetchTransfers } from "../../../redux/slice/transferSlice";
import { fetchInventoryData } from "../../../redux/slice/inventorySlice";
import { useMagicToast } from "../../../context/MagicToastContext";
import { getUserAllowedDivisions, isDivisionAllowed } from "../../../utils/roleUtils";

// Robust string normalization for search & paste
const normalizeSearchText = (str) => {
  if (!str) return "";
  return String(str)
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\u00A0/g, " ")
    .replace(/[''""`]/g, '"')
    .replace(/[–—‑−]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
};

const stripSearchText = (str) => {
  if (!str) return "";
  return normalizeSearchText(str).replace(/[^a-z0-9]/g, "");
};

// Searchable Select Component for dropdowns inside modal
function SearchableSelect({
  value,
  onChange,
  options = [],
  placeholder = "Select...",
  error = false,
  className = "",
  disabled = false,
  allowCustomInput = false,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const containerRef = useRef(null);
  const listRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Scroll to top when search query changes
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = 0;
    }
  }, [searchQuery]);

  const selectedOption = useMemo(() => {
    return (
      options.find((o) => o.value === value) ||
      (value ? { label: value, value } : null)
    );
  }, [options, value]);

  const filteredOptions = useMemo(() => {
    const rawQuery = searchQuery || "";
    const qNorm = normalizeSearchText(rawQuery);
    const qStrip = stripSearchText(rawQuery);

    if (!qNorm) return options;

    const tokens = qNorm.split(" ").filter(Boolean);

    // Score each option to rank matches
    const scored = [];
    for (const opt of options) {
      const valNorm = normalizeSearchText(opt.value);
      const valStrip = stripSearchText(opt.value);
      const labelNorm = normalizeSearchText(opt.label);
      const labelStrip = stripSearchText(opt.label);
      const subLabelNorm = normalizeSearchText(opt.subLabel);

      let score = 0;

      // Exact match on SKU value or stripped SKU
      if (valNorm === qNorm || (qStrip.length >= 2 && valStrip === qStrip)) {
        score = 1000;
      } else if (labelNorm === qNorm || (qStrip.length >= 2 && labelStrip === qStrip)) {
        score = 900;
      } else if (valNorm.startsWith(qNorm) || (qStrip.length >= 2 && valStrip.startsWith(qStrip))) {
        score = 800;
      } else if (labelNorm.startsWith(qNorm) || (qStrip.length >= 2 && labelStrip.startsWith(qStrip))) {
        score = 700;
      } else if (valNorm.includes(qNorm) || (qStrip.length >= 2 && valStrip.includes(qStrip))) {
        score = 600;
      } else if (labelNorm.includes(qNorm) || (qStrip.length >= 2 && labelStrip.includes(qStrip))) {
        score = 500;
      } else if (subLabelNorm.includes(qNorm)) {
        score = 400;
      } else if (tokens.length > 1) {
        const full = `${valNorm} ${labelNorm} ${subLabelNorm}`;
        const allTokens = tokens.every((tok) => full.includes(tok));
        if (allTokens) {
          score = 300;
        }
      }

      if (score > 0) {
        scored.push({ opt, score });
      }
    }

    // Sort scored items highest score first
    scored.sort((a, b) => b.score - a.score);
    const matches = scored.map((s) => s.opt);

    const hasExact = matches.length > 0 && scored[0].score >= 900;
    if (!hasExact && allowCustomInput && qNorm) {
      return [
        {
          value: rawQuery.trim(),
          label: `+ Custom: "${rawQuery.trim()}"`,
          subLabel: "Press to select custom entered value",
        },
        ...matches,
      ];
    }

    return matches;
  }, [options, searchQuery, allowCustomInput]);

  const handlePaste = (e) => {
    const pasted = e.clipboardData ? e.clipboardData.getData("text") : "";
    if (pasted) {
      e.preventDefault();
      const cleaned = pasted
        .replace(/[\u200B-\u200D\uFEFF]/g, "")
        .replace(/[\r\n\t]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();
      setSearchQuery(cleaned);
    }
  };

  return (
    <div ref={containerRef} className={`relative text-left w-full ${className}`}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (!disabled) {
            setIsOpen(!isOpen);
            setSearchQuery("");
          }
        }}
        className={`w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-950 border ${
          error ? "border-rose-500" : "border-gray-200 dark:border-slate-800"
        } rounded-xl text-xs font-semibold text-gray-900 dark:text-white flex items-center justify-between focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer ${
          disabled ? "opacity-60 cursor-not-allowed" : ""
        }`}
      >
        <span
          className={
            selectedOption
              ? "font-bold truncate text-gray-900 dark:text-white"
              : "text-gray-400 dark:text-slate-500 truncate"
          }
        >
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <ChevronDown
          size={14}
          className={`text-gray-400 shrink-0 ml-2 transition-transform duration-200 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {isOpen && (
        <div className="absolute z-50 mt-1.5 w-full bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-scale-up">
          <div className="p-2 border-b border-gray-100 dark:border-slate-800">
            <div className="relative">
              <Search
                size={13}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"
              />
              <input
                type="text"
                autoFocus
                placeholder="Search or paste SKU / name..."
                value={searchQuery}
                onPaste={handlePaste}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-7 py-1.5 bg-gray-50 dark:bg-slate-950 border border-gray-200 dark:border-slate-800 rounded-xl text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-slate-200 p-0.5 rounded cursor-pointer"
                >
                  <X size={13} />
                </button>
              )}
            </div>
          </div>

          <div
            ref={listRef}
            className="max-h-56 overflow-y-auto p-1 divide-y divide-gray-50 dark:divide-slate-850"
          >
            {filteredOptions.length === 0 ? (
              <div className="p-3 text-center text-xs text-gray-400 font-medium">
                No matching items found
              </div>
            ) : (
              filteredOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  disabled={opt.disabled}
                  onClick={() => {
                    if (!opt.disabled) {
                      onChange(opt.value, opt);
                      setIsOpen(false);
                    }
                  }}
                  className={`w-full text-left px-3 py-2 text-xs font-medium rounded-xl transition-colors flex items-center justify-between cursor-pointer ${
                    value === opt.value
                      ? "bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold"
                      : opt.disabled
                      ? "opacity-40 cursor-not-allowed"
                      : "text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-850"
                  }`}
                >
                  <div className="truncate pr-2">
                    <div className="truncate font-bold">{opt.label}</div>
                    {opt.subLabel && (
                      <div className="text-[10px] text-gray-400 dark:text-slate-500 truncate">
                        {opt.subLabel}
                      </div>
                    )}
                  </div>
                  {value === opt.value && (
                    <CheckCircle size={13} className="text-blue-600 shrink-0" />
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function TransferModal({ isOpen, onClose, activeUser }) {
  const dispatch = useDispatch();
  const { showToast } = useMagicToast();

  const { materials = [], divisions = [], transactions = [] } =
    useSelector((state) => state.inventory);
  const { transfers = [], submitting = false } = useSelector(
    (state) => state.transfers || { transfers: [], submitting: false }
  );

  const currentUserName =
    activeUser?.name || localStorage.getItem("user-name") || "Guest Operator";

  const allowedDivisions = useMemo(() => {
    return getUserAllowedDivisions(activeUser);
  }, [activeUser]);

  // Standardize Division Names
  const normalizedDivisions = useMemo(() => {
    if (!divisions || divisions.length === 0) {
      return [
        "Nutech Composites",
        "NuTech Pipes",
        "Protech Max",
      ];
    }
    return divisions.map((d) => (typeof d === "string" ? d : d.name)).filter(Boolean);
  }, [divisions]);

  // Form State
  const [formData, setFormData] = useState({
    fromDivision: "",
    toDivision: "",
    skuCode: "",
    quantity: 1,
    transferDate: new Date().toISOString().slice(0, 10),
    operatorName: currentUserName,
    remarks: "",
  });

  const [formErrors, setFormErrors] = useState({});

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setFormData({
        fromDivision: "",
        toDivision: "",
        skuCode: "",
        quantity: 1,
        transferDate: new Date().toISOString().slice(0, 10),
        operatorName: currentUserName,
        remarks: "",
      });
      setFormErrors({});
      dispatch(fetchTransfers());
    }
  }, [isOpen, currentUserName, dispatch]);

  // Formatted SKU options for SearchableSelect — filtered to fromDivision when selected, else deduplicated
  const skuSelectOptions = useMemo(() => {
    const fromDiv = (formData.fromDivision || "").toLowerCase();

    let pool;
    if (fromDiv) {
      // Filter to division and deduplicate by SKU
      const seen = new Set();
      pool = materials.filter((m) => {
        if ((m.division || "").toLowerCase() !== fromDiv) return false;
        if (seen.has(m.sku)) return false;
        seen.add(m.sku);
        return true;
      });
    } else {
      // Deduplicate by SKU when no division selected
      const seen = new Set();
      pool = materials.filter((m) => {
        if (seen.has(m.sku)) return false;
        seen.add(m.sku);
        return true;
      });
    }

    return pool.map((mat) => ({
      value: mat.sku,
      label: `${mat.name} — ${mat.sku}`,
      subLabel: `Category: ${mat.category || "Item"} | Division: ${mat.division || "Default"}`,
      division: mat.division,
    }));
  }, [materials, formData.fromDivision]);

  // Division select options
  const fromDivisionOptions = useMemo(() => {
    let list = normalizedDivisions;
    if (allowedDivisions && allowedDivisions.length > 0) {
      list = list.filter((div) => isDivisionAllowed(div, allowedDivisions));
    }
    return list.map((div) => ({
      value: div,
      label: div,
    }));
  }, [normalizedDivisions, allowedDivisions]);

  const toDivisionOptions = useMemo(() => {
    return normalizedDivisions.map((div) => ({
      value: div,
      label: div === formData.fromDivision ? `${div} (Same as From Division)` : div,
      disabled: div === formData.fromDivision,
    }));
  }, [normalizedDivisions, formData.fromDivision]);

  // Selected Material Object — prefer match from fromDivision
  const selectedMaterial = useMemo(() => {
    if (!formData.skuCode) return null;
    const fromDiv = (formData.fromDivision || "").toLowerCase();
    if (fromDiv) {
      return (
        materials.find(
          (m) => m.sku === formData.skuCode && (m.division || "").toLowerCase() === fromDiv
        ) || materials.find((m) => m.sku === formData.skuCode)
      );
    }
    return materials.find((m) => m.sku === formData.skuCode);
  }, [materials, formData.skuCode, formData.fromDivision]);

  // Calculate available quantity for selected SKU in From Division
  const calculatedAvailableQty = useMemo(() => {
    if (!selectedMaterial) return 0;

    let qty = Number(selectedMaterial.opening) || 0;
    transactions.forEach((t) => {
      if (t.sku === selectedMaterial.sku) {
        if (t.type === "IN") {
          qty += Number(t.qty) || 0;
        } else if (t.type === "OUT") {
          qty -= Number(t.qty) || 0;
        }
      }
    });

    // Account for Approved internal transfers for selected SKU & division
    const fromDivLower = (formData.fromDivision || "").trim().toLowerCase();
    const skuLower = (selectedMaterial.sku || "").trim().toLowerCase();
    const nameLower = (selectedMaterial.name || "").trim().toLowerCase();
    transfers.forEach((trf) => {
      const trfSku = (trf.skuCode || "").trim().toLowerCase();
      if (trf.status === "Approved" && (trfSku === skuLower || trfSku === nameLower)) {
        if (fromDivLower && (trf.fromDivision || "").trim().toLowerCase() === fromDivLower) {
          qty -= Number(trf.quantity) || 0;
        }
        if (fromDivLower && (trf.toDivision || "").trim().toLowerCase() === fromDivLower) {
          qty += Number(trf.quantity) || 0;
        }
      }
    });

    return Math.max(0, qty);
  }, [selectedMaterial, transactions, transfers, formData.fromDivision]);

  // Handle Form Change
  const handleInputChange = (field, value, extraOpt) => {
    setFormData((prev) => {
      const next = { ...prev, [field]: value };
      if (field === "fromDivision") {
        next.skuCode = "";
        next.quantity = 1;
      } else if (field === "skuCode") {
        // Only auto-set fromDivision when it isn't already selected
        if (!prev.fromDivision) {
          const division = extraOpt?.division ||
            materials.find((m) => m.sku === value)?.division;
          if (division) {
            next.fromDivision = division;
            if (next.toDivision && next.toDivision.toLowerCase() === division.toLowerCase()) {
              next.toDivision = "";
            }
          }
        }
      }
      return next;
    });

    if (formErrors[field]) {
      setFormErrors((prev) => ({ ...prev, [field]: null }));
    }
  };

  // Form Submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = {};

    if (!formData.fromDivision) errors.fromDivision = "From Division is required";
    if (!formData.toDivision) errors.toDivision = "To Division is required";
    if (
      formData.fromDivision &&
      formData.toDivision &&
      formData.fromDivision === formData.toDivision
    ) {
      errors.toDivision = "To Division must be different from From Division";
    }
    if (!formData.skuCode) errors.skuCode = "SKU Code is required";
    if (!formData.quantity || Number(formData.quantity) < 1) {
      errors.quantity = "Minimum quantity is 1";
    } else if (Number(formData.quantity) > calculatedAvailableQty) {
      errors.quantity = `Maximum available quantity is ${calculatedAvailableQty}`;
    }
    if (!formData.transferDate) errors.transferDate = "Transfer Date is required";

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      showToast("Please fix errors in the transfer form", "error");
      return;
    }

    const payload = {
      fromDivision: formData.fromDivision,
      toDivision: formData.toDivision,
      skuCode: formData.skuCode,
      skuName: selectedMaterial?.name || "Material Item",
      unit: selectedMaterial?.unit || "PCS",
      quantity: Number(formData.quantity),
      availableQty: calculatedAvailableQty,
      transferDate: formData.transferDate,
      operatorName: currentUserName,
      remarks: formData.remarks,
    };

    const actionResult = await dispatch(submitTransfer(payload));

    if (submitTransfer.fulfilled.match(actionResult)) {
      showToast("Material transfer request submitted successfully!", "success");
      dispatch(fetchInventoryData());
      dispatch(fetchTransfers());
      onClose();
    } else {
      showToast(
        actionResult.payload || "Failed to submit transfer request",
        "error"
      );
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4 bg-gray-50/60 dark:bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 rounded-xl">
              <ArrowLeftRight size={20} />
            </div>
            <div>
              <h3 className="text-base font-black text-gray-900 dark:text-white">
                New Material Transfer Form
              </h3>
              <p className="text-xs text-gray-500 dark:text-slate-400 font-medium">
                Submit an internal transfer request between divisions
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-slate-200 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Division Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* From Division */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                <Building2 size={13} className="text-blue-500" />
                <span>From Division</span>
                <span className="text-rose-500">*</span>
              </label>
              <SearchableSelect
                value={formData.fromDivision}
                onChange={(val) => handleInputChange("fromDivision", val)}
                options={fromDivisionOptions}
                placeholder="Select From Division..."
                error={!!formErrors.fromDivision}
              />
              {formErrors.fromDivision && (
                <p className="text-[11px] font-bold text-rose-500">
                  {formErrors.fromDivision}
                </p>
              )}
            </div>

            {/* To Division */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                <Building2 size={13} className="text-indigo-500" />
                <span>To Division</span>
                <span className="text-rose-500">*</span>
              </label>
              <SearchableSelect
                value={formData.toDivision}
                onChange={(val) => handleInputChange("toDivision", val)}
                options={toDivisionOptions}
                placeholder="Select To Division..."
                error={!!formErrors.toDivision}
              />
              {formErrors.toDivision && (
                <p className="text-[11px] font-bold text-rose-500">
                  {formErrors.toDivision}
                </p>
              )}
            </div>
          </div>

          {/* SKU and Quantity Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* SKU Searchable Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                <Boxes size={13} className="text-blue-500" />
                <span>SKU Code</span>
                <span className="text-rose-500">*</span>
              </label>
              <SearchableSelect
                value={formData.skuCode}
                onChange={(val, opt) => handleInputChange("skuCode", val, opt)}
                options={skuSelectOptions}
                placeholder={
                  formData.fromDivision
                    ? `Select or paste SKU from ${formData.fromDivision}...`
                    : "Select or paste SKU Code..."
                }
                error={!!formErrors.skuCode}
              />
              {formErrors.skuCode && (
                <p className="text-[11px] font-bold text-rose-500">
                  {formErrors.skuCode}
                </p>
              )}
            </div>

            {/* Quantity */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Package size={13} className="text-emerald-500" />
                  <span>Quantity</span>
                  <span className="text-rose-500">*</span>
                </label>
                {selectedMaterial && (
                  <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md">
                    Available: {calculatedAvailableQty} {selectedMaterial.unit || "PCS"}
                  </span>
                )}
              </div>
              <input
                type="number"
                min={1}
                max={selectedMaterial ? calculatedAvailableQty : 999999}
                value={formData.quantity}
                onChange={(e) => handleInputChange("quantity", e.target.value)}
                placeholder="Enter quantity"
                className={`w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-950 border ${formErrors.quantity
                    ? "border-rose-500"
                    : "border-gray-200 dark:border-slate-800"
                  } rounded-xl text-xs font-semibold text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none`}
              />
              {formErrors.quantity && (
                <p className="text-[11px] font-bold text-rose-500">
                  {formErrors.quantity}
                </p>
              )}
            </div>
          </div>

          {/* Transfer Date and Operator Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Transfer Date */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                <Calendar size={13} className="text-blue-500" />
                <span>Transfer Date</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={formData.transferDate}
                onChange={(e) => handleInputChange("transferDate", e.target.value)}
                className={`w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-950 border ${formErrors.transferDate
                    ? "border-rose-500"
                    : "border-gray-200 dark:border-slate-800"
                  } rounded-xl text-xs font-semibold text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none`}
              />
              {formErrors.transferDate && (
                <p className="text-[11px] font-bold text-rose-500">
                  {formErrors.transferDate}
                </p>
              )}
            </div>

            {/* Operator Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
                <UserCheck size={13} className="text-emerald-500" />
                <span>Operator Name</span>
                <span className="text-[11px] font-normal text-gray-400">(Read only)</span>
              </label>
              <input
                type="text"
                readOnly
                value={formData.operatorName}
                className="w-full px-3.5 py-2.5 bg-gray-100 dark:bg-slate-950/80 border border-gray-200 dark:border-slate-800 rounded-xl text-xs font-bold text-gray-700 dark:text-slate-300 cursor-not-allowed"
              />
            </div>
          </div>

          {/* Remarks */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-700 dark:text-slate-300 flex items-center gap-1.5">
              <FileText size={13} className="text-gray-500" />
              <span>Remarks</span>
              <span className="text-[11px] font-normal text-gray-400">(Optional)</span>
            </label>
            <textarea
              rows={2}
              value={formData.remarks}
              onChange={(e) => handleInputChange("remarks", e.target.value)}
              placeholder="Add any specific notes or instructions for this transfer..."
              className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-950 border border-gray-200 dark:border-slate-800 rounded-xl text-xs font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-150 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-slate-800 text-xs font-bold text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-850 cursor-pointer transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 cursor-pointer disabled:opacity-60 transition-all active:scale-95"
            >
              <Send size={14} />
              <span>{submitting ? "Submitting..." : "Submit Transfer Request"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
