// src/systems/inventory/components/StockDashboardView.jsx
import { useState, useMemo, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Search,
  ChevronDown,
  X,
  History,
  TrendingUp,
  FileSpreadsheet,
  Plus,
  Download,
  Upload,
  Edit2,
  Trash2,
  CheckCircle2,
  FileText,
  AlertCircle,
  Activity,
  ArrowLeftRight,
  AlertTriangle,
  Layers,
  Check,
  Loader2,
  ClipboardList,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";
import Papa from "papaparse";
import RecycleModal from "./RecycleModal";
import DailyConsumptionModal from "./DailyConsumptionModal";
import TransferModal from "./TransferModal";
import PhysicalStockModal from "./PhysicalStockModal";
import { openBatchDetailPdfInNewTab } from "./batchDetailPdfTemplate";
import {
  isScrapItem,
  calculateMaterialRecycleImpact,
  getMaterialCategory,
  matchScrapMaterialForFg,
} from "../utils/scrapUtils";
import {
  fetchInventoryData,
  saveMaterial,
  saveMaterialsBatch,
  deleteMaterial,
  saveSettings,
  postTransaction,
  clearError,
} from "../../../redux/slice/inventorySlice";
import { useMagicToast } from "../../../context/MagicToastContext";
import { getUserAllowedDivisions, isDivisionAllowed } from "../../../utils/roleUtils";
import { usePagePermission, READ_ONLY_TOOLTIP } from "../../../utils/pagePermissionUtils";
import ReadOnlyBanner from "../../../components/ReadOnlyBanner";

function CustomSelect({
  value,
  onChange,
  options = [],
  placeholder = "Select...",
  required = false,
  className = "",
  disabled = false,
  showSearch = true,
  searchPlaceholder = "Search...",
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const containerRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const normalizedOptions = useMemo(() => {
    return options.map((opt) =>
      typeof opt === "string" || typeof opt === "number"
        ? { label: String(opt), value: String(opt) }
        : opt,
    );
  }, [options]);

  const selectedOption = useMemo(() => {
    return normalizedOptions.find((o) => o.value === value);
  }, [normalizedOptions, value]);

  const filteredOptions = useMemo(() => {
    if (!searchQuery.trim()) return normalizedOptions;
    const q = searchQuery.toLowerCase();
    return normalizedOptions.filter(
      (o) =>
        (o.label || "").toLowerCase().includes(q) ||
        (o.subLabel || "").toLowerCase().includes(q) ||
        (o.value || "").toLowerCase().includes(q),
    );
  }, [normalizedOptions, searchQuery]);

  return (
    <div ref={containerRef} className={`relative text-left ${className}`}>
      {required && (
        <input
          type="text"
          value={value || ""}
          onChange={() => { }}
          required
          tabIndex={-1}
          className="opacity-0 absolute inset-0 w-full h-full pointer-events-none -z-10"
        />
      )}
      <button
        type="button"
        disabled={disabled}
        onClick={() => {
          if (!disabled) {
            setIsOpen(!isOpen);
            setSearchQuery("");
          }
        }}
        className={`w-full px-3 py-2 border rounded-xl bg-gray-50 dark:bg-slate-950 text-sm flex items-center justify-between min-h-[38px] focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs transition-all ${value
            ? "border-indigo-500/50 dark:border-indigo-500/60 text-indigo-700 dark:text-indigo-300 font-semibold bg-indigo-50/40 dark:bg-indigo-950/30"
            : "border-gray-200 dark:border-slate-800 text-gray-900 dark:text-white"
          } ${disabled ? "opacity-60 cursor-not-allowed" : ""}`}
      >
        <span
          className={`whitespace-normal break-words leading-snug pr-1 text-left ${selectedOption && selectedOption.value !== ""
              ? "font-semibold text-gray-900 dark:text-white"
              : "text-gray-600 dark:text-slate-400"
            }`}
          title={selectedOption ? selectedOption.label : placeholder}
        >
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <div className="flex items-center gap-1 shrink-0 ml-1">
          {value ? (
            <span
              onClick={(e) => {
                e.stopPropagation();
                onChange("");
                setIsOpen(false);
              }}
              className="p-0.5 rounded-full hover:bg-gray-200 dark:hover:bg-slate-800 text-gray-400 hover:text-gray-600 dark:hover:text-slate-200"
              title="Clear selection"
            >
              <X size={13} />
            </span>
          ) : null}
          <ChevronDown
            size={14}
            className={`text-gray-400 shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="absolute left-0 top-full mt-1.5 min-w-full w-max max-w-[min(32rem,90vw)] bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-50 flex flex-col animate-scale-up">
          {showSearch && (
            <div className="p-2 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-950/50">
              <div className="relative">
                <Search
                  size={13}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  type="text"
                  autoFocus
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-gray-200 dark:border-slate-800 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          <div className="overflow-y-auto max-h-52 p-1.5 space-y-0.5">
            {filteredOptions.length === 0 ? (
              <div className="px-3.5 py-2 text-xs text-gray-400 dark:text-slate-500 text-center">
                No matching options
              </div>
            ) : (
              filteredOptions.map((opt) => {
                const isSelected = opt.value === value;
                return (
                  <div
                    key={String(opt.value)}
                    onClick={() => {
                      onChange(opt.value);
                      setIsOpen(false);
                    }}
                    className={`px-3 py-2 text-xs rounded-xl cursor-pointer transition-colors flex items-center justify-between ${isSelected
                        ? "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold"
                        : "text-gray-750 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-800/80"
                      }`}
                  >
                    <div className="pr-2 min-w-0">
                      <div className="whitespace-normal break-words font-semibold">{opt.label}</div>
                      {opt.subLabel && (
                        <div className="text-[10px] text-gray-400 dark:text-slate-500 whitespace-normal break-words">
                          {opt.subLabel}
                        </div>
                      )}
                    </div>
                    {isSelected && (
                      <Check
                        size={13}
                        className="shrink-0 text-indigo-600 dark:text-indigo-400 ml-1"
                      />
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const BAND_STYLES = {
  "Excess Stock": {
    rowCls: "bg-blue-500/5 hover:bg-blue-500/10 border-l-4 border-l-blue-500",
    badgeCls:
      "bg-blue-100 text-blue-700 dark:bg-blue-950/80 dark:text-blue-300",
  },
  "Normal Stock": {
    rowCls:
      "bg-emerald-500/5 hover:bg-emerald-500/10 border-l-4 border-l-emerald-500",
    badgeCls:
      "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300",
  },
  "66.33% Stock": {
    rowCls:
      "bg-amber-500/5 hover:bg-amber-500/10 border-l-4 border-l-amber-500",
    badgeCls:
      "bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300",
  },
  "Below 33%": {
    rowCls: "bg-rose-500/5 hover:bg-rose-500/10 border-l-4 border-l-rose-500",
    badgeCls:
      "bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300",
  },
};

export default function StockDashboardView({ activeUser }) {
  const dispatch = useDispatch();
  const { showToast } = useMagicToast();
  const { isReadOnly, canWrite } = usePagePermission("inventory_stock");
  const {
    materials,
    transactions,
    indents = [],
    settings,
    units = [],
    locations = [],
    materialNames = [],
    finishedGoodsNames = [],
    masterMaterials = [],
    divisions = [],
    categories: categoriesFromDb = [],
    physicalStocks = [],
    recycles = [],
  } = useSelector((state) => state.inventory);

  const { transfers: allTransfers = [] } = useSelector(
    (state) => state.transfers || {},
  );

  const isViewer = activeUser.role === "Viewer";

  const allowedDivisions = useMemo(() => {
    return getUserAllowedDivisions(activeUser);
  }, [activeUser]);

  const userAllowedDivisionsList = useMemo(() => {
    if (!allowedDivisions || allowedDivisions.length === 0) return divisions;
    return (divisions || []).filter((d) => isDivisionAllowed(d.name || d, allowedDivisions));
  }, [divisions, allowedDivisions]);

  // Phase 4 — Live master material lookup map: { [master_material_id]: masterMaterialRecord }
  // Used to display the always-up-to-date material name from the master catalog instead of the
  // static snapshot stored in transactions/stock rows.
  const masterMaterialMap = useMemo(() => {
    const map = {};
    (masterMaterials || []).forEach((m) => {
      if (m.id) map[m.id] = m;
    });
    return map;
  }, [masterMaterials]);

  // Lookup map for resolving finished good categories
  const fgLookupMap = useMemo(() => {
    const map = {};
    (masterMaterials || []).forEach((m) => {
      if (m.sku) map[m.sku] = m;
      if (m.name) map[m.name] = m;
    });
    (materials || []).forEach((m) => {
      if (m.sku) map[m.sku] = m;
      if (m.name) map[m.name] = m;
    });
    (finishedGoodsNames || []).forEach((fg) => {
      if (typeof fg === "object") {
        if (fg.sku) map[fg.sku] = fg;
        if (fg.name) map[fg.name] = fg;
      }
    });
    return map;
  }, [masterMaterials, materials, finishedGoodsNames]);

  // States
  const [search, setSearch] = useState("");
  const [materialTypeFilter, setMaterialTypeFilter] = useState("");
  const [firmFilter, setFirmFilter] = useState("");
  const [category, setCategory] = useState("");
  const [subCategoryFilter, setSubCategoryFilter] = useState("");
  const [skuFilter, setSkuFilter] = useState("");
  const [band, setBand] = useState("");

  // Physical Stock Modal States
  const [isPhysicalStockModalOpen, setIsPhysicalStockModalOpen] = useState(false);
  const [physicalModalPrefill, setPhysicalModalPrefill] = useState(null);
  const pendingPhysicalCount = useMemo(
    () =>
      (physicalStocks || []).filter(
        (p) => (p.status || "").toLowerCase() === "pending",
      ).length,
    [physicalStocks],
  );

  // Table Pagination / Sorting state
  const [currentPage, setCurrentPage] = useState(1);
  const [sortKey, setSortKey] = useState("sku");
  const [sortDir, setSortDir] = useState(1); // 1 = asc, -1 = desc

  // Modal states
  const [historyModal, setHistoryModal] = useState({
    isOpen: false,
    sku: "",
    type: "",
  });
  const [recycleHistoryModal, setRecycleHistoryModal] = useState({
    isOpen: false,
    sku: "",
    division: "",
  });
  const [trendModal, setTrendModal] = useState({
    isOpen: false,
    sku: "",
    division: "",
  });

  // Add Material Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("add"); // 'add' or 'edit'
  const [formId, setFormId] = useState(null);
  const [formMaterialType, setFormMaterialType] = useState("RM"); // 'RM' (Raw Material) or 'FG' (Finished Goods)
  const [formSku, setFormSku] = useState("");
  const [formCategory, setFormCategory] = useState("");
  const [formExistingCategory, setFormExistingCategory] = useState("RAW MATERIAL");
  const [formSubCategory, setFormSubCategory] = useState("");
  const [formUnit, setFormUnit] = useState("");
  const [formLocation, setFormLocation] = useState("");
  const [formDivision, setFormDivision] = useState("");
  const [formOpening, setFormOpening] = useState(0);
  const [formAdc, setFormAdc] = useState(0);
  const [formLeadTime, setFormLeadTime] = useState(0);
  const [formSafetyFactor, setFormSafetyFactor] = useState(0);
  const [formMoq, setFormMoq] = useState(0);
  const [formSupplierName, setFormSupplierName] = useState("");
  const [formSupplierCode, setFormSupplierCode] = useState("");
  const [formStatus, setFormStatus] = useState("Active");
  const [formMasterMaterialId, setFormMasterMaterialId] = useState(null); // Phase 5 — FK ID from inventory_master_material
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showSubCategoryDropdown, setShowSubCategoryDropdown] = useState(false);
  const [showSkuDropdown, setShowSkuDropdown] = useState(false);

  // CSV Import Preview Modal State
  const [csvPreviewModal, setCsvPreviewModal] = useState({
    isOpen: false,
    type: "", // 'raw_materials' or 'finished_goods'
    title: "",
    fileName: "",
    validRows: [],
    skippedRows: [],
    activeTab: "valid",
    searchQuery: "",
    isSubmitting: false,
    inputEvent: null,
  });

  // Post Transaction Modal States
  const [isTxnModalOpen, setIsTxnModalOpen] = useState(false);
  const [isRecycleModalOpen, setIsRecycleModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isConsumptionModalOpen, setIsConsumptionModalOpen] = useState(false);
  const [reportSearch, setReportSearch] = useState("");
  const [reportTypeFilter, setReportTypeFilter] = useState("");
  const [reportFromDate, setReportFromDate] = useState("");
  const [reportToDate, setReportToDate] = useState("");
  const [txnFormSku, setTxnFormSku] = useState("");
  const [txnFormQty, setTxnFormQty] = useState("");
  const [txnFormType, setTxnFormType] = useState("IN");
  const [txnFormRef, setTxnFormRef] = useState("");
  const [txnFormRemarks, setTxnFormRemarks] = useState("");
  const [txnFormDate, setTxnFormDate] = useState(
    new Date().toISOString().slice(0, 10),
  );
  const [txnFormLocation, setTxnFormLocation] = useState("");
  const [txnFormDivision, setTxnFormDivision] = useState("");

  // IN-specific states
  const [txnFormBillingDate, setTxnFormBillingDate] = useState(
    new Date().toISOString().slice(0, 16),
  );
  const [txnFormReceivingDate, setTxnFormReceivingDate] = useState(
    new Date().toISOString().slice(0, 16),
  );

  // Common & OUT-specific states
  const [txnFormPartyName, setTxnFormPartyName] = useState("");
  const [txnFormDestination, setTxnFormDestination] = useState("");
  const [txnFormChallanNo, setTxnFormChallanNo] = useState("");
  const [txnFormInvoiceNo, setTxnFormInvoiceNo] = useState("");
  const [txnFormVehicleNo, setTxnFormVehicleNo] = useState("");

  // OUT & IN multi-row materials
  const [txnFormInItems, setTxnFormInItems] = useState([
    { sku: "", qty: "", unit: "" },
  ]);
  const [txnFormOutItems, setTxnFormOutItems] = useState([
    { sku: "", qty: "", unit: "" },
  ]);

  // Job Card specific states
  const [txnFormFgCategory, setTxnFormFgCategory] = useState("");
  const [txnFormBatches, setTxnFormBatches] = useState([
    {
      materials: [{ sku: "", qty: "" }],
      numBatches: "",
      remainingBatches: "",
      remainingMaterial: "",
    },
  ]);

  const [txnFormFgItems, setTxnFormFgItems] = useState([
    { sku: "", qty: "", scraps: "" },
  ]);

  const handleAddFgItemRow = () => {
    setTxnFormFgItems((prev) => [...prev, { sku: "", qty: "", scraps: "" }]);
  };

  const handleRemoveFgItemRow = (index) => {
    setTxnFormFgItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleFgItemChange = (index, field, value) => {
    setTxnFormFgItems((prev) =>
      prev.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    );
  };

  const [, setTxnFormRawMaterials] = useState([{ sku: "", qty: "" }]);

  const handleAddInItemRow = () => {
    setTxnFormInItems((prev) => [...prev, { sku: "", qty: "", unit: "" }]);
  };

  const handleRemoveInItemRow = (index) => {
    setTxnFormInItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleInItemChange = (index, field, value) => {
    setTxnFormInItems((prev) =>
      prev.map((item, i) => {
        if (i !== index) return item;
        const updated = { ...item, [field]: value };
        if (field === "sku") {
          const mat = allActiveMaterials.find((m) => m.sku === value);
          updated.unit = mat?.unit || item.unit || "";
        }
        return updated;
      }),
    );
  };

  const handleAddOutItemRow = () => {
    setTxnFormOutItems((prev) => [...prev, { sku: "", qty: "", unit: "" }]);
  };

  const handleRemoveOutItemRow = (index) => {
    setTxnFormOutItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleOutItemChange = (index, field, value) => {
    setTxnFormOutItems((prev) =>
      prev.map((item, i) => {
        if (i !== index) return item;
        const updated = { ...item, [field]: value };
        if (field === "sku") {
          const mat = allActiveMaterials.find((m) => m.sku === value);
          updated.unit = mat?.unit || item.unit || "";
        }
        return updated;
      }),
    );
  };

  // Job Card batch handlers
  const handleAddBatch = () => {
    setTxnFormBatches((prev) => [
      ...prev,
      {
        materials: [{ sku: "", qty: "" }],
        numBatches: "",
        remainingBatches: "",
        remainingMaterial: "",
      },
    ]);
  };

  const handleRemoveBatch = (batchIndex) => {
    setTxnFormBatches((prev) => prev.filter((_, i) => i !== batchIndex));
  };

  const handleBatchFieldChange = (batchIndex, field, value) => {
    setTxnFormBatches((prev) =>
      prev.map((batch, i) =>
        i === batchIndex ? { ...batch, [field]: value } : batch,
      ),
    );
  };

  const handleAddBatchMaterial = (batchIndex) => {
    setTxnFormBatches((prev) =>
      prev.map((batch, i) =>
        i === batchIndex
          ? { ...batch, materials: [...batch.materials, { sku: "", qty: "" }] }
          : batch,
      ),
    );
  };

  const handleRemoveBatchMaterial = (batchIndex, matIndex) => {
    setTxnFormBatches((prev) =>
      prev.map((batch, i) =>
        i === batchIndex
          ? {
            ...batch,
            materials: batch.materials.filter((_, j) => j !== matIndex),
          }
          : batch,
      ),
    );
  };

  const handleBatchMaterialChange = (batchIndex, matIndex, field, value) => {
    setTxnFormBatches((prev) =>
      prev.map((batch, i) =>
        i === batchIndex
          ? {
            ...batch,
            materials: batch.materials.map((mat, j) =>
              j === matIndex ? { ...mat, [field]: value } : mat,
            ),
          }
          : batch,
      ),
    );
  };

  const handleAdd = () => {
    if (!canWrite) return;
    setModalMode("add");
    setFormId(null);
    setFormMaterialType("RM");
    setFormSku("");
    setFormCategory("");
    setFormSubCategory("");
    setFormExistingCategory(rmCategories[0] || "RAW MATERIAL");
    setFormUnit(units[0] || "KG");
    setFormDivision("");
    setFormLocation(locations[0]?.location || "");
    setFormOpening(0);
    setFormAdc(0);
    setFormLeadTime(0);
    setFormSafetyFactor(0);
    setFormMoq(0);
    setFormSupplierName("");
    setFormSupplierCode("");
    setFormStatus("Active");
    setFormMasterMaterialId(null); // Phase 5
    setIsModalOpen(true);
  };

  const handleEdit = (itemOrSku) => {
    if (!canWrite) return;
    const item =
      itemOrSku && typeof itemOrSku === "object"
        ? itemOrSku
        : materials.find((m) => m.sku === itemOrSku || m.id === itemOrSku);
    if (!item) return;
    setModalMode("edit");
    setFormId(item.id || null);

    const rawType = (
      item.materialType ||
      item.material_type ||
      ""
    ).toUpperCase().trim();

    const isFG =
      rawType === "FG"
        ? true
        : rawType === "RM"
          ? false
          : (item.category || "").trim().toLowerCase() === "finished goods" ||
          (item.category || "").trim().toLowerCase() === "fg";

    setFormMaterialType(isFG ? "FG" : "RM");
    setFormSku(item.sku || "");

    const resolvedName =
      (item.masterMaterialId && masterMaterialMap[item.masterMaterialId]?.name) ||
      item.name ||
      item.subCategory ||
      item.sku ||
      "";

    if (isFG) {
      setFormCategory(item.category || "Finished Goods");
      setFormSubCategory(resolvedName);
      setFormExistingCategory(item.category || "Finished Goods");
    } else {
      // For RM: formCategory represents the "Material *" name input
      setFormCategory(resolvedName);
      setFormSubCategory("");
      setFormExistingCategory(item.category || "RAW MATERIAL");
    }

    setFormUnit(item.unit || units[0] || (isFG ? "NOS" : "KG"));
    setFormLocation(item.location || "");
    setFormDivision(item.division || "");
    setFormOpening(item.opening || 0);
    setFormAdc(item.adc || 0);
    setFormLeadTime(item.leadTime || 0);
    setFormSafetyFactor(item.safetyFactor || 0);
    setFormMoq(item.moq || 0);
    setFormSupplierName(item.supplierName || "");
    setFormSupplierCode(item.supplierCode || "");
    setFormStatus(item.status || "Active");
    setFormMasterMaterialId(item.masterMaterialId || null); // Phase 5 — carry FK into edit form
    setIsModalOpen(true);
  };

  const handleDelete = (itemOrSku) => {
    if (!canWrite) return;
    const item =
      itemOrSku && typeof itemOrSku === "object"
        ? itemOrSku
        : materials.find((m) => m.sku === itemOrSku || m.id === itemOrSku);
    const displayLabel = item
      ? `${item.sku}${item.division ? ` (${item.division})` : ""}`
      : itemOrSku;
    if (
      window.confirm(
        `Are you sure you want to delete material ${displayLabel}? This cannot be undone.`,
      )
    ) {
      dispatch(
        deleteMaterial({
          id: item?.id,
          sku: item?.sku || itemOrSku,
          currentUser: activeUser.name,
        }),
      );
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!canWrite) return;
    if (
      !formSku ||
      !formCategory ||
      !formUnit ||
      (formMaterialType === "FG" && !formSubCategory)
    ) {
      alert("Please fill out all required fields marked with *");
      return;
    }

    if (
      modalMode === "add" &&
      formDivision &&
      materials.some(
        (m) =>
          m.sku.toLowerCase() === formSku.trim().toLowerCase() &&
          (m.division || "").toLowerCase() ===
          formDivision.trim().toLowerCase(),
      )
    ) {
      alert(`SKU "${formSku}" already exists for division "${formDivision}"!`);
      return;
    }

    const matName = formCategory.trim();
    const payload = {
      id: formId || undefined,
      sku: formSku.trim(),
      materialType: formMaterialType,
      masterMaterialId: formMasterMaterialId || undefined, // Phase 5 — pass FK to saveMaterialApi
      name:
        formMaterialType === "FG"
          ? formSubCategory.trim()
          : matName || formSku.trim(),
      category:
        formMaterialType === "RM"
          ? (formExistingCategory || rmCategories[0] || "RAW MATERIAL")
          : matName,
      subCategory: formMaterialType === "FG" ? formSubCategory.trim() : "",
      unit: formUnit,
      location: formLocation,
      division: formDivision,
      opening: Number(formOpening) || 0,
      adc: Number(formAdc) || 0,
      leadTime: Number(formLeadTime) || 0,
      safetyFactor: Number(formSafetyFactor) || 0,
      moq: Number(formMoq) || 0,
      supplierName: formSupplierName.trim(),
      supplierCode: formSupplierCode.trim(),
      status: formStatus,
    };

    dispatch(saveMaterial({ material: payload, currentUser: activeUser.name }));
    setIsModalOpen(false);
  };

  const modalSafetyStock =
    (Number(formAdc) || 0) * (Number(formSafetyFactor) || 0);
  const modalReorderLevel =
    (Number(formAdc) || 0) * (Number(formLeadTime) || 0) + modalSafetyStock;
  const modalMaxLevel = modalReorderLevel + (Number(formMoq) || 0);

  // Derived closing stock per SKU (for OUT warning in transaction modal)
  const currentClosingStocks = useMemo(() => {
    const balances = {};
    materials.forEach((m) => {
      balances[m.sku] = Number(m.opening) || 0;
    });
    transactions.forEach((t) => {
      if (balances[t.sku] !== undefined) {
        const isAddition =
          t.type === "IN" ||
          (t.type || "").toUpperCase() === "IN" ||
          t.type === "Job Card" ||
          (t.type || "").toUpperCase() === "JOB CARD" ||
          (t.isJobCard && (t.materialType === "FG" || (t.type || "").toUpperCase() !== "OUT"));
        balances[t.sku] +=
          isAddition ? Number(t.qty) || 0 : -(Number(t.qty) || 0);
      }
    });
    (allTransfers || [])
      .filter((t) => t.status === "Approved")
      .forEach((trf) => {
        const sku = trf.skuCode;
        const qty = Number(trf.quantity) || 0;
        const mat = materials.find((m) => m.sku === sku);
        if (!mat) return;
        if (mat.division === trf.fromDivision)
          balances[sku] = (balances[sku] || 0) - qty;
        if (mat.division === trf.toDivision)
          balances[sku] = (balances[sku] || 0) + qty;
      });
    const completedRecycles = (recycles || []).filter(
      (r) => (r.status || "").toLowerCase() === "completed",
    );
    materials.forEach((m) => {
      const sku = m.sku;
      if (sku && balances[sku] !== undefined) {
        const { directRecycleQty, fgScrapWeightAdded, isScrap } =
          calculateMaterialRecycleImpact(m, completedRecycles, fgLookupMap);
        if (isScrap) {
          balances[sku] += directRecycleQty + fgScrapWeightAdded;
        } else {
          balances[sku] -= directRecycleQty;
        }
      }
    });
    return balances;
  }, [materials, transactions, allTransfers, recycles, fgLookupMap]);


  const handleTxnSkuChange = (sku) => {
    setTxnFormSku(sku);
    const mat = materials.find((m) => m.sku === sku);
    setTxnFormLocation(mat ? mat.location || "" : "");
  };

  const handleOpenTxnModal = () => {
    if (!canWrite) return;
    setTxnFormSku("");
    setTxnFormQty("");
    setTxnFormType("IN");
    setTxnFormRef("");
    setTxnFormRemarks("");
    setTxnFormLocation("");
    setTxnFormDivision("");
    setTxnFormDate(new Date().toISOString().slice(0, 10));
    setTxnFormBillingDate(new Date().toISOString().slice(0, 16));
    setTxnFormReceivingDate(new Date().toISOString().slice(0, 16));
    setTxnFormPartyName("");
    setTxnFormDestination("");
    setTxnFormChallanNo("");
    setTxnFormInvoiceNo("");
    setTxnFormVehicleNo("");
    setTxnFormInItems([{ sku: "", qty: "" }]);
    setTxnFormOutItems([{ sku: "", qty: "" }]);
    setTxnFormFgCategory("");
    setTxnFormBatches([
      {
        materials: [{ sku: "", qty: "" }],
        numBatches: "",
        remainingBatches: "",
        remainingMaterial: "",
      },
    ]);
    setTxnFormFgItems([{ sku: "", qty: "", scraps: "" }]);
    setTxnFormRawMaterials([{ sku: "", qty: "" }]);
    setIsTxnModalOpen(true);
  };

  const handlePostTransaction = async (e) => {
    e.preventDefault();
    if (!canWrite) return;

    if (!txnFormType) {
      alert("Please select a movement type.");
      return;
    }

    const isJobCard = txnFormType === "Job card";

    if (isJobCard) {
      if (!txnFormFgCategory) {
        alert("Please select a Finished Goods Category.");
        return;
      }
      if (txnFormFgItems.length === 0) {
        alert("Please add at least one Finished Goods row.");
        return;
      }

      // Collect & validate all finished goods
      const validatedFgItems = [];
      for (let fi = 0; fi < txnFormFgItems.length; fi++) {
        const fgItem = txnFormFgItems[fi];
        const fgSku = (fgItem.sku || "").trim();
        if (!fgSku) {
          alert(`Please select Finished Goods SKU in row ${fi + 1}.`);
          return;
        }
        const fgQty = Number(fgItem.qty);
        if (isNaN(fgQty) || fgQty < 0) {
          alert(
            `Please enter a valid Finished Goods quantity in row ${fi + 1}.`,
          );
          return;
        }
        const scraps = Number(fgItem.scraps) || 0;
        if (fgItem.scraps !== "" && (isNaN(scraps) || scraps < 0)) {
          alert(`Please enter a valid Scraps quantity in row ${fi + 1}.`);
          return;
        }

        const fgSkuClean = fgSku.toLowerCase();
        const existingFg =
          materials.find((m) => (m.sku || "").trim().toLowerCase() === fgSkuClean) ||
          allActiveMaterials.find((m) => (m.sku || "").trim().toLowerCase() === fgSkuClean) || {
            sku: fgSku,
            name: fgSku,
            materialType: "FG",
          };

        validatedFgItems.push({
          sku: fgSku,
          name: existingFg.name || fgSku,
          qty: fgQty,
          scraps: scraps,
          material: existingFg,
        });
      }

      // Collect & validate all raw materials across all batches
      const validatedItems = [];
      for (let bi = 0; bi < txnFormBatches.length; bi++) {
        const batch = txnFormBatches[bi];
        if (!batch.materials || batch.materials.length === 0) {
          alert(`Please add at least one material in Batch ${bi + 1}.`);
          return;
        }
        for (let mi = 0; mi < batch.materials.length; mi++) {
          const item = batch.materials[mi];
          if (!item.sku) {
            alert(
              `Please select a Material in Batch ${bi + 1}, row ${mi + 1}.`,
            );
            return;
          }
          const perBatchQty = Number(item.qty);
          const qty = perBatchQty * (Number(batch.numBatches) || 1);
          if (!perBatchQty || perBatchQty <= 0) {
            alert(
              `Please enter a valid quantity for Material in Batch ${bi + 1}, row ${mi + 1}.`,
            );
            return;
          }

          const itemSkuClean = (item.sku || "").trim().toLowerCase();
          const selectedMat =
            materials.find((m) => (m.sku || "").trim().toLowerCase() === itemSkuClean) ||
            allActiveMaterials.find((m) => (m.sku || "").trim().toLowerCase() === itemSkuClean);
          if (!selectedMat) {
            alert(
              `Invalid Material selected in Batch ${bi + 1}, row ${mi + 1}.`,
            );
            return;
          }

          validatedItems.push({
            sku: item.sku,
            name: selectedMat.name || item.sku,
            qty,
            material: selectedMat,
          });
        }
      }

      if (validatedItems.length === 0) {
        alert("Please add at least one material in Batch Details.");
        return;
      }

      // Check balance for OUT (raw materials consumed)
      for (const item of validatedItems) {
        const balance = currentClosingStocks[item.sku] || 0;
        if (item.qty > balance) {
          const proceed = window.confirm(
            `WARNING: Outward issue of raw material "${item.sku}" (${item.qty.toLocaleString()}) exceeds current closing stock of ${balance.toLocaleString()}.\n\nPost anyway?`,
          );
          if (!proceed) return;
        }
      }

      // Now post the transactions sequentially to prevent sequence / PK collision
      try {
        // 1. Post OUT transactions for all raw materials sequentially
        for (const item of validatedItems) {
          await dispatch(
            postTransaction({
              transaction: {
                sku: item.sku,
                name: item.name,
                materialType: item.material
                  ? item.material.materialType || "RM"
                  : "RM",
                qty: item.qty,
                type: "OUT",
                date: txnFormDate,
                ref: txnFormRef.trim(),
                remarks: txnFormRemarks.trim(),
                user: activeUser.name,
                firm: txnFormDivision || activeUser.division || "",
                isJobCard: true,
              },
              currentUser: activeUser.name,
            }),
          ).unwrap();
        }

        // Enrich batch materials with names from master before dispatch
        const enrichedBatches = txnFormBatches.map((batch) => ({
          ...batch,
          materials: (batch.materials || []).map((m) => {
            const mClean = (m.sku || "").trim().toLowerCase();
            const mat =
              materials.find((item) => (item.sku || "").trim().toLowerCase() === mClean) ||
              allActiveMaterials.find((item) => (item.sku || "").trim().toLowerCase() === mClean);
            return {
              ...m,
              name: mat ? mat.name || m.sku : m.sku,
            };
          }),
        }));

        // 2. Post Finished Goods IN (Job Card) transactions sequentially for each finished goods item
        for (const fgItem of validatedFgItems) {
          await dispatch(
            postTransaction({
              transaction: {
                sku: fgItem.sku,
                name: fgItem.name,
                materialType: "FG",
                qty: fgItem.qty,
                scraps: fgItem.scraps,
                type: "Job Card",
                date: txnFormDate,
                ref: txnFormRef.trim(),
                remarks: txnFormRemarks.trim(),
                user: activeUser.name,
                firm: txnFormDivision || activeUser.division || "",
                isJobCard: true,
                fgCategory: txnFormFgCategory,
                batches: enrichedBatches,
              },
              currentUser: activeUser.name,
            }),
          ).unwrap();
        }
      } catch (err) {
        alert(`Failed to post Job Card transactions: ${err}`);
        return;
      }

      // Update location of raw materials if changed
      for (const item of validatedItems) {
        if (item.material?.id && txnFormLocation && txnFormLocation !== item.material.location) {
          dispatch(
            saveMaterial({
              material: { ...item.material, location: txnFormLocation },
              currentUser: activeUser.name,
            }),
          );
        }
      }

      // Update location of finished goods if changed
      for (const fgItem of validatedFgItems) {
        if (fgItem.material?.id && txnFormLocation && txnFormLocation !== fgItem.material.location) {
          dispatch(
            saveMaterial({
              material: { ...fgItem.material, location: txnFormLocation },
              currentUser: activeUser.name,
            }),
          );
        }
      }
    } else if (txnFormType === "IN") {
      // IN Transaction (Single SKU)
      if (!txnFormBillingDate) {
        alert("Please select a Billing Date.");
        return;
      }
      if (!txnFormReceivingDate) {
        alert("Please select a Receiving Date.");
        return;
      }
      if (!txnFormPartyName.trim()) {
        alert("Please enter Party Name.");
        return;
      }
      if (!txnFormInvoiceNo.trim()) {
        alert("Please enter Invoice Number.");
        return;
      }
      if (txnFormInItems.length === 0) {
        alert("Please add at least one material.");
        return;
      }

      const validatedInItems = [];
      for (let i = 0; i < txnFormInItems.length; i++) {
        const item = txnFormInItems[i];
        if (!item.sku) {
          alert(`Please select a Material in row ${i + 1}.`);
          return;
        }
        const qty = Number(item.qty);
        if (!qty || qty <= 0) {
          alert(`Please enter a valid quantity for Material in row ${i + 1}.`);
          return;
        }

        const selectedMat =
          materials.find((m) => m.sku === item.sku) ||
          allActiveMaterials.find((m) => m.sku === item.sku);
        if (!selectedMat) {
          alert(`Invalid Material selected in row ${i + 1}.`);
          return;
        }

        validatedInItems.push({
          sku: item.sku,
          name: selectedMat.name,
          qty,
          unit: item.unit || selectedMat.unit || "KG",
          material: selectedMat,
        });
      }

      const receivingDateVal = txnFormReceivingDate
        ? txnFormReceivingDate.slice(0, 10)
        : new Date().toISOString().slice(0, 10);

      // Post IN transactions sequentially
      try {
        for (const item of validatedInItems) {
          await dispatch(
            postTransaction({
              transaction: {
                sku: item.sku,
                name: item.name,
                materialType: item.material
                  ? item.material.materialType || "RM"
                  : "RM",
                qty: item.qty,
                unit: item.unit,
                type: "IN",
                date: receivingDateVal,
                billingDate: txnFormBillingDate,
                receivingDate: txnFormReceivingDate,
                partyName: txnFormPartyName.trim(),
                invoiceNo: txnFormInvoiceNo.trim(),
                ref: txnFormRef.trim() || txnFormInvoiceNo.trim(),
                remarks: txnFormRemarks.trim(),
                user: activeUser.name,
                firm: txnFormDivision || activeUser.division || "",
                isJobCard: false,
              },
              currentUser: activeUser.name,
            }),
          ).unwrap();

          if (txnFormLocation && txnFormLocation !== item.material.location) {
            dispatch(
              saveMaterial({
                material: { ...item.material, location: txnFormLocation },
                currentUser: activeUser.name,
              }),
            );
          }
        }
      } catch (err) {
        alert(`Failed to post IN transactions: ${err}`);
        return;
      }
    } else if (txnFormType === "OUT") {
      // OUT Transaction (Multi-Row SKU + Qty)
      if (!txnFormDate) {
        alert("Please select a Transaction Date.");
        return;
      }
      if (!txnFormPartyName.trim()) {
        alert("Please enter Party Name.");
        return;
      }
      if (!txnFormDestination.trim()) {
        alert("Please enter Destination.");
        return;
      }
      if (!txnFormChallanNo.trim()) {
        alert("Please enter Challan Number.");
        return;
      }
      if (!txnFormInvoiceNo.trim()) {
        alert("Please enter Invoice Number.");
        return;
      }

      if (txnFormOutItems.length === 0) {
        alert("Please add at least one material.");
        return;
      }

      const validatedOutItems = [];
      for (let i = 0; i < txnFormOutItems.length; i++) {
        const item = txnFormOutItems[i];
        if (!item.sku) {
          alert(`Please select a Material in row ${i + 1}.`);
          return;
        }
        const qty = Number(item.qty);
        if (!qty || qty <= 0) {
          alert(`Please enter a valid quantity for Material in row ${i + 1}.`);
          return;
        }

        const selectedMat =
          materials.find((m) => m.sku === item.sku) ||
          allActiveMaterials.find((m) => m.sku === item.sku);
        if (!selectedMat) {
          alert(`Invalid Material selected in row ${i + 1}.`);
          return;
        }

        validatedOutItems.push({
          sku: item.sku,
          name: selectedMat.name,
          qty,
          unit: item.unit || selectedMat.unit || "KG",
          material: selectedMat,
        });
      }

      // Check stock balance for OUT
      for (const item of validatedOutItems) {
        const balance = currentClosingStocks[item.sku] || 0;
        if (item.qty > balance) {
          const proceed = window.confirm(
            `WARNING: Outward issue of "${item.sku}" (${item.qty.toLocaleString()}) exceeds current closing stock of ${balance.toLocaleString()}.\n\nPost anyway?`,
          );
          if (!proceed) return;
        }
      }

      // Post OUT transactions sequentially
      try {
        for (const item of validatedOutItems) {
          await dispatch(
            postTransaction({
              transaction: {
                sku: item.sku,
                name: item.name,
                materialType: item.material
                  ? item.material.materialType || "RM"
                  : "RM",
                qty: item.qty,
                unit: item.unit,
                type: "OUT",
                date: txnFormDate,
                partyName: txnFormPartyName.trim(),
                destination: txnFormDestination.trim(),
                challanNo: txnFormChallanNo.trim(),
                invoiceNo: txnFormInvoiceNo.trim(),
                vehicleNo: txnFormVehicleNo.trim(),
                ref: txnFormRef.trim(),
                remarks: txnFormRemarks.trim(),
                user: activeUser.name,
                firm: txnFormDivision || activeUser.division || "",
                isJobCard: false,
              },
              currentUser: activeUser.name,
            }),
          ).unwrap();

          if (txnFormLocation && txnFormLocation !== item.material.location) {
            dispatch(
              saveMaterial({
                material: { ...item.material, location: txnFormLocation },
                currentUser: activeUser.name,
              }),
            );
          }
        }
      } catch (err) {
        alert(`Failed to post OUT transactions: ${err}`);
        return;
      }
    }
    setIsTxnModalOpen(false);
  };

  // Material names list (Raw Material Catalog strictly from inventory_master_material / legacy tables)
  const rmCatalogItems = useMemo(() => {
    const list = [];
    const sourceList =
      masterMaterials && masterMaterials.length > 0
        ? masterMaterials.filter(
          (m) => (m.materialType || m.material_type || "").toUpperCase() === "RM",
        )
        : materialNames || [];

    sourceList.forEach((item) => {
      if (typeof item === "string") {
        if (item.trim())
          list.push({
            name: item.trim(),
            sku: "",
            category: "RAW MATERIAL",
            materialType: "RM",
          });
      } else if (item && typeof item === "object") {
        const rawName =
          typeof item.name === "string"
            ? item.name
            : item.name?.name
              ? item.name.name
              : item.name
                ? String(item.name)
                : "";
        const rawSku =
          typeof item.sku === "string"
            ? item.sku
            : item.sku
              ? String(item.sku)
              : "";
        const rawDiv = typeof item.division === "string" ? item.division : "";
        const rawCat =
          typeof item.category === "string" && item.category.trim()
            ? item.category.trim()
            : "RAW MATERIAL";
        const name = (rawName || "").trim();
        const sku = (rawSku || "").trim();
        const division = (rawDiv || "").trim();
        if (name || sku)
          list.push({
            name,
            sku,
            division,
            category: rawCat,
            materialType: "RM",
          });
      }
    });
    return list;
  }, [masterMaterials, materialNames]);

  // Finished Goods Catalog (strictly from inventory_master_material / legacy tables)
  const fgCatalogItems = useMemo(() => {
    const list = [];
    const sourceList =
      masterMaterials && masterMaterials.length > 0
        ? masterMaterials.filter(
          (m) => (m.materialType || m.material_type || "").toUpperCase() === "FG",
        )
        : finishedGoodsNames || [];

    sourceList.forEach((item) => {
      if (typeof item === "string") {
        if (item.trim())
          list.push({
            name: item.trim(),
            sku: "",
            category: "Finished Goods",
            division: "",
            materialType: "FG",
          });
      } else if (item && typeof item === "object") {
        const rawName =
          typeof item.name === "string"
            ? item.name
            : item.name?.name
              ? item.name.name
              : item.name
                ? String(item.name)
                : "";
        const rawSku =
          typeof item.sku === "string"
            ? item.sku
            : item.sku
              ? String(item.sku)
              : "";
        const rawCat =
          typeof item.category === "string" ? item.category : "Finished Goods";
        const rawDiv = typeof item.division === "string" ? item.division : "";
        const name = (rawName || "").trim();
        const sku = (rawSku || "").trim();
        const category = (rawCat || "Finished Goods").trim();
        const division = (rawDiv || "").trim();
        if (name || sku)
          list.push({ name, sku, category, division, materialType: "FG" });
      }
    });
    return list;
  }, [masterMaterials, finishedGoodsNames]);

  // Unified list of all active items (Raw Materials + Finished Goods) for SKU selection dropdowns
  const allActiveMaterials = useMemo(() => {
    const map = new Map();
    // 1. Include active materials from inventory_materials master
    (materials || []).forEach((m) => {
      if (m.status !== "Inactive" && m.sku) {
        const skuKey = (m.sku || "").trim();
        if (skuKey && !map.has(skuKey.toLowerCase())) {
          const rawType = (
            m.materialType ||
            m.material_type ||
            ""
          ).toUpperCase();
          const isFG =
            rawType === "FG" ||
            (m.category && m.category.toLowerCase().trim() !== "raw material");
          map.set(skuKey.toLowerCase(), {
            id: m.masterMaterialId || null, // Phase 5 — carry master FK for dropdown capture
            sku: skuKey,
            name: m.name || skuKey,
            unit: m.unit || "",
            division: m.division || "",
            materialType: isFG ? "FG" : "RM",
          });
        }
      }
    });

    // 2. Include catalog items from Raw Materials & Finished Goods catalogs if not present
    // Phase 6 — Only include Active items so inactive materials are blocked from new transaction dropdowns
    (rmCatalogItems || []).filter(item => (item.status || 'Active') === 'Active').forEach((item) => {
      const skuKey = (item.sku || "").trim();
      if (skuKey && !map.has(skuKey.toLowerCase())) {
        map.set(skuKey.toLowerCase(), {
          sku: skuKey,
          name: item.name || skuKey,
          unit: item.unit || "",
          division: item.division || "",
          materialType: "RM",
        });
      }
    });

    // Phase 6 — Only include Active FG items in transaction dropdowns
    (fgCatalogItems || []).filter(item => (item.status || 'Active') === 'Active').forEach((item) => {
      const skuKey = (item.sku || "").trim();
      if (skuKey && !map.has(skuKey.toLowerCase())) {
        map.set(skuKey.toLowerCase(), {
          sku: skuKey,
          name: item.name || skuKey,
          unit: item.unit || "",
          division: item.division || "",
          materialType: "FG",
        });
      }
    });

    return Array.from(map.values()).sort((a, b) =>
      a.sku.localeCompare(b.sku, undefined, {
        numeric: true,
        sensitivity: "base",
      }),
    );
  }, [materials, rmCatalogItems, fgCatalogItems]);

  // Filtered raw materials list for Job Card Batch Details (strictly Raw Materials only, no Finished Goods)
  const allActiveRawMaterials = useMemo(() => {
    return allActiveMaterials.filter((m) => m.materialType === "RM");
  }, [allActiveMaterials]);

  // Filtered finished goods list for Job Card Total Production
  const allActiveFGMaterials = useMemo(() => {
    return allActiveMaterials.filter((m) => m.materialType === "FG");
  }, [allActiveMaterials]);

  // Extract unique firm / division list (from divisions table, finished goods, categories, and materials)
  const firms = useMemo(() => {
    const divNames = (divisions || [])
      .map((d) => (typeof d === "string" ? d : d.name))
      .filter(Boolean);
    const fgDivisions = fgCatalogItems.map((f) => f.division).filter(Boolean);
    const dbCatDivisions = (categoriesFromDb || [])
      .map((c) => (typeof c === "string" ? "" : c.division))
      .filter(Boolean);
    const matDivisions = materials.map((m) => m.division).filter(Boolean);

    const allExtracted = [
      ...new Set([
        ...divNames,
        ...fgDivisions,
        ...dbCatDivisions,
        ...matDivisions,
      ]),
    ]
      .filter((d) => Boolean(d) && String(d).trim().toUpperCase() !== "ALL")
      .sort();

    if (allowedDivisions && allowedDivisions.length > 0) {
      return allExtracted.filter((d) => isDivisionAllowed(d, allowedDivisions));
    }
    return allExtracted;
  }, [divisions, fgCatalogItems, categoriesFromDb, materials, allowedDivisions]);

  // Extract category names strictly for Finished Goods (material_type IN ('FG', 'ALL'), excluding 'Raw Material')
  const fgCategories = useMemo(() => {
    const list = [];
    (categoriesFromDb || []).forEach((c) => {
      if (typeof c === "string") {
        const trimmed = c.trim();
        if (trimmed && trimmed.toLowerCase() !== "raw material")
          list.push(trimmed);
      } else if (c && typeof c === "object") {
        const name = (c.name || "").trim();
        const matType = String(
          c.material_type || c.materialType || "ALL",
        ).toUpperCase();
        const division = (c.division || "").trim();
        if (
          name &&
          name.toLowerCase() !== "raw material" &&
          (matType === "FG" || matType === "ALL") &&
          (!firmFilter ||
            !division ||
            division.toLowerCase() === firmFilter.toLowerCase())
        ) {
          list.push(name);
        }
      }
    });
    fgCatalogItems.forEach((f) => {
      if (
        f.category &&
        f.category.trim() &&
        f.category.toLowerCase() !== "raw material" &&
        (!firmFilter ||
          !f.division ||
          f.division.toLowerCase() === firmFilter.toLowerCase())
      ) {
        list.push(f.category.trim());
      }
    });
    materials.forEach((m) => {
      const matType = (m.materialType || m.material_type || "").toUpperCase();
      if (
        matType !== "RM" &&
        m.category &&
        m.category.trim() &&
        m.category.toLowerCase() !== "raw material" &&
        (!firmFilter ||
          !m.division ||
          m.division.toLowerCase() === firmFilter.toLowerCase())
      ) {
        list.push(m.category.trim());
      }
    });
    return [...new Set(list)].filter(Boolean).sort();
  }, [categoriesFromDb, fgCatalogItems, materials, firmFilter]);

  // Extract category names strictly for Raw Materials (material_type IN ('RM', 'ALL') or matching 'RAW MATERIAL')
  const rmCategories = useMemo(() => {
    const map = new Map(); // lowercase -> preferred name

    // 1. First priority: categories from DB (Settings configured by user)
    (categoriesFromDb || []).forEach((c) => {
      const name = typeof c === "string" ? c.trim() : (c?.name || "").trim();
      const matType = typeof c === "object" ? String(c?.material_type || c?.materialType || "").toUpperCase() : "";
      const division = typeof c === "object" ? (c?.division || "").trim() : "";
      if (
        name &&
        (matType === "RM" || (matType === "ALL" && name.toLowerCase() === "raw material") || name.toLowerCase() === "raw material") &&
        (!firmFilter || !division || division.toLowerCase() === firmFilter.toLowerCase())
      ) {
        const key = name.toLowerCase();
        if (!map.has(key)) map.set(key, name);
      }
    });

    // 2. Second priority: materials from stock master
    materials.forEach((m) => {
      const matType = (m.materialType || m.material_type || "RM").toUpperCase();
      const cat = (m.category || "").trim();
      if (
        cat &&
        (matType === "RM" || cat.toLowerCase() === "raw material") &&
        (!firmFilter || !m.division || m.division.toLowerCase() === firmFilter.toLowerCase())
      ) {
        const key = cat.toLowerCase();
        if (!map.has(key)) map.set(key, cat);
      }
    });

    // 3. Fallback: rmCatalogItems
    (rmCatalogItems || []).forEach((r) => {
      const cat = (r.category || "").trim();
      if (
        cat &&
        (!firmFilter || !r.division || r.division.toLowerCase() === firmFilter.toLowerCase())
      ) {
        const key = cat.toLowerCase();
        if (!map.has(key)) map.set(key, cat);
      }
    });

    const unique = Array.from(map.values()).sort();
    return unique.length > 0 ? unique : ["RAW MATERIAL"];
  }, [categoriesFromDb, materials, rmCatalogItems, firmFilter]);

  // Combined Categories dropdown options based on Material Type and Firm filter
  const categories = useMemo(() => {
    let list = [];
    if (materialTypeFilter === "RM") {
      list = rmCategories;
    } else if (materialTypeFilter === "FG") {
      list = fgCategories;
    } else {
      list = [...rmCategories, ...fgCategories];
    }

    // Case-insensitive deduplication across all categories
    const map = new Map();
    list.forEach((item) => {
      const key = item.toLowerCase().trim();
      if (!map.has(key)) {
        map.set(key, item);
      }
    });
    return Array.from(map.values());
  }, [materialTypeFilter, rmCategories, fgCategories]);

  // Auto-reset category if no longer valid under active filters
  useEffect(() => {
    if (
      category &&
      !categories.some(
        (c) => c.toLowerCase().trim() === category.toLowerCase().trim(),
      )
    ) {
      setCategory("");
    }
  }, [categories, category]);

  // Extract all products from inventory_master_material table, catalogs, and inventory_materials
  const uniqueMaterialNames = useMemo(() => {
    const combinedMap = new Map();
    const defaultRmCat = rmCategories[0] || "RAW MATERIAL";

    // 1. Add directly from Master Materials (strictly from inventory_master_material table)
    (masterMaterials || []).forEach((item) => {
      const sku = (item.sku || "").trim();
      const name = (item.name || "").trim();
      if (!sku && !name) return;

      const key = sku
        ? `sku:${sku.toLowerCase()}`
        : `name:${name.toLowerCase()}`;
      combinedMap.set(key, {
        id: item.id,
        sku: sku || "",
        name: name || sku,
        category: item.category || (item.materialType === "RM" ? defaultRmCat : "Finished Goods"),
        subCategory: item.subCategory || item.sub_category || "",
        materialType: (item.materialType || item.material_type || "RM").toUpperCase(),
        division: item.division || "",
      });
    });

    // 2. Add from Raw Material Catalog fallback
    (rmCatalogItems || []).forEach((rm) => {
      const sku = (rm.sku || "").trim();
      const name = (rm.name || "").trim();
      if (!sku && !name) return;

      const key = sku
        ? `sku:${sku.toLowerCase()}`
        : `name:${name.toLowerCase()}`;
      if (!combinedMap.has(key)) {
        combinedMap.set(key, {
          sku: sku || "",
          name: name || sku,
          category: rm.category || defaultRmCat,
          materialType: "RM",
          division: rm.division || "",
        });
      }
    });

    // 3. Add from Finished Goods Catalog fallback
    (fgCatalogItems || []).forEach((fg) => {
      const sku = (fg.sku || "").trim();
      const name = (fg.name || "").trim();
      if (!sku && !name) return;

      const key = sku
        ? `sku:${sku.toLowerCase()}`
        : `name:${name.toLowerCase()}`;
      if (!combinedMap.has(key)) {
        combinedMap.set(key, {
          sku: sku || "",
          name: name || sku,
          category: fg.category || "Finished Goods",
          materialType: "FG",
          division: fg.division || "",
        });
      }
    });

    // 4. Add from existing inventory_materials
    materials.forEach((m) => {
      const sku = (m.sku || "").trim();
      const name = (m.name || "").trim();
      if (!sku && !name) return;

      const key = sku
        ? `sku:${sku.toLowerCase()}`
        : `name:${name.toLowerCase()}`;
      const existing = combinedMap.get(key);
      const isFG =
        m.materialType === "FG" ||
        m.material_type === "FG" ||
        (m.category && m.category.toLowerCase().trim() !== "raw material");

      combinedMap.set(key, {
        sku: sku || existing?.sku || "",
        name: name || existing?.name || sku || "",
        category:
          m.category ||
          existing?.category ||
          (isFG ? "Finished Goods" : defaultRmCat),
        materialType: isFG ? "FG" : "RM",
        division: m.division || existing?.division || "",
      });
    });

    // 5. Add from approved internal transfers
    (allTransfers || [])
      .filter((t) => t.status === "Approved")
      .forEach((trf) => {
        const sku = (trf.skuCode || "").trim();
        const name = (trf.skuName || "").trim();
        if (!sku && !name) return;

        const key = sku
          ? `sku:${sku.toLowerCase()}`
          : `name:${name.toLowerCase()}`;
        const existing = combinedMap.get(key);
        if (!existing) {
          combinedMap.set(key, {
            sku: sku || "",
            name: name || sku,
            category: defaultRmCat,
            materialType: "RM",
            division: trf.toDivision || trf.fromDivision || "",
          });
        }
      });

    // Determine which items exist in inventory_materials or approved transfers
    const masterNamesSet = new Set(
      materials.map((m) => (m.name || "").toLowerCase().trim()).filter(Boolean),
    );
    const masterSkuSet = new Set(
      materials.map((m) => (m.sku || "").toLowerCase().trim()).filter(Boolean),
    );
    const approvedTransferSkus = new Set(
      (allTransfers || [])
        .filter((t) => t.status === "Approved")
        .map((t) => (t.skuCode || "").toLowerCase().trim())
        .filter(Boolean),
    );
    const approvedTransferNames = new Set(
      (allTransfers || [])
        .filter((t) => t.status === "Approved")
        .map((t) => (t.skuName || "").toLowerCase().trim())
        .filter(Boolean),
    );

    let allItems = Array.from(combinedMap.values()).map((item) => {
      const itemSkuLower = (item.sku || "").toLowerCase().trim();
      const itemNameLower = (item.name || "").toLowerCase().trim();
      const isInMaster =
        (itemSkuLower && masterSkuSet.has(itemSkuLower)) ||
        (itemNameLower && masterNamesSet.has(itemNameLower)) ||
        (itemSkuLower && approvedTransferSkus.has(itemSkuLower)) ||
        (itemNameLower && approvedTransferNames.has(itemNameLower));
      return {
        ...item,
        isMissingOpening: !isInMaster,
      };
    });

    // Apply active filter criteria:
    if (materialTypeFilter) {
      allItems = allItems.filter(
        (item) => item.materialType === materialTypeFilter,
      );
    }
    if (category) {
      const catLower = category.toLowerCase().trim();
      allItems = allItems.filter((item) => {
        const itemCat = (item.category || "").toLowerCase().trim();
        return (
          itemCat === catLower ||
          (catLower === "raw material" &&
            (item.materialType === "RM" || itemCat === "raw material"))
        );
      });
    }
    if (firmFilter) {
      const ffLower = firmFilter.toLowerCase().trim();
      allItems = allItems.filter(
        (item) =>
          !item.division ||
          item.division.toLowerCase().trim() === ffLower ||
          materials.some(
            (m) =>
              ((m.sku &&
                item.sku &&
                m.sku.toLowerCase().trim() === item.sku.toLowerCase().trim()) ||
                (m.name &&
                  item.name &&
                  m.name.toLowerCase().trim() ===
                  item.name.toLowerCase().trim())) &&
              m.division &&
              m.division.toLowerCase().trim() === ffLower,
          ) ||
          (allTransfers || []).some(
            (trf) =>
              trf.status === "Approved" &&
              ((trf.skuCode &&
                item.sku &&
                trf.skuCode.toLowerCase().trim() ===
                item.sku.toLowerCase().trim()) ||
                (trf.skuName &&
                  item.name &&
                  trf.skuName.toLowerCase().trim() ===
                  item.name.toLowerCase().trim())) &&
              ((trf.fromDivision &&
                trf.fromDivision.toLowerCase().trim() === ffLower) ||
                (trf.toDivision &&
                  trf.toDivision.toLowerCase().trim() === ffLower)),
          ),
      );
    }

    return allItems.sort((a, b) => {
      const keyA = a.sku || a.name || "";
      const keyB = b.sku || b.name || "";
      return keyA.localeCompare(keyB, undefined, {
        numeric: true,
        sensitivity: "base",
      });
    });
  }, [
    masterMaterials,
    rmCatalogItems,
    fgCatalogItems,
    materials,
    allTransfers,
    materialTypeFilter,
    category,
    firmFilter,
    rmCategories,
  ]);

  // Material Type Dropdown Options
  const materialTypeOptions = useMemo(
    () => [
      { value: "", label: "All Material Types" },
      { value: "RM", label: "Raw Material (RM)" },
      { value: "FG", label: "Finished Goods (FG)" },
    ],
    [],
  );

  // Firm Dropdown Options
  const firmOptions = useMemo(
    () => [
      { value: "", label: "All Firms" },
      ...firms.map((f) => ({ value: f, label: f })),
    ],
    [firms],
  );

  // Category Dropdown Options
  const categoryOptions = useMemo(
    () => [
      { value: "", label: "All Categories" },
      ...categories.map((c) => ({ value: c, label: c })),
    ],
    [categories],
  );

  // Sub Category Options (Lists out Material / Product Names)
  // - RM: Raw Material names
  // - FG: Finished Goods material names
  // Filtered by active Material Type, Firm, and Category
  const subCategoryOptions = useMemo(() => {
    const namesSet = new Set();
    (uniqueMaterialNames || []).forEach((item) => {
      const name = (item.name || item.subCategory || "").trim();
      if (name) {
        namesSet.add(name);
      }
    });

    const sortedNames = Array.from(namesSet).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }),
    );

    return [
      { value: "", label: "All Sub Categories" },
      ...sortedNames.map((name) => ({ value: name, label: name })),
    ];
  }, [uniqueMaterialNames]);

  // Auto-reset subCategoryFilter if no longer in subCategoryOptions
  useEffect(() => {
    if (
      subCategoryFilter &&
      !subCategoryOptions.some((opt) => opt.value === subCategoryFilter)
    ) {
      setSubCategoryFilter("");
    }
  }, [subCategoryOptions, subCategoryFilter]);

  // SKU Options (Lists out SKUs matching active parent filters + Sub Category)
  const skuOptions = useMemo(() => {
    let items = uniqueMaterialNames || [];
    if (subCategoryFilter) {
      const scLower = subCategoryFilter.toLowerCase().trim();
      items = items.filter((item) => {
        const name = (item.name || "").toLowerCase().trim();
        const subCat = (
          item.subCategory ||
          item.sub_category ||
          ""
        )
          .toLowerCase()
          .trim();
        return name === scLower || subCat === scLower;
      });
    }

    const skuMap = new Map();
    items.forEach((item) => {
      const sku = (item.sku || "").trim();
      if (sku && !skuMap.has(sku.toLowerCase())) {
        const itemName = (item.name || "").trim();
        skuMap.set(sku.toLowerCase(), {
          value: sku,
          label: sku,
          subLabel:
            itemName && itemName.toLowerCase() !== sku.toLowerCase()
              ? itemName
              : undefined,
        });
      }
    });

    const sortedSkus = Array.from(skuMap.values()).sort((a, b) =>
      a.label.localeCompare(b.label, undefined, {
        numeric: true,
        sensitivity: "base",
      }),
    );

    return [{ value: "", label: "All SKUs" }, ...sortedSkus];
  }, [uniqueMaterialNames, subCategoryFilter]);

  // Auto-reset skuFilter if no longer in skuOptions
  useEffect(() => {
    if (skuFilter && !skuOptions.some((opt) => opt.value === skuFilter)) {
      setSkuFilter("");
    }
  }, [skuOptions, skuFilter]);

  // Detect when the selected product / SKU has no opening stock / not in inventory_materials
  const selectedCatalogItem = useMemo(() => {
    const activeFilter = skuFilter || subCategoryFilter;
    if (!activeFilter) return null;
    const afLower = activeFilter.toLowerCase().trim();
    const existing = materials.find(
      (m) =>
        (m.name || "").toLowerCase().trim() === afLower ||
        (m.sku || "").toLowerCase().trim() === afLower,
    );
    if (existing) return null; // already initialized in inventory_materials!

    const foundInList = uniqueMaterialNames.find(
      (item) =>
        (item.name && item.name.toLowerCase().trim() === afLower) ||
        (item.sku && item.sku.toLowerCase().trim() === afLower),
    );
    if (foundInList) return foundInList;

    const inRm = rmCatalogItems.find(
      (r) =>
        (r.name && r.name.toLowerCase().trim() === afLower) ||
        (r.sku && r.sku.toLowerCase().trim() === afLower),
    );
    if (inRm) return { ...inRm, isMissingOpening: true };

    const inFg = fgCatalogItems.find(
      (f) =>
        (f.name && f.name.toLowerCase().trim() === afLower) ||
        (f.sku && f.sku.toLowerCase().trim() === afLower),
    );
    if (inFg) return { ...inFg, isMissingOpening: true };

    return {
      name: activeFilter,
      sku: activeFilter,
      category: materialTypeFilter === "RM" ? (rmCategories[0] || "RAW MATERIAL") : "Finished Goods",
      materialType: materialTypeFilter || "RM",
      subCategory: materialTypeFilter === "FG" ? activeFilter : "",
      division: firmFilter || "",
      isMissingOpening: true,
    };
  }, [
    skuFilter,
    subCategoryFilter,
    materials,
    uniqueMaterialNames,
    rmCatalogItems,
    fgCatalogItems,
    materialTypeFilter,
    firmFilter,
    rmCategories,
  ]);

  const handleCreateOpeningForCatalogItem = (catalogItem) => {
    if (!canWrite) return;
    if (!catalogItem) return;
    setModalMode("add");
    setFormId(null);
    const rawType = (
      catalogItem.materialType ||
      catalogItem.material_type ||
      ""
    ).toUpperCase().trim();
    const isFG = rawType === "FG";
    setFormMaterialType(isFG ? "FG" : "RM");
    setFormSku(catalogItem.sku || "");
    setFormCategory(isFG ? catalogItem.category || "" : catalogItem.name || "");
    setFormSubCategory(
      isFG ? catalogItem.name || catalogItem.subCategory || "" : "",
    );
    setFormExistingCategory(
      catalogItem.category || (isFG ? "Finished Goods" : (rmCategories[0] || "RAW MATERIAL")),
    );
    setFormUnit(units[0] || (isFG ? "NOS" : "KG"));
    setFormDivision(catalogItem.division || firmFilter || "");
    setFormLocation(locations[0]?.location || "");
    setFormOpening(0);
    setFormAdc(0);
    setFormLeadTime(0);
    setFormSafetyFactor(0);
    setFormMoq(0);
    setFormSupplierName("");
    setFormSupplierCode("");
    setFormStatus("Active");
    setFormMasterMaterialId(catalogItem.id || catalogItem.masterMaterialId || null);
    setIsModalOpen(true);
  };

  // Category dropdown values for FG in the modal:
  // Strictly fetched from inventory_master_material table matching material_type = 'FG' from the category column
  const modalFgCategories = useMemo(() => {
    const set = new Set();
    const sourceList =
      masterMaterials && masterMaterials.length > 0
        ? masterMaterials.filter(
          (m) => (m.materialType || m.material_type || "").toUpperCase() === "FG",
        )
        : finishedGoodsNames || [];

    sourceList.forEach((fg) => {
      const cat = typeof fg === "string" ? fg : (fg.category || "");
      const trimmed = (cat || "").trim();
      if (trimmed && trimmed.toLowerCase() !== "raw material") {
        set.add(trimmed);
      }
    });

    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [masterMaterials, finishedGoodsNames]);

  // Category suggestions based on Material Type:
  // - RM: Fetched strictly from master materials catalog (Material Names of RM type)
  // - FG: Fetched strictly from inventory_master_material table matching material_type = 'FG' category column
  const filteredCategorySuggestions = useMemo(() => {
    const search = (formCategory || "").toLowerCase().trim();
    if (formMaterialType === "RM") {
      const names = rmCatalogItems
        .map((i) =>
          typeof i.name === "string"
            ? i.name
            : i.name?.name
              ? String(i.name.name)
              : String(i.name || ""),
        )
        .filter(Boolean);
      const uniqueNames = [...new Set(names)];
      return uniqueNames.filter(
        (n) => typeof n === "string" && n.toLowerCase().includes(search),
      );
    }
    return modalFgCategories.filter(
      (c) => typeof c === "string" && c.toLowerCase().includes(search),
    );
  }, [formMaterialType, rmCatalogItems, modalFgCategories, formCategory]);

  // Sub Category suggestions based on Material Type:
  // - FG: Fetched from FG Material Names (filtered by category if selected)
  const filteredSubCategorySuggestions = useMemo(() => {
    const search = (formSubCategory || "").toLowerCase().trim();
    const selCat = (formCategory || "").toLowerCase().trim();
    const itemsToSearch = fgCatalogItems.filter((i) => {
      if (!selCat || selCat === "finished goods") return true;
      const itemCat = (i.category || "").toLowerCase().trim();
      return !itemCat || itemCat === selCat || itemCat === "finished goods";
    });
    const names = itemsToSearch
      .map((i) =>
        typeof i.name === "string"
          ? i.name
          : i.name?.name
            ? String(i.name.name)
            : String(i.name || ""),
      )
      .filter(Boolean);
    const uniqueNames = [...new Set(names)];
    return uniqueNames.filter(
      (n) => typeof n === "string" && n.toLowerCase().includes(search),
    );
  }, [fgCatalogItems, formCategory, formSubCategory]);

  // Combined SKU Suggestions object list
  const skuSuggestions = useMemo(() => {
    const list = [];
    const targetCatalog =
      formMaterialType === "RM" ? rmCatalogItems : fgCatalogItems;
    targetCatalog.forEach((item) => {
      const rawSku =
        typeof item.sku === "string"
          ? item.sku
          : item.sku?.sku
            ? item.sku.sku
            : item.sku
              ? String(item.sku)
              : "";
      const rawName =
        typeof item.name === "string"
          ? item.name
          : item.name?.name
            ? item.name.name
            : item.name
              ? String(item.name)
              : "";
      const sku = rawSku.trim();
      const name = rawName.trim();
      if (sku && !list.some((l) => l.sku.toLowerCase() === sku.toLowerCase())) {
        list.push({ ...item, sku, name });
      }
    });
    materials.forEach((m) => {
      if (
        formMaterialType === "RM"
          ? m.materialType !== "FG"
          : m.materialType === "FG"
      ) {
        const rawSku =
          typeof m.sku === "string"
            ? m.sku
            : m.sku?.sku
              ? m.sku.sku
              : m.sku
                ? String(m.sku)
                : "";
        const rawName =
          typeof m.name === "string"
            ? m.name
            : m.name?.name
              ? m.name.name
              : m.name
                ? String(m.name)
                : "";
        const sku = rawSku.trim();
        const name = rawName.trim();
        if (
          sku &&
          !list.some((l) => l.sku.toLowerCase() === sku.toLowerCase())
        ) {
          list.push({ ...m, sku, name });
        }
      }
    });
    return list;
  }, [formMaterialType, rmCatalogItems, fgCatalogItems, materials]);

  const filteredSkuSuggestions = useMemo(() => {
    const search = (formSku || "").toLowerCase().trim();
    return skuSuggestions.filter((s) => {
      const skuStr = typeof s.sku === "string" ? s.sku : String(s.sku || "");
      const nameStr =
        typeof s.name === "string" ? s.name : String(s.name || "");
      return (
        skuStr.toLowerCase().includes(search) ||
        nameStr.toLowerCase().includes(search)
      );
    });
  }, [skuSuggestions, formSku]);

  // Material Movement Report Calculations
  const reportRows = useMemo(() => {
    const latestTxnDateMap = {};
    const countsMap = {};

    (transactions || []).forEach((t) => {
      if (!t.sku) return;
      const skuKey = t.sku;

      const rawDate = (
        typeof t.date === "string" ? t.date : t.created_at || ""
      ).trim();
      const txnDate = rawDate.includes("T")
        ? rawDate.slice(0, 10)
        : rawDate.slice(0, 10);

      // Always track the latest transaction date of each material
      if (
        txnDate &&
        (!latestTxnDateMap[skuKey] || txnDate > latestTxnDateMap[skuKey])
      ) {
        latestTxnDateMap[skuKey] = txnDate;
      }

      // Filter for movement counts based on selected date range
      if (reportFromDate && (!txnDate || txnDate < reportFromDate)) return;
      if (reportToDate && (!txnDate || txnDate > reportToDate)) return;

      if (!countsMap[skuKey]) {
        countsMap[skuKey] = { in: 0, out: 0, jobCard: 0 };
      }
      const type = (t.type || "").trim();
      if (type === "IN") {
        countsMap[skuKey].in += 1;
      } else if (type === "OUT") {
        countsMap[skuKey].out += 1;
      } else if (type === "Job Card" || type === "JOB CARD") {
        countsMap[skuKey].jobCard += 1;
      }
    });

    const finishedGoodsSet = new Set(
      (finishedGoodsNames || []).map((fg) =>
        (typeof fg === "string" ? fg : fg.sku || fg.name || "").toLowerCase(),
      ),
    );

    return (materials || []).map((m) => {
      const counts = countsMap[m.sku] || { in: 0, out: 0, jobCard: 0 };
      const latestTxnDate = latestTxnDateMap[m.sku] || "—";

      const isFinishedGood =
        m.materialType === "FG" ||
        m.material_type === "FG" ||
        finishedGoodsSet.has((m.sku || "").toLowerCase()) ||
        finishedGoodsSet.has((m.name || "").toLowerCase()) ||
        finishedGoodsSet.has((m.subCategory || "").toLowerCase());

      const displayType = isFinishedGood ? "Finished Goods" : "Raw Material";

      return {
        sku: m.sku,
        name: m.name,
        type: displayType,
        rawType: isFinishedGood ? "FG" : "RM",
        txnDate: latestTxnDate,
        inCount: counts.in,
        outCount: counts.out,
        jobCardCount: counts.jobCard,
        totalTxns: counts.in + counts.out + counts.jobCard,
      };
    });
  }, [
    materials,
    transactions,
    finishedGoodsNames,
    reportFromDate,
    reportToDate,
  ]);

  const filteredReportRows = useMemo(() => {
    let rows = reportRows;
    if (reportSearch.trim()) {
      const q = reportSearch.toLowerCase().trim();
      rows = rows.filter(
        (r) =>
          r.sku.toLowerCase().includes(q) || r.name.toLowerCase().includes(q),
      );
    }
    if (reportTypeFilter) {
      rows = rows.filter((r) => r.rawType === reportTypeFilter);
    }
    return rows;
  }, [reportRows, reportSearch, reportTypeFilter]);

  // Batch Detail: opens the generated PDF directly in a new tab with live opening > 0 data
  const handleBatchDetailPdf = () => {
    try {
      openBatchDetailPdfInNewTab(materials, { date: new Date() });
    } catch (err) {
      console.error("Batch detail PDF generation failed:", err);
      showToast("Failed to generate Batch Detail PDF", "error");
    }
  };

  const handleExportReportCSV = () => {
    const exportData = filteredReportRows.map((r) => ({
      "SKU Code": r.sku,
      "Material Name": r.name,
      Type: r.type,
      "Transaction Date": r.txnDate,
      "IN Transactions": r.inCount,
      "OUT Transactions": r.outCount,
      "Job Card Transactions": r.jobCardCount,
    }));
    const csv = Papa.unparse(exportData);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const dateSuffix =
      reportFromDate && reportToDate
        ? `_${reportFromDate}_to_${reportToDate}`
        : reportFromDate
          ? `_from_${reportFromDate}`
          : reportToDate
            ? `_to_${reportToDate}`
            : `_${new Date().toISOString().slice(0, 10)}`;
    link.setAttribute(
      "download",
      `IMS_Material_Movement_Report${dateSuffix}.csv`,
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Derived stock table calculations
  const tableRows = useMemo(() => {
    const rawAccessible = (allowedDivisions && allowedDivisions.length > 0)
      ? materials.filter((m) => isDivisionAllowed(m.division, allowedDivisions))
      : materials;

    // Deduplicate by (sku, division) — keep first occurrence
    const seenSkuDiv = new Set();
    const accessibleMaterials = rawAccessible.filter((m) => {
      const k = `${m.sku}__${m.division || ""}`;
      if (seenSkuDiv.has(k)) return false;
      seenSkuDiv.add(k);
      return true;
    });

    // ─── Step 1: Build per-(SKU, division) transaction totals ───────────────────
    const txnBySkuDiv = {};
    accessibleMaterials.forEach((m) => {
      const key = `${m.sku}__${m.division || ""}`;
      txnBySkuDiv[key] = { totalIn: 0, totalOut: 0 };
    });

    transactions.forEach((t) => {
      const qty = Number(t.qty) || 0;
      const key = `${t.sku}__${t.firm || ""}`;
      if (!txnBySkuDiv[key]) {
        txnBySkuDiv[key] = { totalIn: 0, totalOut: 0 };
      }
      if (t.type === "IN" || t.type === "Job Card") {
        txnBySkuDiv[key].totalIn += qty;
      } else {
        txnBySkuDiv[key].totalOut += qty;
      }
    });

    // ─── Step 2: Set of SKUs with approved indents ───────────────────────────
    const approvedIndentSkus = new Set(
      (indents || [])
        .filter((i) => (i.status || "").toLowerCase() === "approved")
        .map((i) => (i.sku || "").toLowerCase()),
    );

    // ─── Step 2b: Filter completed recycle records ───────────────────────────
    const completedRecycles = (recycles || []).filter(
      (r) => (r.status || "").toLowerCase() === "completed",
    );

    // ─── Step 3: Map material rows directly ─────────────────────────────────
    const rows = accessibleMaterials.map((m) => {
      const key = `${m.sku}__${m.division || ""}`;
      const skuTxn = txnBySkuDiv[key] || { totalIn: 0, totalOut: 0 };

      const mDiv = (m.division || "").trim().toLowerCase();
      const mSku = (m.sku || "").trim().toLowerCase();
      const mName = (m.name || "").trim().toLowerCase();

      // Match transfer by sku code OR by material name (transfers may store name in sku_code field)
      const matchesSkuOrName = (t) => {
        const tSku = (t.skuCode || "").trim().toLowerCase();
        return tSku === mSku || tSku === mName;
      };

      // Transfer IN for this material row (sum of approved transfers to this division & SKU)
      const transferInQty = (allTransfers || [])
        .filter(
          (t) =>
            t.status === "Approved" &&
            matchesSkuOrName(t) &&
            (t.toDivision || "").trim().toLowerCase() === mDiv,
        )
        .reduce((sum, t) => sum + (Number(t.quantity) || 0), 0);

      // Transfer OUT for this material row (sum of approved transfers from this division & SKU)
      const transferOutQty = (allTransfers || [])
        .filter(
          (t) =>
            t.status === "Approved" &&
            matchesSkuOrName(t) &&
            (t.fromDivision || "").trim().toLowerCase() === mDiv,
        )
        .reduce((sum, t) => sum + (Number(t.quantity) || 0), 0);

      // Calculate net recycle impact:
      // - Regular materials (RM & FG): direct rejection quantity decreases closing stock
      // - Scrap materials: direct rejection quantity + matching FG rejection weight increases closing stock
      const {
        directRecycleQty,
        fgScrapWeightAdded,
        netRecycleQty,
        isScrap,
      } = calculateMaterialRecycleImpact(m, completedRecycles, fgLookupMap);

      const openingStock = Number(m.opening) || 0;
      const totalIn = skuTxn.totalIn + transferInQty;
      const totalOut = skuTxn.totalOut + transferOutQty;
      const closingStock = isScrap
        ? openingStock + (totalIn - totalOut) + directRecycleQty + fgScrapWeightAdded
        : openingStock + (totalIn - totalOut) - directRecycleQty;

      const recycleQty = netRecycleQty;

      const safetyStock = (Number(m.adc) || 0) * (Number(m.safetyFactor) || 0);
      const reorderLevel =
        (Number(m.adc) || 0) * (Number(m.leadTime) || 0) + safetyStock;
      const maxLevel = reorderLevel + (Number(m.moq) || 0);

      let bandName = "Normal Stock";
      if (maxLevel > 0) {
        const pct = (closingStock / maxLevel) * 100;
        if (pct > 100) bandName = "Excess Stock";
        else if (pct >= 66.33) bandName = "Normal Stock";
        else if (pct >= 33) bandName = "66.33% Stock";
        else bandName = "Below 33%";
      }

      const isTransferReceived = Boolean(
        m.transferred_division || m.transferredDivision,
      );
      const isTransferSent = transferOutQty > 0;

      // Match latest physical stock count for this SKU and division
      const matchedPhysical = (physicalStocks || [])
        .filter((p) => {
          const skuMatch =
            (p.sku || "").trim().toLowerCase() ===
            (m.sku || "").trim().toLowerCase();
          const divMatch =
            !p.division ||
            p.division === "ALL" ||
            !m.division ||
            m.division === "ALL" ||
            p.division === m.division;
          return skuMatch && divMatch;
        })
        .sort(
          (a, b) =>
            new Date(b.countedDate || b.createdAt || 0) -
            new Date(a.countedDate || a.createdAt || 0),
        )[0] || null;

      const latestPhysicalStock = matchedPhysical
        ? Number(matchedPhysical.physicalQty)
        : null;
      const physicalStockStatus = matchedPhysical
        ? matchedPhysical.status
        : null;
      const physicalStockVariance = matchedPhysical
        ? Number(matchedPhysical.differenceQty)
        : null;

      return {
        ...m,
        materialType: (m.materialType || m.material_type || "RM").toUpperCase(),
        recycleQty,
        directRecycleQty,
        fgScrapWeightAdded,
        isScrapMaterial: isScrap,
        closingStock,
        latestPhysicalStock,
        physicalStockStatus,
        physicalStockVariance,
        physicalStockRecord: matchedPhysical,
        safetyStock,
        reorderLevel,
        maxLevel,
        totalIn,
        totalOut,
        transferInQty,
        transferOutQty,
        band: bandName,
        hasApprovedIndent: approvedIndentSkus.has((m.sku || "").toLowerCase()),
        isTransferReceived,
        isTransferSent,
        isTransferRow: isTransferReceived || isTransferSent,
      };
    });

    return rows;
  }, [materials, transactions, indents, allTransfers, physicalStocks, recycles, fgLookupMap, allowedDivisions]);

  // Filtered rows
  const filteredRows = useMemo(() => {
    let rows = activeUser.location
      ? tableRows.filter((m) => m.location === activeUser.location)
      : tableRows;

    if (allowedDivisions && allowedDivisions.length > 0) {
      rows = rows.filter((r) => isDivisionAllowed(r.division, allowedDivisions));
    }

    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.sku.toLowerCase().includes(q) || r.name.toLowerCase().includes(q),
      );
    }
    if (materialTypeFilter) {
      rows = rows.filter(
        (r) =>
          (r.materialType || r.material_type || "RM").toUpperCase() ===
          materialTypeFilter,
      );
    }
    if (firmFilter) {
      rows = rows.filter((r) => r.division === firmFilter);
    }
    if (category) {
      const catLower = category.toLowerCase().trim();
      rows = rows.filter((r) => {
        const rCat = (r.category || "").toLowerCase().trim();
        const rType = (r.materialType || r.material_type || "RM").toUpperCase();
        return (
          rCat === catLower ||
          (catLower === "raw material" && (rType === "RM" || rCat === "raw material"))
        );
      });
    }
    if (subCategoryFilter) {
      const scLower = subCategoryFilter.toLowerCase().trim();
      rows = rows.filter((r) => {
        const rName = (r.name || "").toLowerCase().trim();
        const rSub = (r.subCategory || r.sub_category || "").toLowerCase().trim();
        return rName === scLower || rSub === scLower;
      });
    }
    if (skuFilter) {
      const skuLower = skuFilter.toLowerCase().trim();
      rows = rows.filter(
        (r) => (r.sku || "").toLowerCase().trim() === skuLower,
      );
    }
    if (band) {
      rows = rows.filter((r) => r.band === band);
    }
    // Sort
    return rows.sort((a, b) => {
      let va = a[sortKey],
        vb = b[sortKey];
      if (typeof va === "string") va = va.toLowerCase();
      if (typeof vb === "string") vb = vb.toLowerCase();
      if (va < vb) return -1 * sortDir;
      if (va > vb) return 1 * sortDir;
      return 0;
    });
  }, [
    tableRows,
    search,
    materialTypeFilter,
    firmFilter,
    category,
    subCategoryFilter,
    skuFilter,
    band,
    sortKey,
    sortDir,
    activeUser,
  ]);

  // Pagination details
  const pageSize = settings?.pageSize?.stock || 6;
  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRows.slice(start, start + pageSize);
  }, [filteredRows, currentPage, pageSize]);

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    dispatch(
      saveSettings({
        settings: {
          ...settings,
          pageSize: {
            ...settings?.pageSize,
            stock: newSize,
          },
        },
        currentUser: activeUser.name,
      }),
    );
    setCurrentPage(1);
  };

  // Handle Sort
  const requestSort = (key) => {
    if (sortKey === key) {
      setSortDir((prev) => -prev);
    } else {
      setSortKey(key);
      setSortDir(1);
    }
    setCurrentPage(1);
  };

  // Export CSV
  const handleExport = () => {
    const exportData = filteredRows.map((r) => ({
      "SKU Code": r.sku,
      "Material Name": r.name,
      Category: r.category,
      "Sub Category": r.subCategory || "",
      Unit: r.unit || "",
      Firm: r.division || "",
      "Storage Location": r.location || "",
      "Opening Stock": r.opening || 0,
      "Average Daily Consumption (ADC)": r.adc || 0,
      "Lead Time (Days)": r.leadTime || 0,
      "Safety Factor": r.safetyFactor || 0,
      "Safety Stock": r.safetyStock || 0,
      "Reorder Level": r.reorderLevel || 0,
      MOQ: r.moq || 0,
      "Max Level": r.maxLevel || 0,
      "Supplier Name": r.supplierName || "",
      "Supplier Code": r.supplierCode || "",
      "Material Status": r.status || "Active",
      "Total IN": r.totalIn || 0,
      "Total OUT": r.totalOut || 0,
      "Rejected Qty": r.recycleQty || 0,
      "Closing Stock": r.closingStock || 0,
      "Physical Stock":
        r.latestPhysicalStock !== null ? r.latestPhysicalStock : 0,
      "Physical Status": r.physicalStockStatus || "-",
      Variance:
        r.physicalStockVariance !== null ? r.physicalStockVariance : "-",
      "Stock Band": r.band || "",
    }));

    const csv = Papa.unparse(exportData);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `Stock_Report_${new Date().toISOString().slice(0, 10)}.csv`,
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // ─── CSV Template & Import Handlers for Add Material Modal ───────────────────
  const downloadSampleCSV = (filename, content) => {
    const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadModalTemplate = (materialType) => {
    const div1 = divisions[0]?.name || divisions[0] || "Nutech Composites";
    const div2 = divisions[1]?.name || divisions[1] || "NuTech Pipes";
    if (materialType === "FG") {
      const cat1 =
        categoriesFromDb[0]?.name || categoriesFromDb[0] || "Door frames";
      const cat2 =
        categoriesFromDb[1]?.name || categoriesFromDb[1] || "Panels";
      const sample = `Firm / Division,Category,Sub Category,SKU Code,Unit,Storage Location,Opening Stock Balance,Avg Daily Consumption (ADC),Lead Time (Days),Safety Factor,MOQ,Supplier Name,Supplier Code,Status\n${div1},${cat1},PVC Door Frame 3x2,FG-001,PCS,Sector 1,50,5,3,1.2,10,Internal Production,SUP-000,Active\n${div2},${cat2},Fluted Panel 9 Step,FG-002,PCS,Sector 3,30,3,4,1.0,15,Internal Production,SUP-000,Active\n${div1},Louvers,PVC Louvers 23mm,FG-003,PCS,Sector 4,20,2,5,1.5,10,Internal Production,SUP-000,Active\n`;
      downloadSampleCSV("sample_finished_goods_template.csv", sample);
    } else {
      const sample = `Firm / Division,Material Name,SKU Code,Unit,Storage Location,Opening Stock Balance,Avg Daily Consumption (ADC),Lead Time (Days),Safety Factor,MOQ,Supplier Name,Supplier Code,Status\n${div1},PVC Resin - Grade A,RM-001,KGS,Sector 5,100,10,7,1.5,50,Tata Steel Ltd.,SUP-001,Active\n${div2},Calcium Carbonate,RM-002,KGS,Sector 2,50,5,5,1.2,25,Supreme Polymers,SUP-002,Active\n${div1},Titanium Dioxide,RM-003,KGS,Sector 1,25,2,10,1.0,10,Reliable Chemicals,SUP-003,Active\n`;
      downloadSampleCSV("sample_raw_materials_template.csv", sample);
    }
  };

  const handleImportFile = (e, materialType) => {
    if (!canWrite) return;
    const file = e.target.files?.[0];
    if (!file) return;
    const inputEvent = e;

    Papa.parse(file, {
      header: false,
      skipEmptyLines: "greedy",
      complete: (results) => {
        try {
          if (!results.data || results.data.length === 0) {
            showToast("CSV file is empty or has no valid rows.", "error");
            e.target.value = "";
            return;
          }

          const validRows = [];
          const skippedRows = [];
          const isFG = materialType === "FG";
          let headerMap = null;

          results.data.forEach((rowParts, idx) => {
            const lineNum = idx + 1;
            const parts = Array.isArray(rowParts)
              ? rowParts.map((p) =>
                String(p ?? "")
                  .trim()
                  .replace(/^["']|["']$/g, ""),
              )
              : [];

            // Ignore completely empty rows
            if (!parts || parts.every((p) => !p)) return;

            // Header row detection
            if (idx === 0) {
              const joined = parts.join(" ").toLowerCase();
              const hasHeaderKeyword =
                joined.includes("sku") ||
                joined.includes("name") ||
                joined.includes("category") ||
                joined.includes("firm") ||
                joined.includes("division") ||
                joined.includes("unit") ||
                joined.includes("adc") ||
                joined.includes("consumption") ||
                joined.includes("lead") ||
                joined.includes("opening");

              if (hasHeaderKeyword) {
                headerMap = {};
                parts.forEach((colName, cIdx) => {
                  const norm = colName.toLowerCase().replace(/[^a-z0-9]/g, "");
                  if (
                    norm.includes("firm") ||
                    norm.includes("division") ||
                    norm.includes("company")
                  ) {
                    headerMap.division = cIdx;
                  } else if (
                    norm.includes("subcategory") ||
                    norm.includes("subcat")
                  ) {
                    headerMap.subCategory = cIdx;
                  } else if (
                    norm.includes("materialname") ||
                    norm.includes("rawmaterial") ||
                    (norm.includes("material") &&
                      !norm.includes("type") &&
                      !norm.includes("status")) ||
                    norm.includes("fgname") ||
                    norm.includes("finishedgoodsname") ||
                    norm === "name" ||
                    norm.includes("itemname")
                  ) {
                    headerMap.name = cIdx;
                  } else if (norm.includes("category") || norm === "cat") {
                    headerMap.category = cIdx;
                  } else if (
                    norm.includes("sku") ||
                    norm.includes("skucode") ||
                    norm.includes("itemcode")
                  ) {
                    headerMap.sku = cIdx;
                  } else if (norm.includes("unit") || norm.includes("uom")) {
                    headerMap.unit = cIdx;
                  } else if (
                    norm.includes("location") ||
                    norm.includes("storage")
                  ) {
                    headerMap.location = cIdx;
                  } else if (
                    norm.includes("opening") ||
                    norm.includes("balance") ||
                    norm.includes("initial")
                  ) {
                    headerMap.opening = cIdx;
                  } else if (
                    norm.includes("adc") ||
                    norm.includes("dailyconsumption") ||
                    norm.includes("consumption")
                  ) {
                    headerMap.adc = cIdx;
                  } else if (
                    norm.includes("leadtime") ||
                    norm.includes("lead") ||
                    norm.includes("days")
                  ) {
                    headerMap.leadTime = cIdx;
                  } else if (
                    norm.includes("safety") ||
                    norm.includes("safetyfactor") ||
                    norm === "sf"
                  ) {
                    headerMap.safetyFactor = cIdx;
                  } else if (
                    norm.includes("moq") ||
                    norm.includes("minorder") ||
                    norm.includes("minimumorder")
                  ) {
                    headerMap.moq = cIdx;
                  } else if (
                    norm.includes("suppliername") ||
                    norm.includes("vendorname") ||
                    norm === "supplier" ||
                    norm === "vendor"
                  ) {
                    headerMap.supplierName = cIdx;
                  } else if (
                    norm.includes("suppliercode") ||
                    norm.includes("vendorcode") ||
                    norm.includes("supcode")
                  ) {
                    headerMap.supplierCode = cIdx;
                  } else if (
                    norm.includes("status") ||
                    norm.includes("materialstatus") ||
                    norm.includes("state")
                  ) {
                    headerMap.status = cIdx;
                  } else if (norm.includes("hsn")) {
                    headerMap.hsn = cIdx;
                  }
                });
                return; // Skip header row
              }
            }

            let skuVal = "";
            let nameVal = "";
            let catVal = isFG ? "" : "RAW MATERIAL";
            let subCatVal = "";
            let divVal = "";
            let unitVal = "PCS";
            let locVal = "";
            let openingVal = 0;
            let adcVal = 0;
            let leadTimeVal = 0;
            let safetyFactorVal = 0;
            let moqVal = 0;
            let supplierNameVal = "";
            let supplierCodeVal = "";
            let statusVal = "Active";
            let hsnVal = "";

            if (headerMap) {
              if (headerMap.sku !== undefined) skuVal = parts[headerMap.sku] || "";
              if (headerMap.name !== undefined) nameVal = parts[headerMap.name] || "";
              if (headerMap.category !== undefined) catVal = parts[headerMap.category] || "";
              if (headerMap.subCategory !== undefined) subCatVal = parts[headerMap.subCategory] || "";
              if (headerMap.division !== undefined) divVal = parts[headerMap.division] || "";
              if (headerMap.unit !== undefined) unitVal = parts[headerMap.unit] || "PCS";
              if (headerMap.location !== undefined) locVal = parts[headerMap.location] || "";
              if (headerMap.opening !== undefined) openingVal = Number(parts[headerMap.opening]) || 0;
              if (headerMap.adc !== undefined) adcVal = Number(parts[headerMap.adc]) || 0;
              if (headerMap.leadTime !== undefined) leadTimeVal = Number(parts[headerMap.leadTime]) || 0;
              if (headerMap.safetyFactor !== undefined) safetyFactorVal = Number(parts[headerMap.safetyFactor]) || 0;
              if (headerMap.moq !== undefined) moqVal = Number(parts[headerMap.moq]) || 0;
              if (headerMap.supplierName !== undefined) supplierNameVal = parts[headerMap.supplierName] || "";
              if (headerMap.supplierCode !== undefined) supplierCodeVal = parts[headerMap.supplierCode] || "";
              if (headerMap.status !== undefined) statusVal = parts[headerMap.status] || "Active";
              if (headerMap.hsn !== undefined) hsnVal = parts[headerMap.hsn] || "";
            } else {
              // Positional fallback
              if (isFG) {
                if (parts.length >= 10) {
                  divVal = parts[0] || "";
                  catVal = parts[1] || "";
                  subCatVal = parts[2] || "";
                  skuVal = parts[3] || "";
                  unitVal = parts[4] || "PCS";
                  locVal = parts[5] || "";
                  openingVal = Number(parts[6]) || 0;
                  adcVal = Number(parts[7]) || 0;
                  leadTimeVal = Number(parts[8]) || 0;
                  safetyFactorVal = Number(parts[9]) || 0;
                  moqVal = Number(parts[10]) || 0;
                  supplierNameVal = parts[11] || "";
                  supplierCodeVal = parts[12] || "";
                  statusVal = parts[13] || "Active";
                } else if (parts.length >= 4) {
                  skuVal = parts[0] || "";
                  nameVal = parts[1] || "";
                  catVal = parts[2] || "Finished Goods";
                  divVal = parts[3] || "";
                  hsnVal = parts[4] || "";
                  subCatVal = nameVal;
                } else {
                  skuVal = parts[0] || "";
                  nameVal = parts[1] || "";
                  subCatVal = nameVal;
                }
              } else {
                if (parts.length >= 10) {
                  divVal = parts[0] || "";
                  nameVal = parts[1] || "";
                  skuVal = parts[2] || "";
                  unitVal = parts[3] || "PCS";
                  locVal = parts[4] || "";
                  openingVal = Number(parts[5]) || 0;
                  adcVal = Number(parts[6]) || 0;
                  leadTimeVal = Number(parts[7]) || 0;
                  safetyFactorVal = Number(parts[8]) || 0;
                  moqVal = Number(parts[9]) || 0;
                  supplierNameVal = parts[10] || "";
                  supplierCodeVal = parts[11] || "";
                  statusVal = parts[12] || "Active";
                } else if (parts.length >= 3) {
                  skuVal = parts[0] || "";
                  nameVal = parts[1] || "";
                  divVal = parts[2] || "";
                  hsnVal = parts[3] || "";
                } else {
                  skuVal = parts[0] || "";
                  nameVal = parts[1] || "";
                }
              }
            }

            if (isFG) {
              if (!subCatVal && nameVal) subCatVal = nameVal;
              if (!nameVal && subCatVal) nameVal = subCatVal;
              if (!catVal) catVal = "Finished Goods";
            }

            skuVal = skuVal.trim();
            nameVal = nameVal.trim();
            subCatVal = subCatVal.trim();
            catVal = catVal.trim();
            const normalizedDivision =
              divVal &&
                divVal.trim() &&
                divVal.toLowerCase() !== "universal" &&
                divVal.toLowerCase() !== "none" &&
                divVal.toLowerCase() !== "all"
                ? divVal.trim()
                : "";
            statusVal = statusVal.toLowerCase() === "inactive" ? "Inactive" : "Active";

            // Validation: Missing SKU
            if (!skuVal) {
              skippedRows.push({
                lineNum,
                sku: "—",
                name: isFG ? (subCatVal || nameVal || "—") : (nameVal || "—"),
                category: isFG ? catVal : "RAW MATERIAL",
                division: normalizedDivision || "Universal",
                unit: unitVal || "PCS",
                hsn: hsnVal || "—",
                reason: "Missing SKU Code",
              });
              return;
            }

            // Validation: Missing Name
            const effectiveName = isFG ? (subCatVal || nameVal) : nameVal;
            if (!effectiveName) {
              skippedRows.push({
                lineNum,
                sku: skuVal,
                name: "—",
                category: isFG ? catVal : "RAW MATERIAL",
                division: normalizedDivision || "Universal",
                unit: unitVal || "PCS",
                hsn: hsnVal || "—",
                reason: isFG
                  ? "Missing Finished Goods / Sub Category Name"
                  : "Missing Material Name",
              });
              return;
            }

            // 1. Check if item already exists in inventory_master_material
            const targetDiv = normalizedDivision.toLowerCase();
            const targetType = isFG ? "FG" : "RM";

            const existingInMasterBySku = masterMaterials.find((m) => {
              const mSku = (m.sku || "").trim().toLowerCase();
              const mDiv = (m.division || "").trim().toLowerCase();
              const mType = (m.materialType || m.material_type || "").toUpperCase();
              return (
                mSku === skuVal.toLowerCase() &&
                (!mType || mType === targetType) &&
                (!targetDiv || !mDiv || mDiv === targetDiv || mDiv === "all")
              );
            });

            const existingInMasterByName = masterMaterials.find((m) => {
              const mName = (m.name || m.subCategory || "").trim().toLowerCase();
              const mDiv = (m.division || "").trim().toLowerCase();
              const mType = (m.materialType || m.material_type || "").toUpperCase();
              return (
                mName === effectiveName.toLowerCase() &&
                (!mType || mType === targetType) &&
                (!targetDiv || !mDiv || mDiv === targetDiv || mDiv === "all")
              );
            });

            // 2. Check if item already exists in inventory_materials
            const existingInStockBySku = materials.find((m) => {
              const mSku = (m.sku || "").trim().toLowerCase();
              const mDiv = (m.division || "").trim().toLowerCase();
              const mType = (m.materialType || m.material_type || "").toUpperCase();
              return (
                mSku === skuVal.toLowerCase() &&
                (!mType || mType === targetType) &&
                (!targetDiv || !mDiv || mDiv === targetDiv || mDiv === "all")
              );
            });

            const existingInStockByName = materials.find((m) => {
              const mName = (m.name || "").trim().toLowerCase();
              const mDiv = (m.division || "").trim().toLowerCase();
              const mType = (m.materialType || m.material_type || "").toUpperCase();
              return (
                mName === effectiveName.toLowerCase() &&
                (!mType || mType === targetType) &&
                (!targetDiv || !mDiv || mDiv === targetDiv || mDiv === "all")
              );
            });

            const matchedExisting =
              existingInMasterBySku ||
              existingInStockBySku ||
              existingInMasterByName ||
              existingInStockByName;

            if (matchedExisting) {
              const isSkuMatch = !!(existingInMasterBySku || existingInStockBySku);
              const matchedDiv =
                matchedExisting.division && matchedExisting.division !== "ALL"
                  ? matchedExisting.division
                  : normalizedDivision || "Master Catalog";
              skippedRows.push({
                lineNum,
                sku: skuVal,
                name: effectiveName,
                category: isFG ? catVal : "RAW MATERIAL",
                division: normalizedDivision || "Universal",
                unit: unitVal || "PCS",
                hsn: hsnVal || "—",
                isExisting: true,
                reason: isSkuMatch
                  ? `Already exists in system: SKU "${skuVal}" is registered in ${matchedDiv}`
                  : `Already exists in system: Material "${effectiveName}" is registered in ${matchedDiv}`,
              });
              return;
            }

            // 3. Check duplicate in current batch
            const batchMatchSku = validRows.find((r) => {
              const rSku = (r.item.sku || "").trim().toLowerCase();
              const rDiv = (r.item.division || "").trim().toLowerCase();
              const sameSku = rSku === skuVal.toLowerCase();
              const sameDiv = !targetDiv || !rDiv || rDiv === targetDiv;
              return sameSku && sameDiv;
            });

            if (batchMatchSku) {
              skippedRows.push({
                lineNum,
                sku: skuVal,
                name: effectiveName,
                category: isFG ? catVal : "RAW MATERIAL",
                division: normalizedDivision || "Universal",
                unit: unitVal || "PCS",
                hsn: hsnVal || "—",
                isExisting: false,
                reason: `Duplicate in CSV: SKU "${skuVal}" appears multiple times in this file`,
              });
              return;
            }

            const batchMatchName = validRows.find((r) => {
              const rName = (r.item.name || "").trim().toLowerCase();
              const rDiv = (r.item.division || "").trim().toLowerCase();
              const sameName = rName === effectiveName.toLowerCase();
              const sameDiv = !targetDiv || !rDiv || rDiv === targetDiv;
              return sameName && sameDiv;
            });

            if (batchMatchName) {
              skippedRows.push({
                lineNum,
                sku: skuVal,
                name: effectiveName,
                category: isFG ? catVal : "RAW MATERIAL",
                division: normalizedDivision || "Universal",
                unit: unitVal || "PCS",
                hsn: hsnVal || "—",
                isExisting: false,
                reason: `Duplicate in CSV: Material "${effectiveName}" appears multiple times in this file`,
              });
              return;
            }

            // Valid row
            validRows.push({
              lineNum,
              sku: skuVal,
              name: effectiveName,
              category: isFG ? (catVal || "Finished Goods") : "RAW MATERIAL",
              subCategory: isFG ? (subCatVal || effectiveName) : "",
              division: normalizedDivision,
              unit: unitVal || "PCS",
              location: locVal || "",
              opening: openingVal,
              adc: adcVal,
              leadTime: leadTimeVal,
              safetyFactor: safetyFactorVal,
              moq: moqVal,
              supplierName: supplierNameVal,
              supplierCode: supplierCodeVal,
              status: statusVal,
              hsn: hsnVal || "—",
              item: {
                sku: skuVal,
                name: effectiveName,
                category: isFG ? (catVal || "Finished Goods") : "RAW MATERIAL",
                subCategory: isFG ? (subCatVal || effectiveName) : "",
                materialType: isFG ? "FG" : "RM",
                division: normalizedDivision,
                unit: unitVal || "PCS",
                location: locVal || "",
                opening: openingVal,
                adc: adcVal,
                leadTime: leadTimeVal,
                safetyFactor: safetyFactorVal,
                moq: moqVal,
                supplierName: supplierNameVal,
                supplierCode: supplierCodeVal,
                status: statusVal,
              },
            });
          });

          if (validRows.length === 0 && skippedRows.length === 0) {
            showToast("No readable rows found in the CSV.", "error");
            e.target.value = "";
            return;
          }

          setCsvPreviewModal({
            isOpen: true,
            type: isFG ? "finished_goods" : "raw_materials",
            title: isFG
              ? "Finished Goods CSV Import Preview"
              : "Raw Materials CSV Import Preview",
            fileName: file.name,
            validRows,
            skippedRows,
            activeTab: validRows.length > 0 ? "valid" : "skipped",
            searchQuery: "",
            isSubmitting: false,
            inputEvent,
          });
        } catch (err) {
          console.error("CSV parse error:", err);
          showToast("Failed to parse CSV file.", "error");
          e.target.value = "";
        }
      },
      error: () => {
        showToast(
          "Could not read the file. Make sure it is a valid CSV.",
          "error",
        );
        e.target.value = "";
      },
    });
  };

  const handleConfirmCSVImport = async () => {
    if (!canWrite) return;
    if (!csvPreviewModal.validRows || csvPreviewModal.validRows.length === 0) {
      showToast("No valid rows to import.", "error");
      return;
    }
    setCsvPreviewModal((prev) => ({ ...prev, isSubmitting: true }));
    try {
      const userName = activeUser?.name || activeUser?.user_name || "Admin";
      const newMaterials = csvPreviewModal.validRows.map((r) => r.item);

      await dispatch(
        saveMaterialsBatch({
          materials: newMaterials,
          currentUser: userName,
        }),
      ).unwrap();

      showToast(
        `Successfully imported ${newMaterials.length} material(s) into inventory.`,
        "success",
      );

      if (csvPreviewModal.inputEvent?.target) {
        csvPreviewModal.inputEvent.target.value = "";
      }
      setCsvPreviewModal({
        isOpen: false,
        type: "",
        title: "",
        fileName: "",
        validRows: [],
        skippedRows: [],
        activeTab: "valid",
        searchQuery: "",
        isSubmitting: false,
        inputEvent: null,
      });
      setIsModalOpen(false);
    } catch (err) {
      console.error("CSV import confirm error:", err);
      dispatch(clearError());
      const reason =
        typeof err === "string"
          ? err
          : err?.message || "Failed to save imported items.";
      showToast(`Import failed — ${reason}`, "error", 8000);
      setCsvPreviewModal((prev) => ({ ...prev, isSubmitting: false }));
    }
  };

  const handleExportSkippedCSV = () => {
    if (!csvPreviewModal.skippedRows || csvPreviewModal.skippedRows.length === 0)
      return;

    const exportData = csvPreviewModal.skippedRows.map((r) => ({
      "Line Number": r.lineNum,
      "SKU Code": r.sku || "—",
      "Item / Name": r.name || "—",
      Category: r.category || "—",
      "Firm / Division": r.division || "—",
      Unit: r.unit || "—",
      "Reason for Skipping": r.reason || "Skipped",
    }));

    const csv = Papa.unparse(exportData);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const filePrefix = csvPreviewModal.type || "import";
    link.setAttribute("download", `${filePrefix}_skipped.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Transaction history modal content
  const historyData = useMemo(() => {
    if (!historyModal.isOpen) return [];
    const targetSku = (historyModal.sku || "").trim().toLowerCase();
    const targetDiv = (historyModal.division || "").trim().toLowerCase();
    const reqType = (historyModal.type || "").trim().toUpperCase();

    return transactions
      .filter((t) => {
        const tSku = (t.sku || "").trim().toLowerCase();
        const tFgSku = (t.fgSku || "").trim().toLowerCase();
        const matchesSku = tSku === targetSku || (t.isJobCard && tFgSku === targetSku);
        if (!matchesSku) return false;

        const matchesDiv =
          !targetDiv ||
          targetDiv === "all" ||
          !t.firm ||
          (t.firm || "").trim().toLowerCase() === targetDiv;
        if (!matchesDiv) return false;

        const tType = (t.type || "").trim().toUpperCase();
        if (reqType === "IN") {
          return (
            tType === "IN" ||
            tType === "INWARD" ||
            tType === "JOB CARD" ||
            (t.isJobCard && (t.materialType === "FG" || tType !== "OUT"))
          );
        }
        if (reqType === "OUT") {
          return (
            tType === "OUT" ||
            tType === "OUTWARD" ||
            tType === "ISSUE" ||
            tType === "DISPATCH" ||
            (t.isJobCard && (t.materialType === "RM" || tType === "OUT"))
          );
        }
        return tType === reqType;
      })
      .sort((a, b) => {
        const dateA = (a.date || a.created_at || a.createdAt || "").toString();
        const dateB = (b.date || b.created_at || b.createdAt || "").toString();
        return dateB.localeCompare(dateA);
      });
  }, [transactions, historyModal]);

  const targetMaterial = useMemo(() => {
    const targetSku = ((historyModal.sku || trendModal.sku) || "").trim().toLowerCase();
    const targetDiv = ((historyModal.division || trendModal.division) || "").trim().toLowerCase();

    if (targetSku && targetDiv && targetDiv !== "all") {
      const match = materials.find(
        (m) =>
          (m.sku || "").trim().toLowerCase() === targetSku &&
          (m.division || "").trim().toLowerCase() === targetDiv,
      );
      if (match) return match;
    }
    return materials.find(
      (m) => (m.sku || "").trim().toLowerCase() === targetSku,
    );
  }, [materials, historyModal, trendModal]);

  const targetRecycleMaterial = useMemo(() => {
    if (recycleHistoryModal.isOpen && recycleHistoryModal.division) {
      const match = materials.find(
        (m) =>
          m.sku === recycleHistoryModal.sku &&
          m.division === recycleHistoryModal.division,
      );
      if (match) return match;
    }
    return materials.find((m) => m.sku === recycleHistoryModal.sku);
  }, [materials, recycleHistoryModal]);

  const recycleHistoryData = useMemo(() => {
    if (!recycleHistoryModal.isOpen) return [];
    const rSku = (recycleHistoryModal.sku || "").trim().toLowerCase();
    const rDiv = (recycleHistoryModal.division || "").trim().toLowerCase();
    const isTargetScrap = isScrapItem(targetRecycleMaterial);

    return (recycles || [])
      .filter((r) => (r.status || "").toLowerCase() === "completed")
      .filter((r) => {
        const itemSku = (r.material_sku || "").trim().toLowerCase();
        const itemName = (r.material_name || "").trim().toLowerCase();
        const matchesSku = itemSku
          ? itemSku === rSku
          : itemName && itemName === (targetRecycleMaterial?.name || "").trim().toLowerCase();
        const matchesDiv = !r.firm || !rDiv || r.firm.trim().toLowerCase() === rDiv;
        if (matchesSku && matchesDiv) return true;

        if (isTargetScrap && targetRecycleMaterial) {
          const isFg = String(r.recycle_type || "").toLowerCase().includes("finish");
          const weight = Number(r.weight) || 0;
          if (isFg && weight > 0) {
            const fgCat = getMaterialCategory(r, fgLookupMap);
            return matchScrapMaterialForFg(targetRecycleMaterial, r, fgCat);
          }
        }
        return false;
      })
      .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  }, [recycles, recycleHistoryModal, targetRecycleMaterial, fgLookupMap]);

  // Stock trend calculations
  const trendCalculations = useMemo(() => {
    if (!trendModal.isOpen || !targetMaterial)
      return { chartData: [], tableData: [], alert: null };

    const targetSku = (trendModal.sku || targetMaterial.sku || "").trim().toLowerCase();
    const targetDiv = (trendModal.division || targetMaterial.division || "").trim().toLowerCase();
    const targetName = (targetMaterial.name || "").trim().toLowerCase();

    const skuTxns = transactions
      .filter((t) => {
        const matchesSku = (t.sku || "").trim().toLowerCase() === targetSku;
        if (!matchesSku) return false;
        if (targetDiv && t.firm) {
          return t.firm.trim().toLowerCase() === targetDiv;
        }
        return true;
      })
      .map((t) => ({
        date: t.date,
        type: t.type,
        qty: Number(t.qty) || 0,
        ref: t.ref || "—",
      }));

    const skuTransfers = (allTransfers || [])
      .filter(
        (t) =>
          t.status === "Approved" &&
          (t.skuCode || "").trim().toLowerCase() === targetSku,
      )
      .filter(
        (t) =>
          !targetDiv ||
          (t.fromDivision && t.fromDivision.trim().toLowerCase() === targetDiv) ||
          (t.toDivision && t.toDivision.trim().toLowerCase() === targetDiv),
      )
      .map((t) => ({
        date:
          t.transferDate ||
          (t.approvedAt
            ? t.approvedAt.slice(0, 10)
            : t.submittedAt
              ? t.submittedAt.slice(0, 10)
              : ""),
        type:
          targetDiv && t.fromDivision && t.fromDivision.trim().toLowerCase() === targetDiv
            ? "Transfer OUT"
            : targetMaterial.division === t.fromDivision
              ? "Transfer OUT"
              : "Transfer IN",
        qty: Number(t.quantity) || 0,
        ref: t.id,
      }));

    const skuRecycles = (recycles || [])
      .filter((r) => (r.status || "").toLowerCase() === "completed")
      .filter((r) => {
        const rSku = (r.material_sku || "").trim().toLowerCase();
        const rName = (r.material_name || "").trim().toLowerCase();
        const matchesSkuOrName = rSku ? rSku === targetSku : (rName && rName === targetName);
        if (!matchesSkuOrName) return false;
        if (r.firm && targetDiv) {
          return r.firm.trim().toLowerCase() === targetDiv;
        }
        return true;
      })
      .map((r) => ({
        date:
          r.date ||
          (r.created_at ? r.created_at.slice(0, 10) : "") ||
          "—",
        type: "Rejected",
        qty: Number(r.quantity) || 0,
        ref: r.damage_type
          ? `Rejected (${r.damage_type})`
          : r.reason
            ? `Rejected (${r.reason})`
            : (r.id ? `REJ-${String(r.id).slice(-4)}` : "Rejected"),
      }));

    const isTargetScrap = isScrapItem(targetMaterial);
    let fgScrapMovements = [];
    if (isTargetScrap) {
      fgScrapMovements = (recycles || [])
        .filter((r) => (r.status || "").toLowerCase() === "completed")
        .filter((r) => {
          const isFg = String(r.recycle_type || "").toLowerCase().includes("finish");
          if (!isFg) return false;
          const weight = Number(r.weight) || 0;
          if (weight <= 0) return false;
          const fgCat = getMaterialCategory(r, fgLookupMap);
          return matchScrapMaterialForFg(targetMaterial, r, fgCat);
        })
        .map((r) => ({
          date:
            r.date ||
            (r.created_at ? r.created_at.slice(0, 10) : "") ||
            "—",
          type: "Rejected",
          qty: Number(r.weight) || 0,
          ref: `Scrap from FG: ${r.material_name || r.material_sku} (${r.weight} kg)`,
        }));
    }

    const allMovements = [
      ...skuTxns,
      ...skuTransfers,
      ...skuRecycles,
      ...fgScrapMovements,
    ].sort((a, b) =>
      (a.date || "").localeCompare(b.date || ""),
    );

    const safetyStock =
      (Number(targetMaterial.adc) || 0) *
      (Number(targetMaterial.safetyFactor) || 0);
    const reorderLevel =
      (Number(targetMaterial.adc) || 0) *
      (Number(targetMaterial.leadTime) || 0) +
      safetyStock;
    const maxLevel = reorderLevel + (Number(targetMaterial.moq) || 0);

    let running = Number(targetMaterial.opening) || 0;
    const chartData = [{ date: "Opening", closing: running }];
    const tableData = [
      {
        date: "Opening Balance",
        txn: "—",
        qty: "—",
        closing: running,
        ref: "—",
      },
    ];

    allMovements.forEach((m) => {
      const qty = m.qty;
      const isIn =
        m.type === "IN" ||
        m.type === "Job Card" ||
        m.type === "Transfer IN" ||
        (m.type === "Rejected" && isTargetScrap);
      if (isIn) {
        running += qty;
      } else {
        running -= qty;
      }
      chartData.push({ date: m.date, closing: running });
      tableData.push({
        date: m.date,
        txn:
          isTargetScrap && m.type === "Rejected"
            ? "Rejected (Scrap Added)"
            : m.type,
        qty: (isIn ? "+" : "-") + qty.toLocaleString(),
        closing: running,
        ref: m.ref || "—",
      });
    });

    const finalClosing = running;
    let alertType = "healthy";
    let alertMsg = `Stock level is healthy. Current band: ${stockBandOf(finalClosing, maxLevel)}`;

    if (finalClosing <= safetyStock) {
      alertType = "critical";
      alertMsg = `CRITICAL ALERT: Stock (${finalClosing.toLocaleString()}) is below Safety Stock (${safetyStock.toLocaleString()}). Immediate reorder required!`;
    } else if (finalClosing <= reorderLevel) {
      alertType = "warning";
      alertMsg = `Reorder Alert: Stock (${finalClosing.toLocaleString()}) is below Reorder Level (${reorderLevel.toLocaleString()}). Plan a restock soon.`;
    }

    return {
      chartData,
      tableData: tableData.reverse(),
      alert: { type: alertType, message: alertMsg },
      safetyStock,
      reorderLevel,
    };
  }, [targetMaterial, transactions, allTransfers, recycles, trendModal, fgLookupMap]);

  function stockBandOf(closing, maxLevel) {
    if (maxLevel <= 0) return "Normal Stock";
    const pct = (closing / maxLevel) * 100;
    if (pct > 100) return "Excess Stock";
    if (pct >= 66.33) return "Normal Stock";
    if (pct >= 33) return "66.33% Stock";
    return "Below 33%";
  }

  const handleBandClick = (clickedBand) => {
    setBand((prev) => (prev === clickedBand ? "" : clickedBand));
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6">
      {isReadOnly && <ReadOnlyBanner className="mb-3" />}
      {/* Legend Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-1.5 bg-gray-100/90 dark:bg-slate-950/90 rounded-2xl border border-gray-200/80 dark:border-slate-800/80 shadow-xs">
        {[
          {
            key: "Excess Stock",
            label: "Excess Stock (>100%)",
            bgActive: "bg-blue-600 text-white shadow-blue-500/25 ring-blue-500",
            bgInactive: "bg-blue-600/85 hover:bg-blue-600 text-white",
          },
          {
            key: "Normal Stock",
            label: "Normal Stock (66-100%)",
            bgActive:
              "bg-emerald-600 text-white shadow-emerald-500/25 ring-emerald-500",
            bgInactive: "bg-emerald-600/85 hover:bg-emerald-600 text-white",
          },
          {
            key: "66.33% Stock",
            label: "66.33% Stock (33-66%)",
            bgActive:
              "bg-amber-500 text-slate-950 font-black shadow-amber-500/25 ring-amber-500",
            bgInactive:
              "bg-amber-500/90 hover:bg-amber-500 text-slate-950 font-bold",
          },
          {
            key: "Below 33%",
            label: "Below 33% (Critical)",
            bgActive: "bg-rose-600 text-white shadow-rose-500/25 ring-rose-500",
            bgInactive: "bg-rose-600/85 hover:bg-rose-600 text-white",
          },
        ].map((item) => {
          const isActive = band === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => handleBandClick(item.key)}
              title={
                isActive ? "Click to clear filter" : `Filter by ${item.label}`
              }
              className={`flex items-center justify-center gap-2 py-3 px-3 rounded-xl text-xs tracking-wider transition-all duration-200 cursor-pointer select-none ${isActive
                  ? `${item.bgActive} shadow-lg scale-[1.02] ring-2 ring-offset-2 dark:ring-offset-slate-900 z-10`
                  : `${item.bgInactive} ${band ? "opacity-50 hover:opacity-85" : "opacity-100"}`
                }`}
            >
              {isActive && (
                <CheckCircle2
                  size={15}
                  className="shrink-0 animate-in fade-in zoom-in duration-200"
                />
              )}
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl p-4 shadow-xs">
        <div className="relative flex-1 min-w-[240px]">
          <Search
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500"
            size={18}
          />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search SKU or material name..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-gray-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Filter 1: Material Type */}
        <CustomSelect
          value={materialTypeFilter}
          onChange={(val) => {
            setMaterialTypeFilter(val);
            setCurrentPage(1);
          }}
          options={materialTypeOptions}
          placeholder="All Material Types"
          searchPlaceholder="Search material type..."
          className="min-w-[155px] flex-1 sm:flex-initial"
        />

        {/* Filter 2: Firms */}
        <CustomSelect
          value={firmFilter}
          onChange={(val) => {
            setFirmFilter(val);
            setCurrentPage(1);
          }}
          options={firmOptions}
          placeholder="All Firms"
          searchPlaceholder="Search firm / division..."
          className="min-w-[145px] flex-1 sm:flex-initial"
        />

        {/* Filter 3: Categories */}
        <CustomSelect
          value={category}
          onChange={(val) => {
            setCategory(val);
            setCurrentPage(1);
          }}
          options={categoryOptions}
          placeholder="All Categories"
          searchPlaceholder="Search category..."
          className="min-w-[155px] flex-1 sm:flex-initial"
        />


        {/* Filter 4: Sub Categories (Product / Material Names) */}
        <CustomSelect
          value={subCategoryFilter}
          onChange={(val) => {
            setSubCategoryFilter(val);
            setCurrentPage(1);
          }}
          options={subCategoryOptions}
          placeholder="All Sub Categories"
          searchPlaceholder="Search sub category / material..."
          className="min-w-[180px] flex-1 sm:flex-initial"
        />

        {/* Filter 5: SKU (Hidden per request) */}
        {/* <CustomSelect
          value={skuFilter}
          onChange={(val) => {
            setSkuFilter(val);
            setCurrentPage(1);
          }}
          options={skuOptions}
          placeholder="All SKUs"
          searchPlaceholder="Search SKU..."
          className="min-w-[155px] flex-1 sm:flex-initial"
        /> */}

        {/* Reset Active Filters Button */}
        {(materialTypeFilter ||
          firmFilter ||
          category ||
          subCategoryFilter ||
          skuFilter ||
          search) && (
            <button
              onClick={() => {
                setSearch("");
                setMaterialTypeFilter("");
                setFirmFilter("");
                setCategory("");
                setSubCategoryFilter("");
                setSkuFilter("");
                setCurrentPage(1);
              }}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl hover:bg-rose-100 dark:hover:bg-rose-900/50 cursor-pointer transition-colors active:scale-95"
              title="Reset all active filters"
            >
              <X size={14} />
              Reset
            </button>
          )}

        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 border border-gray-200 dark:border-slate-800 rounded-xl text-sm font-bold text-gray-750 hover:border-indigo-500 hover:text-indigo-650 cursor-pointer bg-white dark:bg-slate-900"
        >
          <FileSpreadsheet size={16} />
          Export CSV
        </button>

        {!isViewer && (
          <>
            <button
              disabled={!canWrite}
              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
              onClick={handleAdd}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              Add Material
            </button>
            <button
              disabled={!canWrite}
              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
              onClick={handleOpenTxnModal}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              Post Transaction
            </button>
            <button
              disabled={!canWrite}
              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
              onClick={() => setIsRecycleModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={16} />
              Rejected
            </button>
            <button
              disabled={!canWrite}
              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
              onClick={() => setIsTransferModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowLeftRight size={16} />
              Transfer Material
            </button>
            <button
              onClick={() => setIsReportModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all"
            >
              <FileText size={16} />
              Report
            </button>
            <button
              onClick={() => setIsConsumptionModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all"
            >
              <Activity size={16} />
              Daily Consumption Report
            </button>
            <button
              onClick={handleBatchDetailPdf}
              className="flex items-center gap-1.5 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-sm font-bold shadow-sm cursor-pointer active:scale-95 transition-all"
            >
              <Layers size={16} />
              Batch Detail
            </button>
          </>
        )}
      </div>

      {/* Grid Container */}
      <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-gray-50 dark:bg-slate-950 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-slate-400 text-xs font-bold uppercase tracking-wider select-none">
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("sku")}
                >
                  SKU Code
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("name")}
                >
                  Sub Category
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("division")}
                >
                  Firm
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("materialType")}
                >
                  Material Type
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("category")}
                >
                  Category
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("opening")}
                >
                  Opening Stock
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("adc")}
                >
                  ADC
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("leadTime")}
                >
                  Lead Time
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("safetyStock")}
                >
                  Safety Stock
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("reorderLevel")}
                >
                  Reorder Lvl
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("moq")}
                >
                  MOQ
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("maxLevel")}
                >
                  Max Lvl
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("totalIn")}
                >
                  Total IN
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("totalOut")}
                >
                  Total OUT
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("recycleQty")}
                >
                  Rejected Qty
                </th>
                <th
                  className="px-5 py-4 cursor-pointer select-none text-center bg-indigo-50/90 dark:bg-indigo-950/70 text-indigo-950 dark:text-indigo-200 border-x-2 border-indigo-200 dark:border-indigo-800/80 font-black tracking-tight whitespace-nowrap shadow-xs hover:bg-indigo-100/90 dark:hover:bg-indigo-900/60 transition-colors"
                  onClick={() => requestSort("closingStock")}
                  title="Click to sort Closing Stock"
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Closing Stock</span>
                    {sortKey === "closingStock" && (
                      <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                        {sortDir === 1 ? "↑" : "↓"}
                      </span>
                    )}
                  </div>
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-teal-500"
                  onClick={() => requestSort("latestPhysicalStock")}
                >
                  Physical Stock
                </th>
                <th
                  className="px-5 py-4 cursor-pointer hover:text-indigo-500"
                  onClick={() => requestSort("band")}
                >
                  Stock Band
                </th>
                {!isViewer && <th className="px-5 py-4">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td
                    colSpan={isViewer ? 18 : 19}
                    className="text-center py-12 px-6"
                  >
                    {selectedCatalogItem ? (
                      <div className="max-w-xl mx-auto bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-3xl p-6 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                        <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-900/60 flex items-center justify-center mx-auto text-amber-600 dark:text-amber-400 mb-3">
                          <AlertCircle size={24} />
                        </div>
                        <h4 className="text-base font-bold text-gray-900 dark:text-white">
                          No Opening Stock for &ldquo;{selectedCatalogItem.name}
                          &rdquo;
                        </h4>
                        <p className="text-xs text-gray-600 dark:text-slate-300 mt-2 leading-relaxed">
                          This product exists in the{" "}
                          <span className="font-bold text-amber-700 dark:text-amber-300">
                            {selectedCatalogItem.materialType === "FG"
                              ? "Finished Goods"
                              : "Raw Material"}
                          </span>{" "}
                          catalog, but has not been initialized with opening
                          stock in the Inventory Master (
                          <code className="font-mono bg-amber-100 dark:bg-amber-900/80 px-1 py-0.5 rounded text-[11px]">
                            inventory_materials
                          </code>
                          ).
                        </p>
                        {!isViewer && (
                          <button
                            disabled={!canWrite}
                            title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                            type="button"
                            onClick={() =>
                              handleCreateOpeningForCatalogItem(
                                selectedCatalogItem,
                              )
                            }
                            className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Plus size={16} />
                            Create Opening Stock for &ldquo;
                            {selectedCatalogItem.name}&rdquo;
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="py-6 text-gray-400 dark:text-slate-500">
                        No matching stock items found.
                      </div>
                    )}
                  </td>
                </tr>
              ) : (
                paginatedRows.map((row) => {
                  const style =
                    BAND_STYLES[row.band] || BAND_STYLES["Normal Stock"];
                  const matType = (
                    row.materialType ||
                    row.material_type ||
                    "RM"
                  ).toUpperCase();
                  return (
                    <tr
                      key={
                        row._virtualKey ||
                        (row.id
                          ? `mat-${row.id}`
                          : `${row.sku}__${row.division || ""}`)
                      }
                      className={`transition-all duration-150 ${style.rowCls}`}
                    >
                      <td
                        onClick={() =>
                          setTrendModal({
                            isOpen: true,
                            sku: row.sku,
                            division: row.division,
                          })
                        }
                        className="px-5 py-4 font-mono font-bold text-indigo-600 dark:text-indigo-400 cursor-pointer hover:underline whitespace-nowrap select-all"
                      >
                        {row.sku}
                      </td>
                      <td
                        onClick={() =>
                          setTrendModal({
                            isOpen: true,
                            sku: row.sku,
                            division: row.division,
                          })
                        }
                        className="px-5 py-4 font-bold text-gray-900 dark:text-white cursor-pointer hover:underline whitespace-nowrap"
                      >
                        <div className="flex items-center gap-2 flex-wrap">
                          {/* Phase 4 — Live name from master catalog; falls back to stored snapshot */}
                          <span className={
                            masterMaterialMap[row.masterMaterialId]?.status === 'Inactive'
                              ? 'text-gray-400 dark:text-slate-500 line-through'
                              : ''
                          }>
                            {masterMaterialMap[row.masterMaterialId]?.name || row.name}
                          </span>
                          {masterMaterialMap[row.masterMaterialId]?.status === 'Inactive' && (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
                              INACTIVE
                            </span>
                          )}
                          {row.hasApprovedIndent && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shadow-2xs">
                              <CheckCircle2 size={12} className="shrink-0" />
                              Approved Indent
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap">
                        {row.division ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                            {row.division}
                          </span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="px-5 py-4 font-semibold text-gray-700 dark:text-slate-300 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${matType === "FG"
                              ? "bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800"
                              : "bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
                            }`}
                        >
                          {matType}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-gray-600 dark:text-slate-350">
                        {row.category}
                      </td>
                      <td className="px-5 py-4 text-gray-650 dark:text-slate-350 font-semibold">
                        {(Number(row.opening) || 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 font-bold text-gray-800 dark:text-slate-200">
                        {row.adc.toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-gray-600 dark:text-slate-350">
                        {row.leadTime}d
                      </td>
                      <td className="px-5 py-4 text-gray-500 dark:text-slate-400">
                        {row.safetyStock.toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-gray-500 dark:text-slate-400">
                        {row.reorderLevel.toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-gray-500 dark:text-slate-400">
                        {row.moq.toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-gray-500 dark:text-slate-400">
                        {row.maxLevel.toLocaleString()}
                      </td>
                      <td className="px-5 py-4">
                        <span
                          onClick={() =>
                            setHistoryModal({
                              isOpen: true,
                              sku: row.sku,
                              division: row.division,
                              type: "IN",
                            })
                          }
                          className="inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-teal-500/10 text-teal-600 dark:text-teal-400 cursor-pointer hover:bg-teal-500/20"
                        >
                          {row.totalIn.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <span
                          onClick={() =>
                            setHistoryModal({
                              isOpen: true,
                              sku: row.sku,
                              division: row.division,
                              type: "OUT",
                            })
                          }
                          className="inline-flex px-2 py-0.5 rounded-full text-xs font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 cursor-pointer hover:bg-rose-500/20"
                        >
                          {row.totalOut.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        {(() => {
                          const isRowScrap = isScrapItem(row);
                          const hasRecycle = (row.recycleQty || 0) > 0;
                          return (
                            <span
                              onClick={() =>
                                setRecycleHistoryModal({
                                  isOpen: true,
                                  sku: row.sku,
                                  division: row.division,
                                })
                              }
                              className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-bold cursor-pointer transition-colors ${hasRecycle
                                  ? isRowScrap
                                    ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20"
                                    : "bg-amber-500/10 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20"
                                  : "text-gray-400 dark:text-slate-500 hover:text-gray-600"
                                }`}
                              title={
                                hasRecycle
                                  ? isRowScrap
                                    ? `Scrap Generated: +${row.recycleQty.toLocaleString()} (Added to Closing Stock). Click to view rejected history.`
                                    : `Rejected: ${row.recycleQty.toLocaleString()} (Deducted from Closing Stock). Click to view rejected history.`
                                  : "No rejected quantity. Click to view rejected history."
                              }
                            >
                              {hasRecycle && isRowScrap ? "+" : ""}
                              {(row.recycleQty || 0).toLocaleString()}
                            </span>
                          );
                        })()}
                      </td>
                      <td className="px-5 py-4 text-center bg-indigo-50/40 dark:bg-indigo-950/30 border-x-2 border-indigo-100 dark:border-indigo-900/50 whitespace-nowrap">
                        <span className="inline-flex items-center justify-center min-w-[54px] px-3 py-1 rounded-xl bg-indigo-100/90 dark:bg-indigo-900/60 text-indigo-950 dark:text-indigo-100 font-black text-base tracking-tight shadow-xs border border-indigo-200/80 dark:border-indigo-700/60">
                          {row.closingStock.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="inline-flex flex-col">
                          {row.latestPhysicalStock !== null ? (
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-gray-900 dark:text-white">
                                {row.latestPhysicalStock.toLocaleString()}
                              </span>
                              <span
                                className={`px-1.5 py-0.5 text-[10px] font-bold rounded-md uppercase tracking-wider ${row.physicalStockStatus === "Approved"
                                    ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800"
                                    : row.physicalStockStatus === "Rejected"
                                      ? "bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300 border border-rose-300 dark:border-rose-800"
                                      : "bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800"
                                  }`}
                              >
                                {row.physicalStockStatus || "Pending"}
                              </span>
                            </div>
                          ) : (
                            <span className="font-bold text-gray-900 dark:text-white">
                              0
                            </span>
                          )}
                          {row.physicalStockVariance !== null &&
                            row.physicalStockVariance !== 0 && (
                              <span
                                className={`text-[11px] font-semibold ${row.physicalStockVariance > 0
                                    ? "text-emerald-600 dark:text-emerald-400"
                                    : "text-rose-600 dark:text-rose-400"
                                  }`}
                              >
                                Var:{" "}
                                {row.physicalStockVariance > 0
                                  ? `+${row.physicalStockVariance}`
                                  : row.physicalStockVariance}
                              </span>
                            )}
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${style.badgeCls}`}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${row.band === "Below 33%"
                                ? "bg-rose-500 animate-pulse"
                                : row.band === "66.33% Stock"
                                  ? "bg-amber-500"
                                  : row.band === "Normal Stock"
                                    ? "bg-emerald-500"
                                    : "bg-blue-500"
                              }`}
                          />
                          {row.band}
                        </span>
                      </td>
                      {!isViewer && (
                        <td className="px-5 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <button
                              disabled={!canWrite}
                              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                              onClick={() => handleEdit(row)}
                              className="p-1 text-gray-450 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              <Edit2 size={15} />
                            </button>
                            <button
                              disabled={!canWrite}
                              title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                              onClick={() => handleDelete(row)}
                              className="p-1 text-gray-450 hover:text-rose-600 dark:hover:text-rose-450 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 bg-gray-50 dark:bg-slate-950 border-t border-gray-200 dark:border-slate-800 text-xs font-bold text-gray-500 dark:text-slate-400">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div>
              Showing{" "}
              {filteredRows.length === 0
                ? 0
                : Math.min(
                  filteredRows.length,
                  (currentPage - 1) * pageSize + 1,
                )}
              –{Math.min(filteredRows.length, currentPage * pageSize)} of{" "}
              {filteredRows.length} items
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase text-gray-400 tracking-wider">
                Rows per page:
              </span>
              <select
                value={pageSize}
                onChange={handlePageSizeChange}
                className="px-2 py-0.5 border border-gray-200 dark:border-slate-800 rounded-md bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-350 cursor-pointer focus:ring-1 focus:ring-indigo-500 font-normal"
              >
                <option value="6">6</option>
                <option value="12">12</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </select>
            </div>
          </div>
          {totalPages > 1 && (
            <div className="flex items-center gap-1.5">
              {Array.from({ length: totalPages }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentPage(idx + 1)}
                  className={`w-7 h-7 rounded-lg transition-colors cursor-pointer flex items-center justify-center border text-[11px] ${currentPage === idx + 1
                      ? "bg-indigo-600 text-white border-indigo-600"
                      : "bg-white dark:bg-slate-900 border-gray-200 dark:border-slate-800 text-gray-600 dark:text-slate-350 hover:bg-gray-50 dark:hover:bg-slate-850"
                    }`}
                >
                  {idx + 1}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* MODAL 1: Transaction History */}
      {historyModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl animate-scale-up flex flex-col max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4">
              <h3 className="text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                <History className="text-indigo-500" size={20} />
                <span>{historyModal.type} Transaction History</span>
              </h3>
              <button
                onClick={() =>
                  setHistoryModal({ isOpen: false, sku: "", type: "" })
                }
                className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              <div className="bg-gray-50 dark:bg-slate-950 p-4 rounded-2xl border border-gray-200 dark:border-slate-800/60 mb-5 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-gray-700 dark:text-slate-300">
                  <div>
                    <span className="text-xs text-gray-500 dark:text-slate-400 block">SKU Code</span>
                    <span className="font-mono font-bold text-gray-900 dark:text-white break-all">
                      {historyModal.sku}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500 dark:text-slate-400 block">Material</span>
                    <span className="font-bold text-gray-900 dark:text-white">
                      {targetMaterial?.name || "—"}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500 dark:text-slate-400 block">Total {historyModal.type} (incl. Transfers)</span>
                    <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {(() => {
                        const txnTotal = historyData.reduce((sum, item) => sum + (Number(item.qty) || 0), 0);
                        const modalSku = (historyModal.sku || "").trim().toLowerCase();
                        const modalDiv = (historyModal.division || "").trim().toLowerCase();
                        const trf = (allTransfers || []).filter(t => {
                          if (t.status !== "Approved") return false;
                          const ts = (t.skuCode || "").trim().toLowerCase();
                          const skuMatch = ts === modalSku || ts === (targetMaterial?.name || "").trim().toLowerCase();
                          if (!skuMatch) return false;
                          return historyModal.type === "IN"
                            ? (t.toDivision || "").trim().toLowerCase() === modalDiv
                            : (t.fromDivision || "").trim().toLowerCase() === modalDiv;
                        }).reduce((sum, t) => sum + (Number(t.quantity) || 0), 0);
                        return (txnTotal + trf).toLocaleString();
                      })()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="border border-gray-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-slate-950 text-gray-505 dark:text-slate-400 font-bold border-b border-gray-200 dark:border-slate-800">
                      <th className="px-4 py-3">Date</th>
                      <th className="px-4 py-3">Qty</th>
                      <th className="px-4 py-3">Reference</th>
                      <th className="px-4 py-3">User</th>
                      <th className="px-4 py-3">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 text-gray-750 dark:text-slate-300">
                    {historyData.length === 0 ? (
                      <tr>
                        <td
                          colSpan={5}
                          className="text-center py-6 text-gray-400"
                        >
                          No {historyModal.type} logs available.
                        </td>
                      </tr>
                    ) : (
                      historyData.map((log) => {
                        const isJobCardLog =
                          log.type === "Job Card" ||
                          (log.type || "").toUpperCase() === "JOB CARD" ||
                          Boolean(log.isJobCard);
                        return (
                          <tr key={log.id || `${log.sku}-${log.date}-${log.qty}-${Math.random()}`}>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {log.date || (log.created_at ? log.created_at.slice(0, 10) : "—")}
                            </td>
                            <td className="px-4 py-3 font-bold text-gray-900 dark:text-white">
                              {(Number(log.qty) || 0).toLocaleString()}
                            </td>
                            <td className="px-4 py-3 font-mono">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {isJobCardLog && (
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300">
                                    Job Card
                                  </span>
                                )}
                                <span>
                                  {log.ref ||
                                    (log.jobCardId
                                      ? `#${log.jobCardId}`
                                      : isJobCardLog
                                        ? "Job Card Production"
                                        : "—")}
                                </span>
                              </div>
                            </td>
                            <td className="px-4 py-3 truncate max-w-[90px]" title={log.user || "—"}>
                              {log.user || "—"}
                            </td>
                            <td
                              className="px-4 py-3 min-w-[260px] max-w-[420px] whitespace-normal break-words"
                              title={log.remarks || (isJobCardLog ? "Produced via Job Card" : "")}
                            >
                              {log.remarks || (isJobCardLog ? "Produced via Job Card" : "—")}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Internal Transfer Details section in history popup */}
              {historyModal.type === "IN" &&
                (() => {
                  const targetSku = (historyModal.sku || "").trim().toLowerCase();
                  const targetDiv = (historyModal.division || "").trim().toLowerCase();
                  const matchingInTransfers = (allTransfers || []).filter(
                    (t) =>
                      t.status === "Approved" &&
                      (t.skuCode || "").trim().toLowerCase() === targetSku &&
                      (!targetDiv ||
                        targetDiv === "all" ||
                        (t.toDivision || "").trim().toLowerCase() === targetDiv),
                  );
                  if (matchingInTransfers.length === 0) return null;

                  const totalTrfIn = matchingInTransfers.reduce(
                    (sum, t) => sum + (Number(t.quantity) || 0),
                    0,
                  );

                  return (
                    <div className="mt-5 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/80 rounded-2xl p-4 text-xs">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                          ↙ Internal Transfer IN
                        </span>
                        <span className="font-mono font-bold text-teal-700 dark:text-teal-400">
                          +{totalTrfIn.toLocaleString()}
                        </span>
                      </div>
                      <div className="space-y-2 divide-y divide-teal-200/60 dark:divide-teal-800/40">
                        {matchingInTransfers.map((trf) => (
                          <div
                            key={trf.id}
                            className="pt-2 first:pt-0 grid grid-cols-4 gap-2 text-gray-600 dark:text-slate-300 font-medium"
                          >
                            <div>
                              From:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {trf.fromDivision}
                              </span>
                            </div>
                            <div>
                              Qty:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {Number(trf.quantity).toLocaleString()}
                              </span>
                            </div>
                            <div>
                              Date:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {trf.transferDate ||
                                  (trf.approvedAt
                                    ? trf.approvedAt.slice(0, 10)
                                    : "—")}
                              </span>
                            </div>
                            <div>
                              Ref:{" "}
                              <span className="font-mono text-gray-900 dark:text-white">
                                {trf.id}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()}

              {historyModal.type === "OUT" &&
                (() => {
                  const targetSku = (historyModal.sku || "").trim().toLowerCase();
                  const targetDiv = (historyModal.division || "").trim().toLowerCase();
                  const matchingTransfers = (allTransfers || []).filter(
                    (t) =>
                      t.status === "Approved" &&
                      (t.skuCode || "").trim().toLowerCase() === targetSku &&
                      (!targetDiv ||
                        targetDiv === "all" ||
                        (t.fromDivision || "").trim().toLowerCase() === targetDiv),
                  );
                  if (matchingTransfers.length === 0) return null;

                  const totalTrfOut = matchingTransfers.reduce(
                    (sum, t) => sum + (Number(t.quantity) || 0),
                    0,
                  );

                  return (
                    <div className="mt-5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-2xl p-4 text-xs">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                          ↗ Internal Transfer OUT
                        </span>
                        <span className="font-mono font-bold text-amber-700 dark:text-amber-400">
                          -{totalTrfOut.toLocaleString()}
                        </span>
                      </div>
                      <div className="space-y-2 divide-y divide-amber-200/60 dark:divide-amber-800/40">
                        {matchingTransfers.map((trf) => (
                          <div
                            key={trf.id}
                            className="pt-2 first:pt-0 grid grid-cols-4 gap-2 text-gray-600 dark:text-slate-300 font-medium"
                          >
                            <div>
                              To:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {trf.toDivision}
                              </span>
                            </div>
                            <div>
                              Qty:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {Number(trf.quantity).toLocaleString()}
                              </span>
                            </div>
                            <div>
                              Date:{" "}
                              <span className="font-bold text-gray-900 dark:text-white">
                                {trf.transferDate ||
                                  (trf.approvedAt
                                    ? trf.approvedAt.slice(0, 10)
                                    : "—")}
                              </span>
                            </div>
                            <div>
                              Ref:{" "}
                              <span className="font-mono text-gray-900 dark:text-white">
                                {trf.id}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()}
            </div>
            <div className="flex justify-end border-t border-gray-150 dark:border-slate-800 px-6 py-4">
              <button
                onClick={() =>
                  setHistoryModal({
                    isOpen: false,
                    sku: "",
                    division: "",
                    type: "",
                  })
                }
                className="px-5 py-2 text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Recycle History */}
      {recycleHistoryModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-3xl shadow-2xl animate-scale-up flex flex-col max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4">
              <h3 className="text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                <History className="text-amber-500" size={20} />
                <span>Rejected History</span>
              </h3>
              <button
                type="button"
                onClick={() =>
                  setRecycleHistoryModal({ isOpen: false, sku: "", division: "" })
                }
                className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              <div className="bg-gray-50 dark:bg-slate-950 p-4 rounded-2xl border border-gray-200 dark:border-slate-800/60 mb-5 text-sm">
                <div className="grid grid-cols-2 gap-2 text-gray-700 dark:text-slate-300">
                  <div>
                    SKU Code:{" "}
                    <span className="font-mono font-bold text-gray-900 dark:text-white">
                      {recycleHistoryModal.sku}
                    </span>
                  </div>
                  <div>
                    Material:{" "}
                    <span className="font-bold text-gray-900 dark:text-white">
                      {targetRecycleMaterial?.name || "—"}
                    </span>
                  </div>
                  {recycleHistoryModal.division && (
                    <div className="col-span-2 text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                      Firm:{" "}
                      <span className="font-semibold text-gray-800 dark:text-slate-200">
                        {recycleHistoryModal.division}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="border border-gray-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-slate-950 text-gray-500 dark:text-slate-400 font-bold border-b border-gray-200 dark:border-slate-800">
                      <th className="px-4 py-3">Date</th>
                      <th className="px-4 py-3">Material SKU / Name</th>
                      <th className="px-4 py-3">Impact Value</th>
                      <th className="px-4 py-3">Damage Type</th>
                      <th className="px-4 py-3">Approved By</th>
                      <th className="px-4 py-3">Reason</th>
                      <th className="px-4 py-3 text-center">Attachment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 text-gray-700 dark:text-slate-300">
                    {recycleHistoryData.length === 0 ? (
                      <tr>
                        <td
                          colSpan={7}
                          className="text-center py-6 text-gray-400"
                        >
                          No rejected history logs available.
                        </td>
                      </tr>
                    ) : (
                      recycleHistoryData.map((log) => {
                        const isLogScrap = isScrapItem(targetRecycleMaterial);
                        const isFromFg = String(log.recycle_type || "")
                          .toLowerCase()
                          .includes("finish");

                        return (
                          <tr key={log.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/30 transition-colors">
                            <td className="px-4 py-3 whitespace-nowrap">
                              {log.date}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex flex-col gap-0.5">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                    {log.material_sku || log.material_name || "—"}
                                  </span>
                                  {isFromFg && (
                                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300">
                                      FG Conversion
                                    </span>
                                  )}
                                </div>
                                {log.material_name &&
                                  log.material_name !== log.material_sku && (
                                    <span className="text-[11px] text-gray-500 dark:text-slate-400">
                                      {log.material_name}
                                    </span>
                                  )}
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              {isLogScrap && isFromFg ? (
                                <div className="flex flex-col">
                                  <span className="font-bold text-emerald-600 dark:text-emerald-400">
                                    +{Number(log.weight || 0).toLocaleString()} kg
                                  </span>
                                  <span className="text-[10px] text-gray-400 dark:text-slate-500 font-normal">
                                    ({Number(log.quantity).toLocaleString()} pcs rejected)
                                  </span>
                                </div>
                              ) : isLogScrap ? (
                                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                                  +{Number(log.quantity).toLocaleString()}
                                </span>
                              ) : (
                                <span className="font-bold text-rose-600 dark:text-rose-400">
                                  -{Number(log.quantity).toLocaleString()}
                                </span>
                              )}
                            </td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300">
                                {log.damage_type || "Damage"}
                              </span>
                            </td>
                            <td className="px-4 py-3 truncate max-w-[90px]">
                              {log.approved_by || "—"}
                            </td>
                            <td
                              className="px-4 py-3 max-w-[120px] truncate"
                              title={log.reason}
                            >
                              {log.reason || "—"}
                            </td>
                            <td className="px-4 py-3 text-center">
                              {log.attachment_url ? (
                                <a
                                  href={log.attachment_url}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
                                >
                                  View
                                </a>
                              ) : (
                                <span className="text-gray-400">—</span>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="flex justify-end border-t border-gray-150 dark:border-slate-800 px-6 py-4">
              <button
                type="button"
                onClick={() =>
                  setRecycleHistoryModal({
                    isOpen: false,
                    sku: "",
                    division: "",
                  })
                }
                className="px-5 py-2 text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Stock Trend */}
      {trendModal.isOpen && targetMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-4xl shadow-2xl animate-scale-up flex flex-col max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4">
              <h3 className="text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="text-indigo-500" size={20} />
                <span>
                  Stock Level Analytics — {targetMaterial.name} (
                  {trendModal.sku})
                </span>
              </h3>
              <button
                onClick={() =>
                  setTrendModal({ isOpen: false, sku: "", division: "" })
                }
                className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[75vh] space-y-6">
              {/* Alert Ribbon */}
              {trendCalculations.alert && (
                <div
                  className={`p-4 rounded-2xl border text-sm font-bold flex items-center gap-2 ${trendCalculations.alert.type === "critical"
                      ? "bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/20 dark:border-rose-900 dark:text-rose-300"
                      : trendCalculations.alert.type === "warning"
                        ? "bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-950/20 dark:border-amber-900 dark:text-amber-300"
                        : "bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-950/20 dark:border-emerald-900 dark:text-emerald-300"
                    }`}
                >
                  <span className="text-base">
                    {trendCalculations.alert.type === "critical"
                      ? "🚨"
                      : trendCalculations.alert.type === "warning"
                        ? "⚠️"
                        : "✅"}
                  </span>
                  {trendCalculations.alert.message}
                </div>
              )}

              {/* Line Chart */}
              <div className="bg-gray-50 dark:bg-slate-950 border border-gray-200 dark:border-slate-800 rounded-2xl p-4">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">
                  Stock Level Timeline
                </h4>
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={trendCalculations.chartData}
                      margin={{ top: 10, right: 25, left: -25, bottom: 0 }}
                    >
                      <XAxis
                        dataKey="date"
                        tickLine={false}
                        axisLine={false}
                        style={{ fontSize: "9px" }}
                      />
                      <YAxis
                        tickLine={false}
                        axisLine={false}
                        style={{ fontSize: "9px" }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(15, 23, 42, 0.9)",
                          border: "none",
                          borderRadius: "8px",
                          color: "#fff",
                          fontSize: "11px",
                        }}
                      />
                      <Legend
                        verticalAlign="bottom"
                        height={24}
                        iconSize={8}
                        wrapperStyle={{ fontSize: "10px" }}
                      />
                      <Line
                        type="monotone"
                        dataKey="closing"
                        name="Stock Level"
                        stroke="#6366f1"
                        strokeWidth={2.5}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                      <ReferenceLine
                        y={trendCalculations.reorderLevel}
                        stroke="#d97706"
                        strokeDasharray="4 4"
                        label={{
                          value: "Reorder Level",
                          fill: "#d97706",
                          fontSize: 9,
                          position: "insideTopRight",
                        }}
                      />
                      <ReferenceLine
                        y={trendCalculations.safetyStock}
                        stroke="#ef4444"
                        strokeDasharray="3 3"
                        label={{
                          value: "Safety Stock",
                          fill: "#ef4444",
                          fontSize: 9,
                          position: "insideBottomRight",
                        }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Transaction Stream */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Transaction Ledger
                </h4>
                <div className="border border-gray-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-slate-950 text-gray-550 dark:text-slate-400 font-bold border-b border-gray-200 dark:border-slate-800">
                        <th className="px-5 py-3">Date</th>
                        <th className="px-5 py-3">Transaction</th>
                        <th className="px-5 py-3">Quantity</th>
                        <th className="px-5 py-3">Closing Stock Balance</th>
                        <th className="px-5 py-3">Reference #</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 text-gray-750 dark:text-slate-350">
                      {trendCalculations.tableData.map((row, idx) => (
                        <tr
                          key={idx}
                          className="hover:bg-gray-50/50 dark:hover:bg-slate-850/30"
                        >
                          <td className="px-5 py-3 font-semibold">
                            {row.date}
                          </td>
                          <td className="px-5 py-3">
                            {row.txn === "IN" ||
                              row.txn === "Transfer IN" ||
                              row.txn === "Job Card" ? (
                              <span className="inline-flex px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 dark:bg-teal-950/60 dark:text-teal-400 font-bold">
                                {row.txn}
                              </span>
                            ) : row.txn === "OUT" ||
                              row.txn === "Transfer OUT" ? (
                              <span className="inline-flex px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-400 font-bold">
                                {row.txn}
                              </span>
                            ) : row.txn === "Rejected" || row.txn === "Recycle" ? (
                              <span className="inline-flex px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400 font-bold">
                                Rejected
                              </span>
                            ) : (
                              <span className="text-gray-400">{row.txn}</span>
                            )}
                          </td>
                          <td
                            className={`px-5 py-3 font-bold ${row.txn === "Rejected" || row.txn === "Recycle"
                                ? "text-amber-600 dark:text-amber-400"
                                : row.qty.startsWith("+")
                                  ? "text-teal-600 dark:text-teal-400"
                                  : row.qty.startsWith("-")
                                    ? "text-rose-600 dark:text-rose-400"
                                    : ""
                              }`}
                          >
                            {row.qty}
                          </td>
                          <td className="px-5 py-3 text-gray-900 dark:text-white font-extrabold text-sm">
                            {row.closing.toLocaleString()}
                          </td>
                          <td className="px-5 py-3 font-mono">{row.ref}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div className="flex justify-end border-t border-gray-150 dark:border-slate-800 px-6 py-4">
              <button
                onClick={() =>
                  setTrendModal({ isOpen: false, sku: "", division: "" })
                }
                className="px-6 py-2.5 text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs cursor-pointer active:scale-95 transition-transform"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POST TRANSACTION MODAL */}
      {isTxnModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-lg sm:max-w-2xl shadow-2xl animate-scale-up">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4">
              <h3 className="text-lg font-black text-gray-900 dark:text-white">
                Inventory Transaction
              </h3>
              <button
                onClick={() => setIsTxnModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handlePostTransaction}>
              <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Firm (Division) — always first, full width */}
                  <div className="flex flex-col gap-1.5 col-span-2 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Firm *
                    </label>
                    <CustomSelect
                      required
                      value={txnFormDivision}
                      onChange={(val) => {
                        setTxnFormDivision(val);
                        setTxnFormLocation("");
                      }}
                      options={[
                        ...new Set(
                          locations
                            .map((l) => l.division)
                            .filter(Boolean)
                            .filter((div) => isDivisionAllowed(div, allowedDivisions)),
                        ),
                      ]}
                      placeholder="Select a firm..."
                    />
                  </div>

                  {/* Movement Type */}
                  <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Movement Type *
                    </label>
                    <CustomSelect
                      required
                      value={txnFormType}
                      onChange={(val) => {
                        setTxnFormType(val);
                        setTxnFormSku("");
                        setTxnFormLocation("");
                      }}
                      options={[
                        { label: "IN (Stock Inward / Receipt)", value: "IN" },
                        { label: "OUT (Stock Outward / Issue)", value: "OUT" },
                        { label: "Job Card", value: "Job card" },
                      ]}
                      placeholder="Select movement type..."
                    />
                  </div>

                  {/* Date Fields depending on Movement Type */}
                  {txnFormType === "IN" ? (
                    <>
                      {/* Billing Date */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Billing Date *
                        </label>
                        <input
                          type="datetime-local"
                          required
                          value={txnFormBillingDate}
                          onChange={(e) =>
                            setTxnFormBillingDate(e.target.value)
                          }
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Receiving Date */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Receiving Date *
                        </label>
                        <input
                          type="datetime-local"
                          required
                          value={txnFormReceivingDate}
                          onChange={(e) =>
                            setTxnFormReceivingDate(e.target.value)
                          }
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Party Name */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Party Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormPartyName}
                          onChange={(e) => setTxnFormPartyName(e.target.value)}
                          placeholder="e.g. Supplier / Vendor Name"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Invoice Number */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Invoice Number *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormInvoiceNo}
                          onChange={(e) => setTxnFormInvoiceNo(e.target.value)}
                          placeholder="e.g. INV-9901"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Dynamic IN Materials Section */}
                      <div className="col-span-2 flex flex-col gap-3 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Materials Received *
                        </label>
                        <div className="flex flex-col gap-3">
                          {txnFormInItems.map((row, index) => (
                            <div
                              key={index}
                              className="grid grid-cols-12 gap-3 items-end"
                            >
                              {/* Select Material */}
                              <div className="flex flex-col gap-1.5 col-span-5 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Material {index + 1}
                                </label>
                                <CustomSelect
                                  required
                                  value={row.sku}
                                  onChange={(val) =>
                                    handleInItemChange(index, "sku", val)
                                  }
                                  options={allActiveMaterials.map((m) => ({
                                    label:
                                      m.name &&
                                        m.name.toLowerCase().trim() !==
                                        m.sku.toLowerCase().trim()
                                        ? `${m.sku} - ${m.name}`
                                        : m.sku,
                                    value: m.sku,
                                  }))}
                                  placeholder="Select a material SKU..."
                                />
                              </div>

                              {/* Material Quantity */}
                              <div className="flex flex-col gap-1.5 col-span-3 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Qty *
                                </label>
                                <input
                                  type="number"
                                  required
                                  min="0.0001"
                                  step="any"
                                  value={row.qty}
                                  onChange={(e) =>
                                    handleInItemChange(
                                      index,
                                      "qty",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 100"
                                  className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              {/* UOM (read-only, auto-filled from material) */}
                              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  UOM
                                </label>
                                <div className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-100 dark:bg-slate-900 text-sm font-bold text-indigo-700 dark:text-indigo-300 cursor-not-allowed min-h-[38px] flex items-center">
                                  {row.unit || <span className="text-gray-400 font-normal text-xs">—</span>}
                                </div>
                              </div>

                              {/* Action Buttons */}
                              <div className="col-span-2 flex items-center justify-start gap-1 pb-1">
                                {txnFormInItems.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleRemoveInItemRow(index)
                                    }
                                    className="p-2 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded-lg transition-colors duration-150 cursor-pointer"
                                    title="Remove Material"
                                  >
                                    <svg
                                      className="w-5 h-5"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M20 12H4"
                                      />
                                    </svg>
                                  </button>
                                )}

                                {index === txnFormInItems.length - 1 && (
                                  <button
                                    type="button"
                                    onClick={handleAddInItemRow}
                                    className="p-2 text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 rounded-lg transition-colors duration-150 cursor-pointer"
                                    title="Add Material"
                                  >
                                    <svg
                                      className="w-5 h-5"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 4v16m8-8H4"
                                      />
                                    </svg>
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : txnFormType === "OUT" ? (
                    <>
                      {/* Transaction Date */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Transaction Date *
                        </label>
                        <input
                          type="date"
                          required
                          value={txnFormDate}
                          onChange={(e) => setTxnFormDate(e.target.value)}
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Party Name */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Party Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormPartyName}
                          onChange={(e) => setTxnFormPartyName(e.target.value)}
                          placeholder="e.g. Customer / Vendor Name"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Destination */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Destination *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormDestination}
                          onChange={(e) =>
                            setTxnFormDestination(e.target.value)
                          }
                          placeholder="e.g. Location / Plant B"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Challan Number */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Challan Number *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormChallanNo}
                          onChange={(e) => setTxnFormChallanNo(e.target.value)}
                          placeholder="e.g. CH-2026-001"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Invoice Number */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Invoice Number *
                        </label>
                        <input
                          type="text"
                          required
                          value={txnFormInvoiceNo}
                          onChange={(e) => setTxnFormInvoiceNo(e.target.value)}
                          placeholder="e.g. INV-9901"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Vehicle Number (Optional) */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Vehicle Number
                        </label>
                        <input
                          type="text"
                          value={txnFormVehicleNo}
                          onChange={(e) => setTxnFormVehicleNo(e.target.value)}
                          placeholder="e.g. MH-12-AB-1234 (Optional)"
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Dynamic OUT Materials Section */}
                      <div className="col-span-2 flex flex-col gap-3 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Materials Issued *
                        </label>
                        <div className="flex flex-col gap-3">
                          {txnFormOutItems.map((row, index) => (
                            <div
                              key={index}
                              className="grid grid-cols-12 gap-3 items-end"
                            >
                              {/* Select Material */}
                              <div className="flex flex-col gap-1.5 col-span-5 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Material {index + 1}
                                </label>
                                <CustomSelect
                                  required
                                  value={row.sku}
                                  onChange={(val) =>
                                    handleOutItemChange(index, "sku", val)
                                  }
                                  options={allActiveMaterials.map((m) => ({
                                    label:
                                      m.name &&
                                        m.name.toLowerCase().trim() !==
                                        m.sku.toLowerCase().trim()
                                        ? `${m.sku} - ${m.name}`
                                        : m.sku,
                                    value: m.sku,
                                  }))}
                                  placeholder="Select a material SKU..."
                                />
                              </div>

                              {/* Material Quantity */}
                              <div className="flex flex-col gap-1.5 col-span-3 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Qty *
                                </label>
                                <input
                                  type="number"
                                  required
                                  min="0.0001"
                                  step="any"
                                  value={row.qty}
                                  onChange={(e) =>
                                    handleOutItemChange(
                                      index,
                                      "qty",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 100"
                                  className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              {/* UOM (read-only, auto-filled from material) */}
                              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  UOM
                                </label>
                                <div className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-100 dark:bg-slate-900 text-sm font-bold text-indigo-700 dark:text-indigo-300 cursor-not-allowed min-h-[38px] flex items-center">
                                  {row.unit || <span className="text-gray-400 font-normal text-xs">—</span>}
                                </div>
                              </div>

                              {/* Action Buttons */}
                              <div className="col-span-2 flex items-center justify-start gap-1 pb-1">
                                {txnFormOutItems.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleRemoveOutItemRow(index)
                                    }
                                    className="p-2 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded-lg transition-colors duration-150 cursor-pointer"
                                    title="Remove Material"
                                  >
                                    <svg
                                      className="w-5 h-5"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M20 12H4"
                                      />
                                    </svg>
                                  </button>
                                )}

                                {index === txnFormOutItems.length - 1 && (
                                  <button
                                    type="button"
                                    onClick={handleAddOutItemRow}
                                    className="p-2 text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 rounded-lg transition-colors duration-150 cursor-pointer"
                                    title="Add Material"
                                  >
                                    <svg
                                      className="w-5 h-5"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 4v16m8-8H4"
                                      />
                                    </svg>
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Transaction Date (Job Card) */}
                      <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Transaction Date *
                        </label>
                        <input
                          type="date"
                          required
                          value={txnFormDate}
                          onChange={(e) => setTxnFormDate(e.target.value)}
                          className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      {/* Finished Goods Category */}
                      <div className="flex flex-col gap-1.5 col-span-2 text-left">
                        <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                          Finished Goods Category *
                        </label>
                        <CustomSelect
                          required
                          value={txnFormFgCategory}
                          onChange={(val) => setTxnFormFgCategory(val)}
                          options={fgCategories}
                          placeholder="Select Finished Goods Category..."
                        />
                      </div>

                      {/* Batch Detail Sections */}
                      <div className="col-span-2 flex flex-col gap-4">
                        {txnFormBatches.map((batch, batchIdx) => (
                          <div
                            key={batchIdx}
                            className="p-4 border border-gray-200 dark:border-slate-800 rounded-2xl bg-gray-50/50 dark:bg-slate-950/40 space-y-3 text-left"
                          >
                            <div className="flex items-center justify-between border-b border-gray-200 dark:border-slate-800 pb-2">
                              <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                                Batch Detail {batchIdx + 1}
                              </span>
                              <div className="flex items-center gap-2">
                                {txnFormBatches.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveBatch(batchIdx)}
                                    className="p-1 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded-md transition-colors cursor-pointer"
                                    title="Remove Batch"
                                  >
                                    <X size={16} />
                                  </button>
                                )}
                                {batchIdx === txnFormBatches.length - 1 && (
                                  <button
                                    type="button"
                                    onClick={handleAddBatch}
                                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 rounded-lg transition-colors cursor-pointer"
                                    title="Add Batch"
                                  >
                                    <Plus size={14} /> Add Batch
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* SKU / Material and Quantity grouped with + / - buttons */}
                            <div className="flex flex-col gap-3">
                              {batch.materials.map((matRow, matIdx) => (
                                <div
                                  key={matIdx}
                                  className="grid grid-cols-12 gap-3 items-end"
                                >
                                  {/* SKU / Material Dropdown */}
                                  <div className="flex flex-col gap-1.5 col-span-4 text-left">
                                    <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                      SKU / Material {matIdx + 1} *
                                    </label>
                                    <CustomSelect
                                      required
                                      value={matRow.sku}
                                      onChange={(val) =>
                                        handleBatchMaterialChange(
                                          batchIdx,
                                          matIdx,
                                          "sku",
                                          val,
                                        )
                                      }
                                      options={allActiveRawMaterials.map((m) => ({
                                        label:
                                          m.name &&
                                            m.name.toLowerCase().trim() !==
                                            m.sku.toLowerCase().trim()
                                            ? `${m.sku} - ${m.name}`
                                            : m.sku,
                                        value: m.sku,
                                      }))}
                                      placeholder="Select SKU / Material..."
                                    />
                                  </div>

                                  {/* Quantity */}
                                  <div className="flex flex-col gap-1.5 col-span-4 text-left">
                                    <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                      Qty *
                                    </label>
                                    <input
                                      type="number"
                                      required
                                      min="0.0001"
                                      step="any"
                                      value={matRow.qty}
                                      onChange={(e) =>
                                        handleBatchMaterialChange(
                                          batchIdx,
                                          matIdx,
                                          "qty",
                                          e.target.value,
                                        )
                                      }
                                      placeholder="e.g. 100"
                                      className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                    />
                                  </div>

                                  {/* UOM (read-only, auto-filled from material) */}
                                  <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                    <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                      UOM
                                    </label>
                                    <div className="w-full px-3 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-100 dark:bg-slate-900 text-sm font-bold text-indigo-700 dark:text-indigo-300 cursor-not-allowed min-h-[38px] flex items-center">
                                      {allActiveRawMaterials.find((m) => m.sku === matRow.sku)?.unit || <span className="text-gray-400 font-normal text-xs">—</span>}
                                    </div>
                                  </div>

                                  {/* Action Buttons (+ / -) */}
                                  <div className="col-span-2 flex items-center justify-start gap-1 pb-1">
                                    {batch.materials.length > 1 && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleRemoveBatchMaterial(
                                            batchIdx,
                                            matIdx,
                                          )
                                        }
                                        className="p-2 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer"
                                        title="Remove Material Row"
                                      >
                                        <svg
                                          className="w-4 h-4"
                                          fill="none"
                                          stroke="currentColor"
                                          viewBox="0 0 24 24"
                                        >
                                          <path
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth="2"
                                            d="M20 12H4"
                                          />
                                        </svg>
                                      </button>
                                    )}

                                    {matIdx === batch.materials.length - 1 && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleAddBatchMaterial(batchIdx)
                                        }
                                        className="p-2 text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 rounded-lg transition-colors cursor-pointer"
                                        title="Add Material Row"
                                      >
                                        <svg
                                          className="w-4 h-4"
                                          fill="none"
                                          stroke="currentColor"
                                          viewBox="0 0 24 24"
                                        >
                                          <path
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth="2"
                                            d="M12 4v16m8-8H4"
                                          />
                                        </svg>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>

                            {/* Batch Textbox Fields: No. of Batches, Remaining Batches, Remaining Material */}
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                              <div className="flex flex-col gap-1 text-left">
                                <label className="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase">
                                  No. of Batches
                                </label>
                                <input
                                  type="text"
                                  value={batch.numBatches}
                                  onChange={(e) =>
                                    handleBatchFieldChange(
                                      batchIdx,
                                      "numBatches",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 5"
                                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              <div className="flex flex-col gap-1 text-left">
                                <label className="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase">
                                  Remaining Batches
                                </label>
                                <input
                                  type="text"
                                  value={batch.remainingBatches}
                                  onChange={(e) =>
                                    handleBatchFieldChange(
                                      batchIdx,
                                      "remainingBatches",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 4"
                                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              <div className="flex flex-col gap-1 text-left">
                                <label className="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase">
                                  Remaining Material
                                </label>
                                <input
                                  type="text"
                                  value={batch.remainingMaterial}
                                  onChange={(e) =>
                                    handleBatchFieldChange(
                                      batchIdx,
                                      "remainingMaterial",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 200 KG"
                                  className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-xs text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* TOTAL PRODUCTION Section Header & Multi-Item Fields */}
                      <div className="col-span-2 border-t border-gray-200 dark:border-slate-800 pt-3 flex flex-col gap-3">
                        <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider text-left">
                          TOTAL PRODUCTION
                        </span>

                        {/* Multi-Row Finished Goods */}
                        <div className="flex flex-col gap-3">
                          {txnFormFgItems.map((fgRow, fgIdx) => (
                            <div
                              key={fgIdx}
                              className="grid grid-cols-12 gap-3 items-end"
                            >
                              {/* Finished Goods SKU Code */}
                              <div className="flex flex-col gap-1.5 col-span-4 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Finished Goods SKU{" "}
                                  {txnFormFgItems.length > 1 ? fgIdx + 1 : ""} *
                                </label>
                                <CustomSelect
                                  required
                                  value={fgRow.sku}
                                  onChange={(val) =>
                                    handleFgItemChange(fgIdx, "sku", val)
                                  }
                                  options={allActiveFGMaterials.map((m) => ({
                                    label:
                                      m.name &&
                                        m.name.toLowerCase().trim() !==
                                        m.sku.toLowerCase().trim()
                                        ? `${m.sku} - ${m.name}`
                                        : m.sku,
                                    value: m.sku,
                                  }))}
                                  placeholder="Select Finished Goods SKU..."
                                />
                              </div>

                              {/* Finished Goods Quantity */}
                              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Qty *
                                </label>
                                <input
                                  type="number"
                                  required
                                  min="0"
                                  step="any"
                                  value={fgRow.qty}
                                  onChange={(e) =>
                                    handleFgItemChange(
                                      fgIdx,
                                      "qty",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 50"
                                  className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              {/* Scraps Quantity */}
                              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  Scraps
                                </label>
                                <input
                                  type="number"
                                  min="0"
                                  step="any"
                                  value={fgRow.scraps}
                                  onChange={(e) =>
                                    handleFgItemChange(
                                      fgIdx,
                                      "scraps",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="e.g. 5"
                                  className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>

                              {/* UOM (read-only, auto-filled from material) */}
                              <div className="flex flex-col gap-1.5 col-span-2 text-left">
                                <label className="text-[10px] font-bold text-gray-400 dark:text-slate-500 uppercase">
                                  UOM
                                </label>
                                <div className="w-full px-3 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-100 dark:bg-slate-900 text-sm font-bold text-indigo-700 dark:text-indigo-300 cursor-not-allowed min-h-[38px] flex items-center">
                                  {allActiveFGMaterials.find((m) => m.sku === fgRow.sku)?.unit || <span className="text-gray-400 font-normal text-xs">—</span>}
                                </div>
                              </div>

                              {/* Action Buttons (+ / -) */}
                              <div className="col-span-2 flex items-center justify-start gap-1 pb-1">
                                {txnFormFgItems.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveFgItemRow(fgIdx)}
                                    className="p-2 text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer"
                                    title="Remove Finished Goods Row"
                                  >
                                    <svg
                                      className="w-4 h-4"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M20 12H4"
                                      />
                                    </svg>
                                  </button>
                                )}

                                {fgIdx === txnFormFgItems.length - 1 && (
                                  <button
                                    type="button"
                                    onClick={handleAddFgItemRow}
                                    className="p-2 text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 rounded-lg transition-colors cursor-pointer"
                                    title="Add Finished Goods Row"
                                  >
                                    <svg
                                      className="w-4 h-4"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth="2"
                                        d="M12 4v16m8-8H4"
                                      />
                                    </svg>
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Break line after section TOTAL PRODUCTION */}
                      <div className="col-span-2 border-b border-gray-200 dark:border-slate-800 my-2" />
                    </>
                  )}

                  {/* Storage Location */}
                  <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Storage Location *
                    </label>
                    <CustomSelect
                      required
                      value={txnFormLocation}
                      onChange={(val) => setTxnFormLocation(val)}
                      options={[
                        ...new Set([
                          ...locations
                            .filter(
                              (l) =>
                                !txnFormDivision ||
                                l.division === txnFormDivision,
                            )
                            .map((l) => l.location),
                          txnFormLocation,
                        ]),
                      ].filter(Boolean)}
                      placeholder="Select a storage location..."
                    />
                  </div>

                  {/* Reference Number */}
                  <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Reference Number (PO / Invoice / WO)
                    </label>
                    <input
                      type="text"
                      value={txnFormRef}
                      onChange={(e) => setTxnFormRef(e.target.value)}
                      placeholder="e.g. PO-7491"
                      className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  {/* Operator Name */}
                  <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Operator Name
                    </label>
                    <div className="px-3.5 py-2.5 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-100 dark:bg-slate-950/60 text-sm font-semibold text-gray-700 dark:text-slate-350">
                      {activeUser.name} ({activeUser.role})
                    </div>
                  </div>

                  {/* Remarks */}
                  <div className="flex flex-col gap-1.5 col-span-2 text-left">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Remarks
                    </label>
                    <textarea
                      rows="2"
                      value={txnFormRemarks}
                      onChange={(e) => setTxnFormRemarks(e.target.value)}
                      placeholder="Optional details..."
                      className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 border-t border-gray-150 dark:border-slate-800 px-6 py-4 bg-gray-50 dark:bg-slate-950 rounded-b-3xl">
                <button
                  type="button"
                  onClick={() => setIsTxnModalOpen(false)}
                  className="px-5 py-2 text-sm font-bold bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-350 border border-gray-200 dark:border-slate-800 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!canWrite}
                  title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                  className="px-5 py-2 text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Post Transaction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Material Movement Report */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-5xl shadow-2xl animate-scale-up flex flex-col max-h-[90vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4 bg-gray-50/50 dark:bg-slate-955/50">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400">
                  <FileText size={20} />
                </div>
                <div>
                  <h3 className="text-base font-black text-gray-900 dark:text-white">
                    Material Movement Report
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-slate-400">
                    Transaction movement counts (IN, OUT, Job Card) sourced from
                    transactions list
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Top Summary KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
                  <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block mb-1">
                    Total Materials
                  </span>
                  <span className="text-2xl font-black text-indigo-900 dark:text-indigo-100">
                    {filteredReportRows.length}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/30 border border-teal-100 dark:border-teal-900/50">
                  <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider block mb-1">
                    Total IN Movements
                  </span>
                  <span className="text-2xl font-black text-teal-900 dark:text-teal-100">
                    {filteredReportRows.reduce((sum, r) => sum + r.inCount, 0)}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/50">
                  <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider block mb-1">
                    Total OUT Movements
                  </span>
                  <span className="text-2xl font-black text-rose-900 dark:text-rose-100">
                    {filteredReportRows.reduce((sum, r) => sum + r.outCount, 0)}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-purple-50/60 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/50">
                  <span className="text-[10px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider block mb-1">
                    Total Job Cards
                  </span>
                  <span className="text-2xl font-black text-purple-900 dark:text-purple-100">
                    {filteredReportRows.reduce(
                      (sum, r) => sum + r.jobCardCount,
                      0,
                    )}
                  </span>
                </div>
              </div>

              {/* Toolbar: Search, Filter, Date Range, Export */}
              <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-gray-50 dark:bg-slate-955/50 border border-gray-200 dark:border-slate-800 rounded-2xl p-3">
                <div className="flex flex-wrap items-center gap-2.5 flex-1">
                  <div className="relative min-w-[180px] flex-1 sm:flex-initial">
                    <Search
                      className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                      size={16}
                    />
                    <input
                      type="text"
                      value={reportSearch}
                      onChange={(e) => setReportSearch(e.target.value)}
                      placeholder="Search SKU or material name..."
                      className="w-full pl-9 pr-3 py-1.5 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 outline-hidden"
                    />
                  </div>

                  <select
                    value={reportTypeFilter}
                    onChange={(e) => setReportTypeFilter(e.target.value)}
                    className="px-3 py-1.5 border border-gray-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 text-sm text-gray-900 dark:text-white cursor-pointer"
                  >
                    <option value="">All Types</option>
                    <option value="RM">Raw Material</option>
                    <option value="FG">Finished Goods</option>
                  </select>

                  <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl px-2.5 py-1.5">
                    <span className="text-[10px] font-bold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
                      From
                    </span>
                    <input
                      type="date"
                      value={reportFromDate}
                      onChange={(e) => setReportFromDate(e.target.value)}
                      className="text-xs bg-transparent text-gray-900 dark:text-white outline-hidden cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-xl px-2.5 py-1.5">
                    <span className="text-[10px] font-bold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
                      To
                    </span>
                    <input
                      type="date"
                      value={reportToDate}
                      onChange={(e) => setReportToDate(e.target.value)}
                      className="text-xs bg-transparent text-gray-900 dark:text-white outline-hidden cursor-pointer"
                    />
                  </div>

                  {(reportFromDate || reportToDate) && (
                    <button
                      type="button"
                      onClick={() => {
                        setReportFromDate("");
                        setReportToDate("");
                      }}
                      className="px-2.5 py-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl cursor-pointer border border-rose-200 dark:border-rose-900/50 transition-colors"
                      title="Clear Date Filters"
                    >
                      Clear Dates
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleExportReportCSV}
                  className="flex items-center justify-center gap-1.5 px-4 py-1.5 border border-gray-200 dark:border-slate-800 rounded-xl text-xs font-bold text-gray-700 dark:text-slate-300 bg-white dark:bg-slate-900 hover:border-purple-500 cursor-pointer transition-colors"
                >
                  <FileSpreadsheet size={14} />
                  Export CSV
                </button>
              </div>

              {/* Table */}
              <div className="overflow-x-auto border border-gray-200 dark:border-slate-800 rounded-2xl">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-slate-955 border-b border-gray-200 dark:border-slate-800 text-gray-500 dark:text-slate-400 font-bold uppercase tracking-wider">
                      <th className="px-4 py-3">SKU</th>
                      <th className="px-4 py-3">Sub Category</th>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3 text-center">
                        Transaction Date
                      </th>
                      <th className="px-4 py-3 text-center">IN</th>
                      <th className="px-4 py-3 text-center">OUT</th>
                      <th className="px-4 py-3 text-center">JOB CARD</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-150 dark:divide-slate-800/60 text-gray-700 dark:text-slate-350">
                    {filteredReportRows.length === 0 ? (
                      <tr>
                        <td
                          colSpan={7}
                          className="text-center py-8 text-gray-400"
                        >
                          No matching materials found.
                        </td>
                      </tr>
                    ) : (
                      filteredReportRows.map((r) => (
                        <tr
                          key={r.sku}
                          className="hover:bg-gray-50/50 dark:hover:bg-slate-850/20"
                        >
                          <td className="px-4 py-3 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                            {r.sku}
                          </td>
                          <td className="px-4 py-3 font-bold text-gray-900 dark:text-white whitespace-nowrap">
                            {r.name}
                          </td>
                          <td className="px-4 py-3">
                            {r.rawType === "FG" ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-400">
                                Finished Goods
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400">
                                Raw Material
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center font-mono text-gray-600 dark:text-slate-400">
                            {r.txnDate}
                          </td>
                          <td className="px-4 py-3 text-center font-bold text-teal-600 dark:text-teal-400">
                            {r.inCount}
                          </td>
                          <td className="px-4 py-3 text-center font-bold text-rose-600 dark:text-rose-400">
                            {r.outCount}
                          </td>
                          <td className="px-4 py-3 text-center font-bold text-purple-600 dark:text-purple-400">
                            {r.jobCardCount}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end border-t border-gray-150 dark:border-slate-800 px-6 py-3 bg-gray-50/50 dark:bg-slate-950/50">
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="px-5 py-2 bg-gray-200 dark:bg-slate-800 hover:bg-gray-300 dark:hover:bg-slate-700 text-gray-800 dark:text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Add / Edit Material */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl animate-scale-up max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between border-b border-gray-150 dark:border-slate-800 px-6 py-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                {modalMode === "edit" ? "Edit Material" : "Add New Material"}
              </h3>
              <div className="flex items-center gap-2">
                {modalMode === "add" && !isViewer && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        handleDownloadModalTemplate(formMaterialType)
                      }
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 dark:border-slate-700 rounded-xl text-xs font-bold text-gray-700 dark:text-slate-300 hover:border-indigo-500 bg-white dark:bg-slate-800 cursor-pointer transition-all"
                      title={`Download ${formMaterialType === "FG" ? "Finished Goods" : "Raw Material"} CSV Template`}
                    >
                      <Download size={13} />
                      Template
                    </button>
                    <label className="flex items-center gap-1.5 px-3 py-1.5 border border-indigo-200 dark:border-indigo-900/60 rounded-xl text-xs font-bold text-indigo-650 dark:text-indigo-400 bg-indigo-50/50 hover:bg-indigo-50 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 cursor-pointer active:scale-95 transition-all">
                      <Upload size={13} />
                      Import CSV
                      <input
                        type="file"
                        accept=".csv"
                        onChange={(e) => handleImportFile(e, formMaterialType)}
                        disabled={!canWrite}
                        className="hidden"
                      />
                    </label>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-white p-1 rounded-xl cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            <form
              onSubmit={handleSave}
              className="flex flex-col flex-1 overflow-hidden"
            >
              <div className="p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
                {/* 1. Firm Division */}
                <div className="sm:col-span-2 flex flex-col gap-1.5 text-left">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Select Firm
                  </label>
                  <select
                    value={formDivision}
                    onChange={(e) => {
                      const nextDiv = e.target.value;
                      setFormDivision(nextDiv);
                      if (nextDiv) {
                        const isLocInDiv = locations.some(
                          (l) =>
                            l.location === formLocation &&
                            l.division === nextDiv,
                        );
                        if (!isLocInDiv) {
                          setFormLocation("");
                        }
                      }
                    }}
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white cursor-pointer focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">Select firm...</option>
                    {userAllowedDivisionsList.map((d) => (
                      <option key={d.id || d.name} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Material Type Selector (R.M vs F.G) */}
                <div className="sm:col-span-2 flex flex-col gap-1.5 text-left">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Material Type *
                  </label>
                  <div className="grid grid-cols-2 gap-2 p-1 bg-gray-100 dark:bg-slate-950 rounded-xl border border-gray-200 dark:border-slate-800">
                    <button
                      type="button"
                      disabled={modalMode === "edit"}
                      onClick={() => {
                        if (modalMode === "edit") return;
                        setFormMaterialType("RM");
                        if (modalMode !== "edit") {
                          setFormCategory("");
                          setFormSubCategory("");
                          setFormSku("");
                        }
                      }}
                      className={`py-2 px-4 text-xs font-bold rounded-lg transition-all ${modalMode === "edit" ? "cursor-not-allowed" : "cursor-pointer"
                        } ${formMaterialType === "RM"
                          ? `bg-indigo-600 text-white shadow-xs ${modalMode === "edit" ? "opacity-90" : ""}`
                          : `text-gray-600 dark:text-slate-400 ${modalMode === "edit" ? "opacity-40" : "hover:text-gray-900 dark:hover:text-white"}`
                        }`}
                    >
                      R.M (Raw Material)
                    </button>
                    <button
                      type="button"
                      disabled={modalMode === "edit"}
                      onClick={() => {
                        if (modalMode === "edit") return;
                        setFormMaterialType("FG");
                        if (modalMode !== "edit") {
                          setFormCategory("");
                          setFormSubCategory("");
                          setFormSku("");
                        }
                      }}
                      className={`py-2 px-4 text-xs font-bold rounded-lg transition-all ${modalMode === "edit" ? "cursor-not-allowed" : "cursor-pointer"
                        } ${formMaterialType === "FG"
                          ? `bg-indigo-600 text-white shadow-xs ${modalMode === "edit" ? "opacity-90" : ""}`
                          : `text-gray-600 dark:text-slate-400 ${modalMode === "edit" ? "opacity-40" : "hover:text-gray-900 dark:hover:text-white"}`
                        }`}
                    >
                      F.G (Finished Goods)
                    </button>
                  </div>
                </div>

                {/* 3. Material (RM) / Category (FG) */}
                <div className="flex flex-col gap-1.5 text-left relative">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    {formMaterialType === "RM" ? "Material *" : "Category *"}
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      disabled={modalMode === "edit"}
                      value={formCategory}
                      onChange={(e) => {
                        if (modalMode === "edit") return;
                        setFormCategory(e.target.value);
                        setShowCategoryDropdown(true);
                      }}
                      onFocus={() => {
                        if (modalMode !== "edit") setShowCategoryDropdown(true);
                      }}
                      onBlur={() =>
                        setTimeout(() => setShowCategoryDropdown(false), 200)
                      }
                      placeholder={
                        formMaterialType === "RM"
                          ? "Select or type Raw Material Name..."
                          : "e.g. Door frames, Panels, Louvers"
                      }
                      className="w-full px-3.5 py-2 pr-10 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-100 dark:disabled:bg-slate-900/60 focus:outline-hidden"
                    />
                    {modalMode !== "edit" && (
                      <button
                        type="button"
                        tabIndex="-1"
                        onClick={() =>
                          setShowCategoryDropdown(!showCategoryDropdown)
                        }
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                      >
                        <ChevronDown
                          size={16}
                          className={`transition-transform duration-200 ${showCategoryDropdown ? "rotate-180" : ""}`}
                        />
                      </button>
                    )}
                  </div>

                  {modalMode !== "edit" &&
                    showCategoryDropdown &&
                    filteredCategorySuggestions.length > 0 && (
                      <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-slate-955 border border-gray-200 dark:border-slate-800 rounded-xl shadow-xl max-h-48 overflow-y-auto z-50 divide-y divide-gray-100 dark:divide-slate-800/40">
                        {filteredCategorySuggestions.map((c) => {
                          const catText =
                            typeof c === "string"
                              ? c
                              : c && typeof c === "object"
                                ? c.name || c.sku || ""
                                : String(c);
                          return (
                            <div
                              key={catText}
                              onMouseDown={() => {
                                setFormCategory(catText);
                                if (formMaterialType === "RM") {
                                  const match = rmCatalogItems.find(
                                    (i) =>
                                      i.name.toLowerCase() ===
                                      catText.toLowerCase(),
                                  );
                                  if (match && match.sku) {
                                    setFormSku(match.sku);
                                  }
                                }
                                setShowCategoryDropdown(false);
                              }}
                              className="px-4 py-2 text-sm text-left text-gray-750 dark:text-slate-350 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-700 dark:hover:text-indigo-400 cursor-pointer transition-colors"
                            >
                              {catText}
                            </div>
                          );
                        })}
                      </div>
                    )}
                </div>

                {/* 4. Sub Category (Only for F.G) */}
                {formMaterialType === "FG" && (
                  <div className="flex flex-col gap-1.5 text-left relative">
                    <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                      Sub Category *
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        disabled={modalMode === "edit"}
                        value={formSubCategory}
                        onChange={(e) => {
                          if (modalMode === "edit") return;
                          setFormSubCategory(e.target.value);
                          setShowSubCategoryDropdown(true);
                        }}
                        onFocus={() => {
                          if (modalMode !== "edit") setShowSubCategoryDropdown(true);
                        }}
                        onBlur={() =>
                          setTimeout(
                            () => setShowSubCategoryDropdown(false),
                            200,
                          )
                        }
                        placeholder="e.g. FG78, FG95"
                        className="w-full px-3.5 py-2 pr-10 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-100 dark:disabled:bg-slate-900/60 focus:outline-hidden"
                      />
                      {modalMode !== "edit" && (
                        <button
                          type="button"
                          tabIndex="-1"
                          onClick={() =>
                            setShowSubCategoryDropdown(!showSubCategoryDropdown)
                          }
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                        >
                          <ChevronDown
                            size={16}
                            className={`transition-transform duration-200 ${showSubCategoryDropdown ? "rotate-180" : ""}`}
                          />
                        </button>
                      )}
                    </div>

                    {modalMode !== "edit" &&
                      showSubCategoryDropdown &&
                      filteredSubCategorySuggestions.length > 0 && (
                        <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-slate-955 border border-gray-200 dark:border-slate-800 rounded-xl shadow-xl max-h-48 overflow-y-auto z-50 divide-y divide-gray-100 dark:divide-slate-800/40">
                          {filteredSubCategorySuggestions.map((fg) => {
                            const fgText =
                              typeof fg === "string"
                                ? fg
                                : fg && typeof fg === "object"
                                  ? fg.name || fg.sku || ""
                                  : String(fg);
                            return (
                              <div
                                key={fgText}
                                onMouseDown={() => {
                                  setFormSubCategory(fgText);
                                  const match = fgCatalogItems.find(
                                    (i) =>
                                      i.name.toLowerCase() ===
                                      fgText.toLowerCase(),
                                  );
                                  if (match) {
                                    if (match.sku)
                                      setFormSku(match.sku);
                                    if (match.category)
                                      setFormCategory(match.category);
                                  }
                                  setShowSubCategoryDropdown(false);
                                }}
                                className="px-4 py-2 text-sm text-left text-gray-750 dark:text-slate-350 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-700 dark:hover:text-indigo-400 cursor-pointer transition-colors"
                              >
                                {fgText}
                              </div>
                            );
                          })}
                        </div>
                      )}
                  </div>
                )}

                {/* 5. SKU Code (Searchable Combobox) */}
                <div
                  className={`${formMaterialType === "RM" ? "sm:col-span-1" : "sm:col-span-2"} flex flex-col gap-1.5 text-left relative`}
                >
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    SKU Code *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      disabled={modalMode === "edit"}
                      value={formSku}
                      onChange={(e) => {
                        if (modalMode === "edit") return;
                        setFormSku(e.target.value);
                        setShowSkuDropdown(true);
                      }}
                      onFocus={() => {
                        if (modalMode !== "edit") setShowSkuDropdown(true);
                      }}
                      onBlur={() =>
                        setTimeout(() => setShowSkuDropdown(false), 200)
                      }
                      placeholder={
                        formMaterialType === "RM"
                          ? "e.g. RM-001"
                          : "e.g. 001 (Black)"
                      }
                      className="w-full px-3.5 py-2 pr-10 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-100 dark:disabled:bg-slate-900/60 focus:outline-hidden font-mono"
                    />
                    {modalMode !== "edit" && (
                      <button
                        type="button"
                        tabIndex="-1"
                        onClick={() => setShowSkuDropdown(!showSkuDropdown)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                      >
                        <ChevronDown
                          size={16}
                          className={`transition-transform duration-200 ${showSkuDropdown ? "rotate-180" : ""}`}
                        />
                      </button>
                    )}
                  </div>

                  {showSkuDropdown &&
                    modalMode !== "edit" &&
                    filteredSkuSuggestions.length > 0 && (
                      <div className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-slate-955 border border-gray-200 dark:border-slate-800 rounded-xl shadow-xl max-h-48 overflow-y-auto z-50 divide-y divide-gray-100 dark:divide-slate-800/40">
                        {filteredSkuSuggestions.map((item) => {
                          const skuText =
                            typeof item.sku === "string"
                              ? item.sku
                              : String(item.sku || "");
                          const nameText =
                            typeof item.name === "string"
                              ? item.name
                              : item.name && typeof item.name === "object"
                                ? item.name.name || ""
                                : String(item.name || "");
                          return (
                            <div
                              key={skuText}
                              onMouseDown={() => {
                                setFormSku(skuText);
                                if (formMaterialType === "RM" && nameText) {
                                  setFormCategory(nameText);
                                } else if (
                                  formMaterialType === "FG" &&
                                  nameText
                                ) {
                                  setFormSubCategory(nameText);
                                  if (item.category) {
                                    const catStr =
                                      typeof item.category === "string"
                                        ? item.category
                                        : String(item.category || "");
                                    setFormCategory(catStr);
                                  }
                                }
                                if (item.unit)
                                  setFormUnit(
                                    typeof item.unit === "string"
                                      ? item.unit
                                      : String(item.unit),
                                  );
                                if (item.location)
                                  setFormLocation(
                                    typeof item.location === "string"
                                      ? item.location
                                      : String(item.location),
                                  );
                                if (item.division)
                                  setFormDivision(
                                    typeof item.division === "string"
                                      ? item.division
                                      : String(item.division),
                                  );
                                if (
                                  item.opening !== undefined &&
                                  item.opening !== null
                                )
                                  setFormOpening(item.opening);
                                if (item.adc !== undefined && item.adc !== null)
                                  setFormAdc(item.adc);
                                if (
                                  item.leadTime !== undefined &&
                                  item.leadTime !== null
                                )
                                  setFormLeadTime(item.leadTime);
                                if (
                                  item.safetyFactor !== undefined &&
                                  item.safetyFactor !== null
                                )
                                  setFormSafetyFactor(item.safetyFactor);
                                if (item.moq !== undefined && item.moq !== null)
                                  setFormMoq(item.moq);
                                if (item.supplierName)
                                  setFormSupplierName(
                                    typeof item.supplierName === "string"
                                      ? item.supplierName
                                      : String(item.supplierName),
                                  );
                                if (item.supplierCode)
                                  setFormSupplierCode(
                                    typeof item.supplierCode === "string"
                                      ? item.supplierCode
                                      : String(item.supplierCode),
                                  );
                                if (item.status)
                                  setFormStatus(
                                    typeof item.status === "string"
                                      ? item.status
                                      : String(item.status),
                                  );
                                setShowSkuDropdown(false);
                              }}
                              className="px-4 py-2.5 text-xs text-left text-gray-750 dark:text-slate-350 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-700 dark:hover:text-indigo-400 cursor-pointer transition-colors flex items-center justify-between"
                            >
                              <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                {skuText}
                              </span>
                              {nameText && (
                                <span className="text-gray-500 dark:text-slate-400 font-medium truncate max-w-[180px]">
                                  {nameText}
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Unit *
                  </label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white cursor-pointer focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  >
                    {units.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Storage Location
                  </label>
                  <select
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white cursor-pointer focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">Select storage location...</option>
                    {locations
                      .filter(
                        (l) => !formDivision || l.division === formDivision,
                      )
                      .map((l) => (
                        <option key={l.location} value={l.location}>
                          {l.location}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Opening Stock Balance
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formOpening}
                    onChange={(e) =>
                      setFormOpening(Number(e.target.value) || 0)
                    }
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Avg Daily Consumption (ADC) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formAdc}
                    onChange={(e) => setFormAdc(Number(e.target.value) || 0)}
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Lead Time (Days) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formLeadTime}
                    onChange={(e) =>
                      setFormLeadTime(Number(e.target.value) || 0)
                    }
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Safety Factor *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    required
                    value={formSafetyFactor}
                    onChange={(e) =>
                      setFormSafetyFactor(Number(e.target.value) || 0)
                    }
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    MOQ *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formMoq}
                    onChange={(e) => setFormMoq(Number(e.target.value) || 0)}
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Supplier Name
                  </label>
                  <input
                    type="text"
                    value={formSupplierName}
                    onChange={(e) => setFormSupplierName(e.target.value)}
                    placeholder="Tata Steel Ltd."
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Supplier Code
                  </label>
                  <input
                    type="text"
                    value={formSupplierCode}
                    onChange={(e) => setFormSupplierCode(e.target.value)}
                    placeholder="e.g. SUP-001"
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider">
                    Material Status
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value)}
                    className="px-3.5 py-2 border border-gray-200 dark:border-slate-800 rounded-xl bg-gray-50 dark:bg-slate-950 text-sm text-gray-900 dark:text-white cursor-pointer focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>

                {/* Auto Calculated Preview Fields */}
                <div className="sm:col-span-2 grid grid-cols-3 gap-3 pt-3 border-t border-gray-150 dark:border-slate-800">
                  <div className="bg-indigo-500/5 p-3 rounded-2xl border border-indigo-500/10">
                    <div className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-wider">
                      Safety Stock
                    </div>
                    <div className="text-sm font-black text-indigo-650 dark:text-indigo-300">
                      {modalSafetyStock.toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-amber-500/5 p-3 rounded-2xl border border-amber-500/10">
                    <div className="text-[10px] font-bold text-amber-500 dark:text-amber-400 uppercase tracking-wider">
                      Reorder Lvl
                    </div>
                    <div className="text-sm font-black text-amber-650 dark:text-amber-300">
                      {modalReorderLevel.toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-blue-500/5 p-3 rounded-2xl border border-blue-500/10">
                    <div className="text-[10px] font-bold text-blue-500 dark:text-blue-400 uppercase tracking-wider">
                      Max Level
                    </div>
                    <div className="text-sm font-black text-blue-650 dark:text-blue-300">
                      {modalMaxLevel.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 border-t border-gray-150 dark:border-slate-800 px-6 py-4 bg-gray-50 dark:bg-slate-950 rounded-b-3xl">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2 text-sm font-bold bg-white dark:bg-slate-900 text-gray-700 dark:text-slate-300 border border-gray-200 dark:border-slate-800 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!canWrite}
                  title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                  className="px-5 py-2 text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {modalMode === "edit"
                    ? "Save Specifications"
                    : "Add SKU Material"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CSV Import Preview Modal */}
      {csvPreviewModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-scale-up">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between bg-gray-50/50 dark:bg-slate-900/50">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                  <FileText size={22} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                    {csvPreviewModal.title}
                  </h3>
                  <p className="text-xs font-medium text-gray-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>
                      File:{" "}
                      <strong className="text-gray-700 dark:text-slate-300">
                        {csvPreviewModal.fileName}
                      </strong>
                    </span>
                    <span>•</span>
                    <span>
                      Total CSV Rows:{" "}
                      <strong className="text-gray-700 dark:text-slate-300">
                        {csvPreviewModal.validRows.length +
                          csvPreviewModal.skippedRows.length}
                      </strong>
                    </span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (csvPreviewModal.inputEvent?.target) {
                    csvPreviewModal.inputEvent.target.value = "";
                  }
                  setCsvPreviewModal((prev) => ({ ...prev, isOpen: false }));
                }}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-xl hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            {/* Metric Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 p-4 sm:px-6 bg-gray-50/40 dark:bg-slate-950/40 border-b border-gray-100 dark:border-slate-800">
              <div
                onClick={() =>
                  setCsvPreviewModal((p) => ({ ...p, activeTab: "valid" }))
                }
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${csvPreviewModal.activeTab === "valid"
                    ? "bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700/80 shadow-xs"
                    : "bg-white dark:bg-slate-900 border-gray-200/80 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-800"
                  }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl">
                    <CheckCircle2 size={20} />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-gray-500 dark:text-slate-400">
                      New Items to Add
                    </div>
                    <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                      {csvPreviewModal.validRows.length} rows
                    </div>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 rounded-lg">
                  Ready to Submit
                </span>
              </div>

              <div
                onClick={() =>
                  setCsvPreviewModal((p) => ({ ...p, activeTab: "skipped" }))
                }
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${csvPreviewModal.activeTab === "skipped"
                    ? "bg-amber-50/90 dark:bg-amber-950/40 border-amber-300 dark:border-amber-700/80 shadow-xs"
                    : "bg-white dark:bg-slate-900 border-gray-200/80 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-800"
                  }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl">
                    <AlertTriangle size={20} />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-gray-500 dark:text-slate-400">
                      Existing & Skipped Items
                    </div>
                    <div className="text-xl font-bold text-amber-600 dark:text-amber-400">
                      {csvPreviewModal.skippedRows.length} rows
                    </div>
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 rounded-lg">
                  {csvPreviewModal.skippedRows.filter((r) => r.isExisting).length > 0
                    ? `${csvPreviewModal.skippedRows.filter((r) => r.isExisting).length} Already Exist`
                    : "Will Be Skipped"}
                </span>
              </div>
            </div>

            {/* Validation Notice Banner for Existing / Skipped rows */}
            {csvPreviewModal.skippedRows.length > 0 && (
              <div className="mx-4 sm:mx-6 mt-4 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-start gap-3 text-xs">
                <AlertTriangle
                  size={18}
                  className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5"
                />
                <div className="flex-1">
                  <div className="font-bold text-amber-900 dark:text-amber-200">
                    Validation Notice:{" "}
                    {csvPreviewModal.skippedRows.filter((r) => r.isExisting).length > 0
                      ? `${csvPreviewModal.skippedRows.filter((r) => r.isExisting).length} item(s) already exist in your system.`
                      : `${csvPreviewModal.skippedRows.length} row(s) cannot be added.`}
                  </div>
                  <div className="text-amber-700 dark:text-amber-300 mt-0.5">
                    {csvPreviewModal.skippedRows.filter((r) => r.isExisting).length > 0 &&
                      "Items that already exist in your master catalog or stock records are highlighted under the Skipped tab and will be excluded to prevent duplication. "}
                    {csvPreviewModal.validRows.length > 0
                      ? `Only the ${csvPreviewModal.validRows.length} new unique item(s) listed under "Ready to Add" will be submitted to the inventory_master_materials table upon confirmation.`
                      : "No new unique items found in this file to submit."}
                  </div>
                </div>
              </div>
            )}

            {/* Sub-Header Bar with Tabs & Search */}
            <div className="p-4 sm:px-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900">
              <div className="flex items-center gap-1.5 bg-gray-100 dark:bg-slate-800/80 p-1 rounded-2xl self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() =>
                    setCsvPreviewModal((p) => ({ ...p, activeTab: "valid" }))
                  }
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${csvPreviewModal.activeTab === "valid"
                      ? "bg-white dark:bg-slate-900 text-gray-900 dark:text-white shadow-xs"
                      : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                    }`}
                >
                  <CheckCircle2 size={14} className="text-emerald-500" />
                  <span>
                    Ready to Add ({csvPreviewModal.validRows.length})
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setCsvPreviewModal((p) => ({ ...p, activeTab: "skipped" }))
                  }
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${csvPreviewModal.activeTab === "skipped"
                      ? "bg-white dark:bg-slate-900 text-gray-900 dark:text-white shadow-xs"
                      : "text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                    }`}
                >
                  <AlertTriangle size={14} className="text-amber-500" />
                  <span>
                    Skipped Rows ({csvPreviewModal.skippedRows.length})
                  </span>
                </button>
              </div>

              {/* Search Filter */}
              <div className="relative w-full sm:w-64">
                <Search
                  size={15}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  type="text"
                  value={csvPreviewModal.searchQuery}
                  onChange={(e) =>
                    setCsvPreviewModal((p) => ({
                      ...p,
                      searchQuery: e.target.value,
                    }))
                  }
                  placeholder="Search rows or reasons..."
                  className="w-full pl-9 pr-3.5 py-2 bg-gray-50 dark:bg-slate-950 border border-gray-200 dark:border-slate-800 rounded-xl text-xs font-medium text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Table Content */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 min-h-[250px] max-h-[420px] bg-gray-50/20 dark:bg-slate-950/20">
              {csvPreviewModal.activeTab === "valid" ? (
                (() => {
                  const filteredValid = csvPreviewModal.validRows.filter(
                    (r) =>
                      !csvPreviewModal.searchQuery ||
                      (r.name &&
                        r.name
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.sku &&
                        r.sku
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.category &&
                        r.category
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.division &&
                        r.division
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )),
                  );

                  if (filteredValid.length === 0) {
                    return (
                      <div className="py-12 text-center flex flex-col items-center justify-center">
                        <div className="p-3 bg-gray-100 dark:bg-slate-800 text-gray-400 rounded-2xl mb-3">
                          <Layers size={24} />
                        </div>
                        <p className="text-sm font-bold text-gray-600 dark:text-slate-300">
                          No valid rows to show
                        </p>
                        <p className="text-xs text-gray-400 dark:text-slate-500 mt-1 max-w-xs">
                          {csvPreviewModal.searchQuery
                            ? "No valid rows match your search query."
                            : "All rows in this CSV were skipped or rejected due to validation errors."}
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="overflow-x-auto rounded-2xl border border-gray-200/80 dark:border-slate-800 bg-white dark:bg-slate-900">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-gray-50/80 dark:bg-slate-950/80 border-b border-gray-200/80 dark:border-slate-800 text-gray-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[11px]">
                            <th className="py-3 px-4 w-16"># Line</th>
                            <th className="py-3 px-4">SKU Code</th>
                            <th className="py-3 px-4">Item / Name</th>
                            <th className="py-3 px-4">Firm</th>
                            <th className="py-3 px-4">Unit / Loc</th>
                            <th className="py-3 px-4">Opening</th>
                            <th className="py-3 px-4">ADC / Lead Time</th>
                            <th className="py-3 px-4 text-right">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 font-medium">
                          {filteredValid.map((r, idx) => (
                            <tr
                              key={`valid-${idx}`}
                              className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40 transition-colors"
                            >
                              <td className="py-3 px-4 text-gray-400 dark:text-slate-500 font-mono text-[11px]">
                                Line {r.lineNum}
                              </td>
                              <td className="py-3 px-4 text-gray-900 dark:text-white font-semibold font-mono text-indigo-600 dark:text-indigo-400 font-bold">
                                {r.sku || "—"}
                              </td>
                              <td className="py-3 px-4 text-gray-900 dark:text-white">
                                <div className="font-semibold">{r.name}</div>
                                {r.subCategory && r.subCategory !== r.name && (
                                  <div className="text-[10px] text-gray-400 dark:text-slate-500 font-normal">
                                    {r.subCategory}
                                  </div>
                                )}
                              </td>
                              <td className="py-3 px-4 text-gray-600 dark:text-slate-300">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300">
                                  {r.division || "Universal"}
                                  {r.category &&
                                    r.category.toLowerCase().trim() !== "raw material"
                                    ? ` • ${r.category}`
                                    : ""}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-gray-700 dark:text-slate-300 font-medium">
                                {r.unit || "PCS"}
                                {r.location && (
                                  <span className="text-gray-400 dark:text-slate-500 text-[10px]">
                                    {" "}
                                    ({r.location})
                                  </span>
                                )}
                              </td>
                              <td className="py-3 px-4 font-mono font-bold text-gray-800 dark:text-slate-200">
                                {r.opening ?? 0}
                              </td>
                              <td className="py-3 px-4 font-mono text-[11px] text-gray-600 dark:text-slate-400">
                                ADC: {r.adc ?? 0} • LT: {r.leadTime ?? 0}d
                              </td>
                              <td className="py-3 px-4 text-right">
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/40">
                                  <CheckCircle2 size={12} />
                                  Ready to Add
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })()
              ) : (
                (() => {
                  const filteredSkipped = csvPreviewModal.skippedRows.filter(
                    (r) =>
                      !csvPreviewModal.searchQuery ||
                      (r.name &&
                        r.name
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.sku &&
                        r.sku
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.reason &&
                        r.reason
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.category &&
                        r.category
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )) ||
                      (r.division &&
                        r.division
                          .toLowerCase()
                          .includes(
                            csvPreviewModal.searchQuery.toLowerCase(),
                          )),
                  );

                  if (filteredSkipped.length === 0) {
                    return (
                      <div className="py-12 text-center flex flex-col items-center justify-center">
                        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-500 rounded-2xl mb-3">
                          <CheckCircle2 size={24} />
                        </div>
                        <p className="text-sm font-bold text-gray-700 dark:text-slate-200">
                          {csvPreviewModal.searchQuery
                            ? "No skipped rows match your search."
                            : "Awesome! No rows were skipped."}
                        </p>
                        <p className="text-xs text-gray-400 dark:text-slate-500 mt-1">
                          All rows in the uploaded CSV are valid and supported!
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div className="overflow-x-auto rounded-2xl border border-gray-200/80 dark:border-slate-800 bg-white dark:bg-slate-900">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-gray-50/80 dark:bg-slate-950/80 border-b border-gray-200/80 dark:border-slate-800 text-gray-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[11px]">
                            <th className="py-3 px-4 w-16"># Line</th>
                            <th className="py-3 px-4">SKU Code</th>
                            <th className="py-3 px-4">Item / Name</th>
                            <th className="py-3 px-4">Firm</th>
                            <th className="py-3 px-4">Unit</th>
                            <th className="py-3 px-4">Reason Not Inserted</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 font-medium">
                          {filteredSkipped.map((r, idx) => (
                            <tr
                              key={`skipped-${idx}`}
                              className="hover:bg-amber-50/30 dark:hover:bg-amber-950/10 transition-colors"
                            >
                              <td className="py-3 px-4 text-gray-400 dark:text-slate-500 font-mono text-[11px]">
                                Line {r.lineNum}
                              </td>
                              <td className="py-3 px-4 text-gray-900 dark:text-white font-semibold font-mono">
                                {r.sku || "—"}
                              </td>
                              <td className="py-3 px-4 text-gray-900 dark:text-white font-semibold">
                                {r.name || "—"}
                              </td>
                              <td className="py-3 px-4 text-gray-600 dark:text-slate-300">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300">
                                  {r.division || "Universal"}
                                  {r.category &&
                                    r.category.toLowerCase().trim() !== "raw material"
                                    ? ` • ${r.category}`
                                    : ""}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-gray-600 dark:text-slate-300 font-medium">
                                {r.unit || "—"}
                              </td>
                              <td className="py-3 px-4">
                                <span
                                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-bold border ${r.isExisting
                                      ? "bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border-amber-300/80 dark:border-amber-800/60"
                                      : "bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border-rose-200/60 dark:border-rose-800/40"
                                    }`}
                                >
                                  {r.isExisting ? (
                                    <AlertTriangle
                                      size={12}
                                      className="shrink-0 text-amber-600 dark:text-amber-400"
                                    />
                                  ) : (
                                    <AlertCircle size={12} className="shrink-0" />
                                  )}
                                  {r.reason}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })()
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-6 border-t border-gray-100 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-gray-50/50 dark:bg-slate-900/50">
              <div>
                {csvPreviewModal.skippedRows.length > 0 && (
                  <button
                    type="button"
                    onClick={handleExportSkippedCSV}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:hover:bg-amber-900/50 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/40 rounded-2xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <Download size={15} />
                    <span>
                      Export Skipped CSV ({csvPreviewModal.skippedRows.length})
                    </span>
                  </button>
                )}
              </div>

              <div className="flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    if (csvPreviewModal.inputEvent?.target) {
                      csvPreviewModal.inputEvent.target.value = "";
                    }
                    setCsvPreviewModal((prev) => ({ ...prev, isOpen: false }));
                  }}
                  className="px-5 py-2.5 rounded-2xl text-xs font-bold text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  title={!canWrite ? READ_ONLY_TOOLTIP : undefined}
                  type="button"
                  disabled={
                    !canWrite ||
                    csvPreviewModal.validRows.length === 0 ||
                    csvPreviewModal.isSubmitting
                  }
                  onClick={handleConfirmCSVImport}
                  className="flex items-center justify-center gap-2 px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white rounded-2xl text-xs font-bold transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  {csvPreviewModal.isSubmitting ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Submitting to Master Materials...</span>
                    </>
                  ) : (
                    <>
                      <Check size={16} />
                      <span>
                        Confirm & Submit (
                        {csvPreviewModal.validRows.length} New Material
                        {csvPreviewModal.validRows.length !== 1 ? "s" : ""} to Master Catalog)
                      </span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Rejected */}
      <RecycleModal
        isOpen={isRecycleModalOpen}
        onClose={() => setIsRecycleModalOpen(false)}
        activeUser={activeUser}
        materials={materials}
        finishedGoodsNames={finishedGoodsNames}
        divisions={divisions}
        onRecycleUpdated={() => dispatch(fetchInventoryData())}
      />

      {/* MODAL: Daily Consumption Report */}
      <DailyConsumptionModal
        isOpen={isConsumptionModalOpen}
        onClose={() => setIsConsumptionModalOpen(false)}
        activeUser={activeUser}
      />

      {/* MODAL: Material Transfer Form */}
      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        activeUser={activeUser}
      />

      {/* MODAL: Physical Stock Count & Variance */}
      <PhysicalStockModal
        isOpen={isPhysicalStockModalOpen}
        onClose={() => {
          setIsPhysicalStockModalOpen(false);
          setPhysicalModalPrefill(null);
        }}
        activeUser={activeUser}
        prefill={physicalModalPrefill}
      />
    </div>
  );
}
